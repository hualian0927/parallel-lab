#pragma once

#include <algorithm>
#include <chrono>
#include <cstdint>
#include <cstdlib>
#include <cstring>
#include <fstream>
#include <iostream>
#include <limits>
#include <queue>
#include <string>
#include <vector>
#include <mpi.h>
#if defined(__aarch64__) || defined(__ARM_NEON)
#include <arm_neon.h>
#endif
#include "hnswlib/hnswlib/simd_utils.h"
#include "../graph_index_common/common.h"

// ---- IVF list ----

struct IvfPqIVFList
{
    std::vector<int> ids;
};

// ---- thread stat ----

struct IvfPqThreadStat
{
    double work_us = 0.0;
    size_t tasks = 0;
};

// ---- path helpers ----

static inline std::string ivf_pq_cent_path(int K, size_t dim)
{
    return files_path("ivfpq_cent_K" + std::to_string(K) + "_d" + std::to_string(dim) + ".bin");
}

static inline std::string ivf_pq_cb_path(int K, int M, int Kpq, size_t dim)
{
    return files_path("ivfpq_cb_K" + std::to_string(K) + "_M" + std::to_string(M) +
                      "_Kpq" + std::to_string(Kpq) + "_d" + std::to_string(dim) + ".bin");
}

static inline std::string ivf_pq_codes_path(int K, int M, int Kpq, size_t n)
{
    return files_path("ivfpq_codes_K" + std::to_string(K) + "_M" + std::to_string(M) +
                      "_Kpq" + std::to_string(Kpq) + "_n" + std::to_string(n) + ".bin");
}

static inline std::string ivf_pq_assign_path(int K, size_t dim, size_t n)
{
    return files_path("ivfpq_assign_K" + std::to_string(K) + "_d" + std::to_string(dim) +
                      "_n" + std::to_string(n) + ".bin");
}

// ---- templated file I/O ----

template <typename T>
static inline void ivf_pq_save_vec_bin(const std::string &path, const std::vector<T> &v)
{
    std::ofstream out(path, std::ios::binary);
    size_t n = v.size();
    out.write(reinterpret_cast<const char *>(&n), sizeof(n));
    if (n)
        out.write(reinterpret_cast<const char *>(v.data()), static_cast<std::streamsize>(n * sizeof(T)));
}

template <typename T>
static inline bool ivf_pq_load_vec_bin(const std::string &path, std::vector<T> &v)
{
    std::ifstream in(path, std::ios::binary);
    if (!in)
        return false;
    size_t n = 0;
    in.read(reinterpret_cast<char *>(&n), sizeof(n));
    v.resize(n);
    if (n)
        in.read(reinterpret_cast<char *>(v.data()), static_cast<std::streamsize>(n * sizeof(T)));
    return true;
}

// ---- IVF training ----

static inline void ivf_pq_train_ivf(const float *b, size_t n, size_t d, int K,
                                     std::vector<float> &cent, int it = 12)
{
    cent.resize((size_t)K * d);
    for (int k = 0; k < K; ++k)
    {
        int ri = rand() % n;
        std::memcpy(cent.data() + (size_t)k * d, b + (size_t)ri * d, d * sizeof(float));
    }

    std::vector<int> as(n);
    std::vector<float> nc((size_t)K * d);
    std::vector<int> cn(K);
    for (int t = 0; t < it; ++t)
    {
        for (size_t i = 0; i < n; ++i)
        {
            float best = 1e30f;
            int bk = 0;
            const float *v = b + i * d;
            for (int k = 0; k < K; ++k)
            {
                float dist = 0.0f;
                const float *c = cent.data() + (size_t)k * d;
                for (size_t j = 0; j < d; ++j)
                {
                    float df = v[j] - c[j];
                    dist += df * df;
                }
                if (dist < best)
                {
                    best = dist;
                    bk = k;
                }
            }
            as[i] = bk;
        }

        std::fill(nc.begin(), nc.end(), 0.0f);
        std::fill(cn.begin(), cn.end(), 0);
        for (size_t i = 0; i < n; ++i)
        {
            int k = as[i];
            ++cn[k];
            const float *v = b + i * d;
            for (size_t j = 0; j < d; ++j)
                nc[(size_t)k * d + j] += v[j];
        }
        for (int k = 0; k < K; ++k)
            if (cn[k] > 0)
                for (size_t j = 0; j < d; ++j)
                    cent[(size_t)k * d + j] = nc[(size_t)k * d + j] / cn[k];
    }
}

// ---- IVF assign ----

static inline void ivf_pq_compute_ivf_assign(const float *b, size_t n, size_t d, int K,
                                              const std::vector<float> &cent, std::vector<int> &assign)
{
    assign.resize(n);
    for (size_t i = 0; i < n; ++i)
    {
        float best = 1e30f;
        int bk = 0;
        const float *v = b + i * d;
        for (int k = 0; k < K; ++k)
        {
            float dist = 0.0f;
            const float *c = cent.data() + (size_t)k * d;
            for (size_t j = 0; j < d; ++j)
            {
                float df = v[j] - c[j];
                dist += df * df;
            }
            if (dist < best)
            {
                best = dist;
                bk = k;
            }
        }
        assign[i] = bk;
    }
}

static inline std::vector<IvfPqIVFList> ivf_pq_build_ivf_from_assign(const std::vector<int> &assign, int K)
{
    std::vector<IvfPqIVFList> lists(K);
    for (size_t i = 0; i < assign.size(); ++i)
        lists[(size_t)assign[i]].ids.push_back((int)i);
    return lists;
}

// ---- PQ training & encoding (SoA layout) ----

static inline void ivf_pq_train_encode_soa(const float *b, size_t n, size_t d, int M, int Kpq,
                                            std::vector<float> &cb_SoA, uint8_t *codes, int it = 6)
{
    size_t ds = d / M;
    std::vector<float> ca((size_t)M * Kpq * ds);
    for (int m = 0; m < M; ++m)
    {
        float *cent = ca.data() + (size_t)m * Kpq * ds;
        for (int k = 0; k < Kpq; ++k)
        {
            int ri = rand() % n;
            std::memcpy(cent + (size_t)k * ds, b + (size_t)ri * d + (size_t)m * ds, ds * sizeof(float));
        }

        std::vector<int> as(n);
        std::vector<float> sm((size_t)Kpq * ds);
        std::vector<int> cn(Kpq);
        for (int t = 0; t < it; ++t)
        {
            for (size_t i = 0; i < n; ++i)
            {
                float best = 1e30f;
                int bk = 0;
                const float *sv = b + i * d + (size_t)m * ds;
                for (int k = 0; k < Kpq; ++k)
                {
                    float dist = 0.0f;
                    for (size_t j = 0; j < ds; ++j)
                    {
                        float df = sv[j] - cent[(size_t)k * ds + j];
                        dist += df * df;
                    }
                    if (dist < best)
                    {
                        best = dist;
                        bk = k;
                    }
                }
                as[i] = bk;
            }

            std::fill(sm.begin(), sm.end(), 0.0f);
            std::fill(cn.begin(), cn.end(), 0);
            for (size_t i = 0; i < n; ++i)
            {
                int k = as[i];
                ++cn[k];
                for (size_t j = 0; j < ds; ++j)
                    sm[(size_t)k * ds + j] += b[i * d + (size_t)m * ds + j];
            }
            for (int k = 0; k < Kpq; ++k)
                if (cn[k] > 0)
                    for (size_t j = 0; j < ds; ++j)
                        cent[(size_t)k * ds + j] = sm[(size_t)k * ds + j] / cn[k];
        }

        for (size_t i = 0; i < n; ++i)
        {
            float best = 1e30f;
            uint8_t bk = 0;
            const float *sv = b + i * d + (size_t)m * ds;
            for (int k = 0; k < Kpq; ++k)
            {
                float dist = 0.0f;
                for (size_t j = 0; j < ds; ++j)
                {
                    float df = sv[j] - cent[(size_t)k * ds + j];
                    dist += df * df;
                }
                if (dist < best)
                {
                    best = dist;
                    bk = (uint8_t)k;
                }
            }
            codes[i * M + m] = bk;
        }
    }

    cb_SoA.resize((size_t)M * Kpq * ds);
    for (int m = 0; m < M; ++m)
        for (int c = 0; c < Kpq; ++c)
            for (size_t dd = 0; dd < ds; ++dd)
                cb_SoA[(size_t)m * Kpq * ds + dd * Kpq + c] = ca[(size_t)m * Kpq * ds + (size_t)c * ds + dd];
}

// ---- local search with re-rank ----

static inline void ivf_pq_search_local_rerank(const float *base, const uint8_t *codes,
                                               const std::vector<float> &cent,
                                               const std::vector<IvfPqIVFList> &lists,
                                               const std::vector<float> &cb_SoA,
                                               const float *q, size_t d, int M, int Kpq, int np,
                                               size_t pq_pool, size_t local_k, int goff,
                                               std::vector<std::pair<float, int>> &out)
{
    size_t ds = d / M;
    int Kivf = (int)(cent.size() / d);
    np = std::min(np, Kivf);

    Heap coarse;
    for (int c = 0; c < Kivf; ++c)
        hp(coarse, InnerProductSIMDNeon(q, cent.data() + (size_t)c * d, d), c, np);

    std::vector<int> probes;
    probes.reserve(np);
    while (!coarse.empty())
    {
        probes.push_back(coarse.top().second);
        coarse.pop();
    }

    float lut[4 * 256];
    for (int m = 0; m < M; ++m)
    {
        const float *qs = q + (size_t)m * ds;
        const float *csa = cb_SoA.data() + (size_t)m * Kpq * ds;
        float *lm = lut + (size_t)m * Kpq;
        for (int c = 0; c < Kpq; c += 4)
        {
#if defined(__aarch64__) || defined(__ARM_NEON)
            float32x4_t s4 = vdupq_n_f32(0.0f);
            for (size_t j = 0; j < ds; ++j)
                s4 = vmlaq_f32(s4, vdupq_n_f32(qs[j]), vld1q_f32(csa + j * Kpq + c));
            vst1q_f32(lm + c, s4);
#else
            for (int cc = 0; cc < 4 && c + cc < Kpq; ++cc)
            {
                float dot = 0.0f;
                for (size_t j = 0; j < ds; ++j)
                    dot += qs[j] * csa[j * Kpq + c + cc];
                lm[c + cc] = dot;
            }
#endif
        }
    }

    Heap approx;
    for (int cid : probes)
    {
        for (int vi : lists[cid].ids)
        {
            const uint8_t *pq = codes + (size_t)vi * M;
            float dot = 0.0f;
            for (int m = 0; m < M; ++m)
                dot += lut[(size_t)m * Kpq + pq[m]];
            hp(approx, 1.0f - dot, vi, pq_pool);
        }
    }

    Heap fine;
    while (!approx.empty())
    {
        int local_id = approx.top().second;
        approx.pop();
        float dist = InnerProductSIMDNeon(q, base + (size_t)local_id * d, d);
        hp(fine, dist, local_id + goff, local_k);
    }

    out.clear();
    out.reserve(local_k);
    while (!fine.empty())
    {
        out.push_back(fine.top());
        fine.pop();
    }
}
