#pragma once
// ===================================================================
// FA-MPI 共享层: 数据加载 + Bcast/Scatter + 已有FA框架复用
// 依赖: fa_core.h, fa_codec.h, fa_index.h, fa_parallel.h, fa_pool.h
// ===================================================================
#include <algorithm>
#include <cstdlib>
#include <cstring>
#include <fstream>
#include <iostream>
#include <mpi.h>
#include <queue>
#include <set>
#include <vector>
#include "hnswlib/hnswlib/fa_core.h"
#include "hnswlib/hnswlib/fa_codec.h"
#include "hnswlib/hnswlib/fa_index.h"
#include "hnswlib/hnswlib/fa_parallel.h"
#include "hnswlib/hnswlib/fa_pool.h"

using TopK = fa_core::TopK;

// ---- 数据加载 ----
template<typename T>
T* load_data(const std::string& p, size_t& n, size_t& d) {
    std::ifstream f(p, std::ios::binary); if (!f) return nullptr;
    int32_t h[2]; f.read((char*)h, 8); n = h[0]; d = h[1];
    T* dt = new T[n * d]; f.read((char*)dt, n * d * sizeof(T)); return dt;
}

// ---- Bcast vector<float> helper ----
static inline void bcast_vec(std::vector<float>& v, int rank) {
    size_t sz = v.size();
    MPI_Bcast(&sz, 1, MPI_UNSIGNED_LONG_LONG, 0, MPI_COMM_WORLD);
    if (rank != 0) v.resize(sz);
    if (sz) MPI_Bcast(v.data(), (int)sz, MPI_FLOAT, 0, MPI_COMM_WORLD);
}

// ---- Bcast uint8_t vector helper ----
static inline void bcast_u8(std::vector<uint8_t>& v, int rank) {
    size_t sz = v.size();
    MPI_Bcast(&sz, 1, MPI_UNSIGNED_LONG_LONG, 0, MPI_COMM_WORLD);
    if (rank != 0) v.resize(sz);
    if (sz) MPI_Bcast(v.data(), (int)sz, MPI_UNSIGNED_CHAR, 0, MPI_COMM_WORLD);
}

// ---- Bcast Codec (centroids + codes + M/ksub/dsub fields) ----
static inline void bcast_codec(fa_engine::Codec& c, int rank) {
    bcast_vec(c.centroids, rank);
    bcast_u8(c.codes, rank);
    int f[3] = {c.M, c.ksub, c.dsub};
    MPI_Bcast(f, 3, MPI_INT, 0, MPI_COMM_WORLD);
    if (rank != 0) { c.M = f[0]; c.ksub = f[1]; c.dsub = f[2]; }
}

// ---- Bcast FAIndex (IVF centroids + Codec + order) ----
static inline void bcast_fa_index(fa_engine::FAIndex& idx, int rank) {
    // IVF centroids
    bcast_vec(idx.ivf.centroids, rank);
    // IVF list_offsets
    { size_t sz = idx.ivf.list_offsets.size();
      MPI_Bcast(&sz, 1, MPI_UNSIGNED_LONG_LONG, 0, MPI_COMM_WORLD);
      if (rank != 0) idx.ivf.list_offsets.resize(sz);
      if (sz) MPI_Bcast(idx.ivf.list_offsets.data(), (int)sz, MPI_UNSIGNED_LONG_LONG, 0, MPI_COMM_WORLD); }
    // IVF reordered_ids
    { size_t sz = idx.ivf.reordered_ids.size();
      MPI_Bcast(&sz, 1, MPI_UNSIGNED_LONG_LONG, 0, MPI_COMM_WORLD);
      if (rank != 0) idx.ivf.reordered_ids.resize(sz);
      if (sz) MPI_Bcast(idx.ivf.reordered_ids.data(), (int)sz, MPI_UNSIGNED, 0, MPI_COMM_WORLD); }
    // IVF dimensions
    MPI_Bcast(&idx.ivf.nlist, 1, MPI_UNSIGNED_LONG_LONG, 0, MPI_COMM_WORLD);
    MPI_Bcast(&idx.ivf.d, 1, MPI_UNSIGNED_LONG_LONG, 0, MPI_COMM_WORLD);
    // CodeOrder
    int o = static_cast<int>(idx.order);
    MPI_Bcast(&o, 1, MPI_INT, 0, MPI_COMM_WORLD);
    if (rank != 0) idx.order = static_cast<fa_engine::CodeOrder>(o);
    // Global Codec
    bcast_codec(idx.global_codec, rank);
    // n, d, base (base isn't sent, caller must reassign)
    idx.n = idx.ivf.reordered_ids.size();
    idx.d = idx.ivf.d;
}

// ---- 计算recall@k ----
static inline float compute_recall(const TopK& res, const int* gt, size_t k) {
    std::set<int> gs(gt, gt + k); size_t hits = 0;
    TopK tmp = res;
    while (!tmp.empty()) { if (gs.count(tmp.top().second)) ++hits; tmp.pop(); }
    return (float)hits / k;
}
