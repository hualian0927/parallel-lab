// ============================================================================
// v7: Communication-Computation Overlap Pipeline — 测试入口
// 编译: mpic++ main.cc -o main -O2 -lpthread -std=c++17 -I../..
//
// 实验设计:
//   - 固定算法参数 (K, M, Kpq, np), 变化 num_batches (1/2/4/8/16)
//   - num_batches=1 → 完全串行 (baseline)
//   - num_batches>1 → 流水线, 预期 wall-time < serial_time
//   - 关键输出: overlap_ratio, pipeline_speedup
//
// 分析维度:
//   1. overlap_ratio vs num_batches — 最优分批数
//   2. overlap_ratio vs MPI规模 (sz=2/4/8) — 通信时间越长, 重叠收益越大
//   3. overlap_ratio vs cand_k — 搜索时间越长 (候选池大), 重叠窗口越大
// ============================================================================

#include <algorithm>
#include <atomic>
#include <chrono>
#include <cstdlib>
#include <cstring>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <limits>
#include <pthread.h>
#include <string>
#include <vector>
#include <mpi.h>
#include "overlap_pipeline.h"

int main(int argc, char **argv)
{
    MPI_Init(&argc, &argv);
    int rank, sz;
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
    MPI_Comm_size(MPI_COMM_WORLD, &sz);
    srand(42 + rank);

    // ---- 数据加载 (rank 0) ----
    size_t tn = 0, dim = 0, qn = 0, gd = 0;
    float *ab = nullptr, *qu = nullptr;
    int *gt = nullptr;
    if (rank == 0)
    {
        std::string dp = "/anndata/";
        qu = load_fbin_like<float>(dp + "DEEP100K.query.fbin", qn, dim);
        ab = load_fbin_like<float>(dp + "DEEP100K.base.100k.fbin", tn, dim);
        gt = load_fbin_like<int>(dp + "DEEP100K.gt.query.100k.top100.bin", qn, gd);
        qn = 2000;
    }

    MPI_Bcast(&tn, 1, MPI_UNSIGNED_LONG_LONG, 0, MPI_COMM_WORLD);
    MPI_Bcast(&dim, 1, MPI_UNSIGNED_LONG_LONG, 0, MPI_COMM_WORLD);
    MPI_Bcast(&qn, 1, MPI_UNSIGNED_LONG_LONG, 0, MPI_COMM_WORLD);
    MPI_Bcast(&gd, 1, MPI_UNSIGNED_LONG_LONG, 0, MPI_COMM_WORLD);

    // ---- 等块分发 ----
    size_t ln = tn / sz, rm = tn % sz;
    std::vector<int> sc(sz), ds(sz);
    size_t off = 0;
    for (int i = 0; i < sz; ++i)
    {
        size_t ni = ln + (size_t)(i < (int)rm ? 1 : 0);
        sc[i] = (int)(ni * dim);
        ds[i] = (int)(off * dim);
        off += ni;
    }

    size_t mn = ln + (size_t)(rank < (int)rm ? 1 : 0);
    std::vector<float> lb(mn * dim);
    MPI_Scatterv(ab, sc.data(), ds.data(), MPI_FLOAT, lb.data(), (int)(mn * dim), MPI_FLOAT, 0, MPI_COMM_WORLD);
    int goff = (int)(ds[rank] / dim);

    // ---- 参数 ----
    const int K = env_i("ANN_K", 200), M = 4, Kpq = 256;
    const size_t k = 10;
    const size_t cand_k = std::max((size_t)env_i("ANN_CAND_PER_RANK", 384), k);
    const size_t local_k = std::max((size_t)env_i("ANN_LOCAL_K", 20), k);
    const bool build_only = env_i("ANN_BUILD_ONLY", 0) != 0;
    const bool use_prebuilt = env_i("ANN_USE_PREBUILT", 1) != 0;

    MPI_Barrier(MPI_COMM_WORLD);
    double tb0 = MPI_Wtime();

    // ---- 训练/加载全局索引 (rank 0) ----
    std::vector<float> cent, cb_SoA;
    std::vector<uint8_t> codes_all;
    std::vector<int> assign_all;
    int index_mode = 0;
    if (rank == 0)
    {
        const std::string p_cent = ivf_pq_cent_path(K, dim);
        const std::string p_cb = ivf_pq_cb_path(K, M, Kpq, dim);
        const std::string p_codes = ivf_pq_codes_path(K, M, Kpq, tn);
        const std::string p_assign = ivf_pq_assign_path(K, dim, tn);
        bool loaded = false;
        if (use_prebuilt && file_exists(p_cent) && file_exists(p_cb) && file_exists(p_codes) && file_exists(p_assign))
        {
            loaded = ivf_pq_load_vec_bin<float>(p_cent, cent) &&
                     ivf_pq_load_vec_bin<float>(p_cb, cb_SoA) &&
                     ivf_pq_load_vec_bin<uint8_t>(p_codes, codes_all) &&
                     ivf_pq_load_vec_bin<int>(p_assign, assign_all);
        }
        if (!loaded)
        {
            ivf_pq_train_ivf(ab, tn, dim, K, cent, 12);
            codes_all.resize(tn * M);
            ivf_pq_train_encode_soa(ab, tn, dim, M, Kpq, cb_SoA, codes_all.data(), 6);
            ivf_pq_compute_ivf_assign(ab, tn, dim, K, cent, assign_all);
            ivf_pq_save_vec_bin<float>(p_cent, cent);
            ivf_pq_save_vec_bin<float>(p_cb, cb_SoA);
            ivf_pq_save_vec_bin<uint8_t>(p_codes, codes_all);
            ivf_pq_save_vec_bin<int>(p_assign, assign_all);
            index_mode = 0;
        }
        else
        {
            index_mode = 1;
        }
    }

    MPI_Bcast(&index_mode, 1, MPI_INT, 0, MPI_COMM_WORLD);

    if (build_only)
    {
        double tb1_build = MPI_Wtime();
        if (rank == 0)
            std::cout << "[PIPELINE] build only, index_mode=" << (index_mode ? "load" : "train")
                      << " K=" << K << " build_ms=" << (tb1_build - tb0) * 1e3 << "\n";
        if (rank == 0) delete[] ab;
        delete[] qu; delete[] gt;
        MPI_Finalize();
        return 0;
    }

    bcast_vector_f32(cent, rank);
    bcast_vector_f32(cb_SoA, rank);

    // ---- 分发 codes & assign ----
    std::vector<uint8_t> codes(mn * M);
    std::vector<int> local_assign(mn);
    {
        std::vector<int> scc(sz), dsc(sz);
        size_t o2 = 0;
        for (int i = 0; i < sz; ++i)
        {
            size_t ni = ln + (size_t)(i < (int)rm ? 1 : 0);
            scc[i] = (int)(ni * M); dsc[i] = (int)(o2 * M); o2 += ni;
        }
        MPI_Scatterv(rank == 0 ? codes_all.data() : nullptr, scc.data(), dsc.data(), MPI_UNSIGNED_CHAR,
                     codes.data(), (int)(mn * M), MPI_UNSIGNED_CHAR, 0, MPI_COMM_WORLD);
        std::vector<int> scc_a(sz), dsc_a(sz);
        size_t o3 = 0;
        for (int i = 0; i < sz; ++i)
        {
            size_t ni = ln + (size_t)(i < (int)rm ? 1 : 0);
            scc_a[i] = (int)ni; dsc_a[i] = (int)o3; o3 += ni;
        }
        MPI_Scatterv(rank == 0 ? assign_all.data() : nullptr, scc_a.data(), dsc_a.data(), MPI_INT,
                     local_assign.data(), (int)mn, MPI_INT, 0, MPI_COMM_WORLD);
    }

    auto lists = ivf_pq_build_ivf_from_assign(local_assign, K);

    if (rank == 0) delete[] ab;

    if (rank != 0) { qu = new float[qn * dim]; gt = new int[qn * gd]; }
    MPI_Bcast(qu, (int)(qn * dim), MPI_FLOAT, 0, MPI_COMM_WORLD);
    MPI_Bcast(gt, (int)(qn * gd), MPI_INT, 0, MPI_COMM_WORLD);

    if (rank == 0)
    {
        std::cout << std::fixed << std::setprecision(3)
                  << "[PIPELINE] MPI=" << sz
                  << " K=" << K << " M=" << M << " Kpq=" << Kpq
                  << " cand_k=" << cand_k << " local_k=" << local_k
                  << " index_mode=" << (index_mode ? "load" : "train") << "\n";
    }

    // ---- 实验: 变化 num_batches 观察重叠效果 ----
    int default_np[] = {10, 12, 14};
    int test_batches[] = {1, 2, 4, 8, 16};  // 1 = baseline serial

    for (int np : default_np)
    {
        std::cout << (rank == 0 ? "" : ""); // barrier for clean output
        MPI_Barrier(MPI_COMM_WORLD);

        for (int nbatches : test_batches)
        {
            PipelineTiming timing;
            double total_recall = 0.0;
            int actual_batches = std::min(nbatches, (int)qn);

            MPI_Barrier(MPI_COMM_WORLD);
            pipeline_search_all(lb.data(), codes.data(), cent, lists, cb_SoA,
                                qu, qn, dim, M, Kpq, np, cand_k, local_k, goff,
                                gt, gd, k, rank, sz, actual_batches,
                                total_recall, timing);

            // rank 0 outputs results
            if (rank == 0)
            {
                double recall = total_recall / (double)qn;

                std::cout << std::fixed << std::setprecision(3)
                          << "[PIPELINE] np=" << np
                          << " batches=" << actual_batches
                          << " recall=" << recall
                          << " avg_lat=" << (timing.wall_us / qn) << " us"
                          << " search_us=" << timing.total_search_us
                          << " gather_us=" << timing.total_gather_us
                          << " merge_us=" << timing.total_merge_us
                          << " overlap_ratio=" << timing.overlap_ratio
                          << " speedup=" << timing.pipeline_speedup;

                // 每个 batch 的详细分解
                if (actual_batches > 1)
                {
                    std::cout << " batch_detail[search/wait/merge]:";
                    for (int bi = 0; bi < actual_batches && bi < 4; ++bi)
                    {
                        std::cout << " b" << bi << "("
                                  << timing.batch_search_us[bi] << "/"
                                  << timing.batch_wait_us[bi] << "/"
                                  << timing.batch_merge_us[bi] << ")";
                    }
                }
                std::cout << "\n";
            }
        }
    }

    delete[] qu; delete[] gt;
    MPI_Finalize();
    return 0;
}
