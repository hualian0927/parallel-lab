#pragma once
// ============================================================================
// v7: Communication-Computation Overlap Pipeline
//
// 核心思路: 将 query 分批, 用 MPI_Igather (非阻塞) + 双缓冲实现流水线:
//   batch 0: search → pack → Igather ───────────────────── merge
//   batch 1:           search → pack → Igather ─────────── merge
//   batch 2:                     search → pack → Igather ── merge
//
// 预期效果: 当 search_time ≈ gather_time 时, wall-time 接近 max(search, gather)
//          而非 search + gather (完全串行), 加速比上限 = (T_search+T_gather) / max(T_search,T_gather)
//
// 关键测量指标:
//   - overlap_ratio = 实际重叠时间 / 理论最大重叠时间
//   - pipeline_efficiency = (串行总时间 / 流水线总时间) - 1 的百分比
// ============================================================================

#include <algorithm>
#include <chrono>
#include <cstring>
#include <iomanip>
#include <iostream>
#include <limits>
#include <mpi.h>
#include <numeric>
#include <string>
#include <vector>
#include "../ivf_pq.h"

// ---- 双缓冲结构 ----
// 两个 send buffer 交替使用: batch_i 用 buffer[i%2] search+pack,
// 同时 batch_{i-1} 的 buffer[(i-1)%2] 处于 MPI_Igather 进行中

struct PipelineBuffer
{
    std::vector<float> sendbuf;   // 打包后的 (dist,id) 对
    std::vector<float> recvbuf;   // rank 0 接收用
    MPI_Request request;
    bool in_flight = false;
};

// ---- 流水线 batch 搜索 ----
// 对一批 query 执行本地 IVF-PQ 搜索, 结果直接打包到 buffer
static inline void pipeline_search_batch(
    const float *base, const uint8_t *codes,
    const std::vector<float> &cent, const std::vector<IvfPqIVFList> &lists,
    const std::vector<float> &cb_SoA,
    const float *queries, size_t q_start, size_t q_end,
    size_t d, int M, int Kpq, int np, size_t cand_k, size_t local_k, int goff,
    const float invalid, std::vector<float> &sendbuf)
{
    size_t batch_qn = q_end - q_start;
    for (size_t qi_local = 0; qi_local < batch_qn; ++qi_local)
    {
        size_t qi = q_start + qi_local;
        std::vector<std::pair<float, int>> out;
        ivf_pq_search_local_rerank(base, codes, cent, lists, cb_SoA,
                                    queries + qi * d, d, M, Kpq, np,
                                    cand_k, local_k, goff, out);

        size_t base_idx = qi_local * local_k * 2;
        for (size_t j = 0; j < local_k; ++j)
        {
            if (j < out.size())
            {
                sendbuf[base_idx + j * 2] = out[j].first;
                sendbuf[base_idx + j * 2 + 1] = (float)out[j].second;
            }
            else
            {
                sendbuf[base_idx + j * 2] = invalid;
                sendbuf[base_idx + j * 2 + 1] = -1.0f;
            }
        }
    }
}

// ---- rank 0 合并一个 batch 的结果 ----
static inline double pipeline_merge_batch(
    const std::vector<float> &recvbuf, int sz, size_t batch_qn,
    size_t local_k, size_t k, size_t q_start,
    const int *gt, size_t gd,
    std::vector<double> &batch_recalls)
{
    double sum_recall = 0.0;
    size_t rank_stride = batch_qn * local_k * 2;

    for (size_t qi_local = 0; qi_local < batch_qn; ++qi_local)
    {
        size_t qi = q_start + qi_local;
        Heap g;
        for (int r = 0; r < sz; ++r)
        {
            size_t base = (size_t)r * rank_stride + qi_local * local_k * 2;
            for (size_t j = 0; j < local_k; ++j)
            {
                int id = (int)recvbuf[base + j * 2 + 1];
                if (id >= 0)
                    hp(g, recvbuf[base + j * 2], id, k);
            }
        }
        std::set<int> gs(gt + qi * gd, gt + qi * gd + k);
        size_t hit = 0;
        Heap tmp = g;
        while (!tmp.empty())
        {
            if (gs.count(tmp.top().second))
                ++hit;
            tmp.pop();
        }
        double recall_i = (double)hit / k;
        sum_recall += recall_i;
        if (qi_local < batch_recalls.size())
            batch_recalls[qi_local] = recall_i;
    }
    return sum_recall;
}

// ---- 流水线主循环 (返回详细时序分解) ----
struct PipelineTiming
{
    double total_search_us = 0.0;   // 所有 rank 的 search 总时间 (max across ranks)
    double total_gather_us = 0.0;   // 所有 batch 的 MPI_Wait 总时间
    double total_merge_us = 0.0;    // rank 0 的 merge 总时间
    double wall_us = 0.0;           // 端到端 wall time
    double overlap_search_us = 0.0; // 与 communication 重叠的 search 时间
    double overlap_ratio = 0.0;     // overlap_search_us / total_search_us
    double pipeline_speedup = 0.0;  // vs 完全串行
    std::vector<double> batch_search_us;
    std::vector<double> batch_wait_us;
    std::vector<double> batch_merge_us;
};

static inline void pipeline_search_all(
    const float *base, const uint8_t *codes,
    const std::vector<float> &cent, const std::vector<IvfPqIVFList> &lists,
    const std::vector<float> &cb_SoA,
    const float *queries, size_t qn, size_t d,
    int M, int Kpq, int np, size_t cand_k, size_t local_k, int goff,
    const int *gt, size_t gd, size_t k,
    int rank, int sz, int num_batches,
    double &total_recall, PipelineTiming &timing)
{
    const float invalid = std::numeric_limits<float>::infinity();
    size_t batch_qn = (qn + num_batches - 1) / num_batches;
    int send_count_per_batch = (int)(batch_qn * local_k * 2);
    int recv_count = send_count_per_batch * sz;

    // 双缓冲
    PipelineBuffer buf[2];
    for (int b = 0; b < 2; ++b)
    {
        buf[b].sendbuf.resize(send_count_per_batch);
        if (rank == 0)
            buf[b].recvbuf.resize(recv_count);
    }

    timing.batch_search_us.resize(num_batches);
    timing.batch_wait_us.resize(num_batches);
    timing.batch_merge_us.resize(num_batches);

    total_recall = 0.0;
    double wall_t0 = MPI_Wtime();

    int prev_buf_idx = -1; // 上一个 batch 使用的 buffer index

    for (int bi = 0; bi < num_batches; ++bi)
    {
        size_t q_start = (size_t)bi * batch_qn;
        size_t q_end = std::min(q_start + batch_qn, qn);
        size_t actual_batch_qn = q_end - q_start;
        if (actual_batch_qn == 0)
            break;

        int cur_buf_idx = bi % 2;

        // ---- Step 1: 搜索当前 batch (可能与前一个 batch 的通信重叠) ----
        double t_search0 = MPI_Wtime();
        pipeline_search_batch(base, codes, cent, lists, cb_SoA,
                              queries, q_start, q_end, d, M, Kpq, np,
                              cand_k, local_k, goff, invalid,
                              buf[cur_buf_idx].sendbuf);
        double t_search1 = MPI_Wtime();
        timing.batch_search_us[bi] = (t_search1 - t_search0) * 1e6;

        // ---- Step 2: 启动当前 batch 的非阻塞 Gather ----
        double t_gather0 = MPI_Wtime();
        MPI_Igather(buf[cur_buf_idx].sendbuf.data(), send_count_per_batch, MPI_FLOAT,
                    rank == 0 ? buf[cur_buf_idx].recvbuf.data() : nullptr,
                    send_count_per_batch, MPI_FLOAT,
                    0, MPI_COMM_WORLD, &buf[cur_buf_idx].request);
        buf[cur_buf_idx].in_flight = true;

        // ---- Step 3: 等待上一个 batch 的 Gather 完成 + merge ----
        double batch_wait_us = 0.0, batch_merge_us = 0.0;
        if (prev_buf_idx >= 0 && buf[prev_buf_idx].in_flight)
        {
            double t_wait0 = MPI_Wtime();
            MPI_Wait(&buf[prev_buf_idx].request, MPI_STATUS_IGNORE);
            double t_wait1 = MPI_Wtime();
            batch_wait_us = (t_wait1 - t_wait0) * 1e6;
            buf[prev_buf_idx].in_flight = false;

            if (rank == 0)
            {
                double t_merge0 = MPI_Wtime();
                size_t prev_q_start = (size_t)(bi - 1) * batch_qn;
                size_t prev_q_end = std::min(prev_q_start + batch_qn, qn);
                size_t prev_batch_qn = prev_q_end - prev_q_start;
                std::vector<double> dummy(prev_batch_qn);
                total_recall += pipeline_merge_batch(
                    buf[prev_buf_idx].recvbuf, sz, prev_batch_qn,
                    local_k, k, prev_q_start, gt, gd, dummy);
                double t_merge1 = MPI_Wtime();
                batch_merge_us = (t_merge1 - t_merge0) * 1e6;
            }
        }
        timing.batch_wait_us[bi] = batch_wait_us;
        timing.batch_merge_us[bi] = batch_merge_us;

        prev_buf_idx = cur_buf_idx;
    }

    // ---- 收尾: 等待并 merge 最后一个 batch ----
    if (prev_buf_idx >= 0 && buf[prev_buf_idx].in_flight)
    {
        double t_wait0 = MPI_Wtime();
        MPI_Wait(&buf[prev_buf_idx].request, MPI_STATUS_IGNORE);
        double t_wait1 = MPI_Wtime();
        buf[prev_buf_idx].in_flight = false;

        if (rank == 0)
        {
            size_t last_bi = (size_t)(num_batches - 1);
            size_t last_q_start = last_bi * batch_qn;
            size_t last_q_end = std::min(last_q_start + batch_qn, qn);
            size_t last_batch_qn = last_q_end - last_q_start;
            std::vector<double> dummy(last_batch_qn);
            total_recall += pipeline_merge_batch(
                buf[prev_buf_idx].recvbuf, sz, last_batch_qn,
                local_k, k, last_q_start, gt, gd, dummy);
        }
        // 合并最后一个 batch 的 wait 和 merge 到 timing
        if (num_batches > 0)
        {
            timing.batch_wait_us[num_batches - 1] += (t_wait1 - t_wait0) * 1e6;
        }
    }

    double wall_t1 = MPI_Wtime();
    timing.wall_us = (wall_t1 - wall_t0) * 1e6;

    // ---- 汇总统计 ----
    timing.total_search_us = 0.0;
    timing.total_gather_us = 0.0;
    timing.total_merge_us = 0.0;
    for (int bi = 0; bi < num_batches; ++bi)
    {
        timing.total_search_us += timing.batch_search_us[bi];
        timing.total_gather_us += timing.batch_wait_us[bi];
        timing.total_merge_us += timing.batch_merge_us[bi];
    }

    // 计算重叠指标
    // 串行时间 = search + gather + merge
    // 流水线 wall time = max(search_active, gather_active) + merge
    // 重叠部分 = serial - wall
    double serial_total = timing.total_search_us + timing.total_gather_us + timing.total_merge_us;
    timing.overlap_search_us = std::max(0.0, serial_total - timing.wall_us);
    timing.overlap_ratio = serial_total > 0 ? timing.overlap_search_us / serial_total : 0.0;
    timing.pipeline_speedup = timing.wall_us > 0 ? serial_total / timing.wall_us : 1.0;
}
