#include <algorithm>
#include <chrono>
#include <cstdint>
#include <cstdlib>
#include <cstring>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <limits>
#include <queue>
#include <set>
#include <string>
#include <vector>
#include <mpi.h>
#ifdef _OPENMP
#include <omp.h>
#else
static inline void omp_set_dynamic(int) {}
static inline void omp_set_num_threads(int) {}
static inline int omp_get_thread_num() { return 0; }
#endif
#include "../ivf_pq.h"

int main(int argc, char **argv)
{
    MPI_Init(&argc, &argv);
    int rank, sz;
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
    MPI_Comm_size(MPI_COMM_WORLD, &sz);
    srand(42 + rank);

    // ---- data loading (rank 0) ----
    size_t tn = 0, dim = 0, qn = 0, gd = 0;
    float *ab = nullptr, *qu = nullptr;
    int *gt = nullptr;
    if (rank == 0)
    {
        std::string dp = "/anndata/";
        qu = load_fbin_like<float>(dp + "DEEP100K.query.fbin", qn, dim);
        ab = load_fbin_like<float>(dp + "DEEP100K.base.100k.fbin", tn, dim);
        gt = load_fbin_like<int>(dp + "DEEP100K.gt.query.100k.top100.bin", qn, gd);
        qn = 2000;
    }

    MPI_Bcast(&tn, 1, MPI_UNSIGNED_LONG_LONG, 0, MPI_COMM_WORLD);
    MPI_Bcast(&dim, 1, MPI_UNSIGNED_LONG_LONG, 0, MPI_COMM_WORLD);
    MPI_Bcast(&qn, 1, MPI_UNSIGNED_LONG_LONG, 0, MPI_COMM_WORLD);
    MPI_Bcast(&gd, 1, MPI_UNSIGNED_LONG_LONG, 0, MPI_COMM_WORLD);

    // ---- equal-chunk scatter ----
    size_t ln = tn / sz, rm = tn % sz;
    std::vector<int> sc(sz), ds(sz);
    size_t off = 0;
    for (int i = 0; i < sz; ++i)
    {
        size_t ni = ln + (size_t)(i < (int)rm ? 1 : 0);
        sc[i] = (int)(ni * dim);
        ds[i] = (int)(off * dim);
        off += ni;
    }

    size_t mn = ln + (size_t)(rank < (int)rm ? 1 : 0);
    std::vector<float> lb(mn * dim);
    MPI_Scatterv(ab, sc.data(), ds.data(), MPI_FLOAT, lb.data(), (int)(mn * dim), MPI_FLOAT, 0, MPI_COMM_WORLD);
    int goff = (int)(ds[rank] / dim);

    // ---- parameters ----
    const int K = env_i("ANN_K", 200), M = 4, Kpq = 256;
    const size_t k = 10;
    const size_t cand_k = std::max((size_t)env_i("ANN_CAND_PER_RANK", 384), k);
    const size_t local_k = std::max((size_t)env_i("ANN_LOCAL_K", 20), k);
    const int nth_req = std::max(1, env_i("ANN_OMP_THREADS", env_i("ANN_NTHREADS", 8 / sz)));
    const bool build_only = env_i("ANN_BUILD_ONLY", 0) != 0;
    const bool use_prebuilt = env_i("ANN_USE_PREBUILT", 1) != 0;
    const int nth =
#ifdef _OPENMP
        nth_req;
#else
        1;
#endif

    MPI_Barrier(MPI_COMM_WORLD);
    double tb0 = MPI_Wtime();

    // ---- train / load global index (rank 0) ----
    std::vector<float> cent, cb_SoA;
    std::vector<uint8_t> codes_all;
    std::vector<int> assign_all;
    int index_mode = 0;
    if (rank == 0)
    {
        const std::string p_cent = ivf_pq_cent_path(K, dim);
        const std::string p_cb = ivf_pq_cb_path(K, M, Kpq, dim);
        const std::string p_codes = ivf_pq_codes_path(K, M, Kpq, tn);
        const std::string p_assign = ivf_pq_assign_path(K, dim, tn);
        bool loaded = false;
        if (use_prebuilt && file_exists(p_cent) && file_exists(p_cb) && file_exists(p_codes) && file_exists(p_assign))
        {
            loaded = ivf_pq_load_vec_bin<float>(p_cent, cent) &&
                     ivf_pq_load_vec_bin<float>(p_cb, cb_SoA) &&
                     ivf_pq_load_vec_bin<uint8_t>(p_codes, codes_all) &&
                     ivf_pq_load_vec_bin<int>(p_assign, assign_all);
        }

        if (!loaded)
        {
            ivf_pq_train_ivf(ab, tn, dim, K, cent, 12);
            codes_all.resize(tn * M);
            ivf_pq_train_encode_soa(ab, tn, dim, M, Kpq, cb_SoA, codes_all.data(), 6);
            ivf_pq_compute_ivf_assign(ab, tn, dim, K, cent, assign_all);
            ivf_pq_save_vec_bin<float>(p_cent, cent);
            ivf_pq_save_vec_bin<float>(p_cb, cb_SoA);
            ivf_pq_save_vec_bin<uint8_t>(p_codes, codes_all);
            ivf_pq_save_vec_bin<int>(p_assign, assign_all);
            index_mode = 0;
        }
        else
        {
            index_mode = 1;
        }
    }

    MPI_Bcast(&index_mode, 1, MPI_INT, 0, MPI_COMM_WORLD);

    if (build_only)
    {
        double tb1_build = MPI_Wtime();
        if (rank == 0)
        {
            std::cout << "[IVFPQ-OMP] build only finished"
                      << " index_mode=" << (index_mode ? "load" : "train")
                      << " K=" << K << " M=" << M << " Kpq=" << Kpq
                      << " build_ms=" << (tb1_build - tb0) * 1e3 << "\n";
        }
        if (rank == 0)
            delete[] ab;
        delete[] qu;
        delete[] gt;
        MPI_Finalize();
        return 0;
    }

    bcast_vector_f32(cent, rank);
    bcast_vector_f32(cb_SoA, rank);

    // ---- scatter codes & assign ----
    std::vector<uint8_t> codes(mn * M);
    std::vector<int> local_assign(mn);
    {
        std::vector<int> scc(sz), dsc(sz);
        size_t o2 = 0;
        for (int i = 0; i < sz; ++i)
        {
            size_t ni = ln + (size_t)(i < (int)rm ? 1 : 0);
            scc[i] = (int)(ni * M);
            dsc[i] = (int)(o2 * M);
            o2 += ni;
        }
        MPI_Scatterv(rank == 0 ? codes_all.data() : nullptr, scc.data(), dsc.data(), MPI_UNSIGNED_CHAR,
                     codes.data(), (int)(mn * M), MPI_UNSIGNED_CHAR, 0, MPI_COMM_WORLD);

        std::vector<int> scc_assign(sz), dsc_assign(sz);
        size_t o3 = 0;
        for (int i = 0; i < sz; ++i)
        {
            size_t ni = ln + (size_t)(i < (int)rm ? 1 : 0);
            scc_assign[i] = (int)ni;
            dsc_assign[i] = (int)o3;
            o3 += ni;
        }
        MPI_Scatterv(rank == 0 ? assign_all.data() : nullptr, scc_assign.data(), dsc_assign.data(), MPI_INT,
                     local_assign.data(), (int)mn, MPI_INT, 0, MPI_COMM_WORLD);
    }

    auto lists = ivf_pq_build_ivf_from_assign(local_assign, K);
    double tb1 = MPI_Wtime();

    // ---- build stats ----
    double local_build_ms = (tb1 - tb0) * 1e3;
    double build_min_ms = 0.0, build_max_ms = 0.0, build_sum_ms = 0.0;
    double local_points_f = static_cast<double>(mn);
    double points_min = 0.0, points_max = 0.0, points_sum = 0.0;
    MPI_Reduce(&local_build_ms, &build_min_ms, 1, MPI_DOUBLE, MPI_MIN, 0, MPI_COMM_WORLD);
    MPI_Reduce(&local_build_ms, &build_max_ms, 1, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD);
    MPI_Reduce(&local_build_ms, &build_sum_ms, 1, MPI_DOUBLE, MPI_SUM, 0, MPI_COMM_WORLD);
    MPI_Reduce(&local_points_f, &points_min, 1, MPI_DOUBLE, MPI_MIN, 0, MPI_COMM_WORLD);
    MPI_Reduce(&local_points_f, &points_max, 1, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD);
    MPI_Reduce(&local_points_f, &points_sum, 1, MPI_DOUBLE, MPI_SUM, 0, MPI_COMM_WORLD);

    // ---- broadcast queries & ground truth ----
    if (rank != 0)
    {
        qu = new float[qn * dim];
        gt = new int[qn * gd];
    }
    MPI_Bcast(qu, (int)(qn * dim), MPI_FLOAT, 0, MPI_COMM_WORLD);
    MPI_Bcast(gt, (int)(qn * gd), MPI_INT, 0, MPI_COMM_WORLD);

    if (rank == 0)
        std::cout << "[IVFPQ-OMP] MPI=" << sz << " omp=" << nth << " K=" << K
                  << " workers=" << sz * nth
                  << " pq_pool/rank=" << cand_k << " local_k=" << local_k
                  << " index_mode=" << (index_mode ? "load" : "train")
                  << " build_ms[min/avg/max]=" << build_min_ms << "/"
                  << (build_sum_ms / sz) << "/" << build_max_ms
                  << " points[min/avg/max]=" << (int)points_min << "/"
                  << (int)(points_sum / sz) << "/" << (int)points_max << "\n";

    // ---- search benchmark (multiple nprobe values) ----
    int default_np[] = {10, 12, 14};
    int one_np = env_i("ANN_NP_ONLY", 0);
    std::vector<int> nps;
    if (one_np > 0)
        nps.push_back(one_np);
    else
        nps.assign(default_np, default_np + sizeof(default_np) / sizeof(default_np[0]));

    const float invalid = std::numeric_limits<float>::infinity();
    for (int np : nps)
    {
        std::vector<std::vector<std::pair<float, int>>> lr(qn);
        std::vector<double> query_us(qn, 0.0);
        std::vector<IvfPqThreadStat> thread_stats((size_t)nth);

        MPI_Barrier(MPI_COMM_WORLD);
        double ts = MPI_Wtime();
        omp_set_dynamic(0);
        omp_set_num_threads(nth);
#pragma omp parallel for schedule(dynamic, 8)
        for (int qi = 0; qi < (int)qn; ++qi)
        {
            int tid = omp_get_thread_num();
            auto t0 = std::chrono::steady_clock::now();
            ivf_pq_search_local_rerank(lb.data(), codes.data(), cent, lists, cb_SoA,
                                        qu + (size_t)qi * dim, dim, M, Kpq, np,
                                        cand_k, local_k, goff, lr[(size_t)qi]);
            auto t1 = std::chrono::steady_clock::now();
            double us = std::chrono::duration<double, std::micro>(t1 - t0).count();
            query_us[(size_t)qi] = us;
            thread_stats[(size_t)tid].tasks += 1;
            thread_stats[(size_t)tid].work_us += us;
        }
        double tscan = MPI_Wtime();

        // ---- pack send buffer ----
        std::vector<float> send(qn * local_k * 2, 0.0f);
        for (size_t qi = 0; qi < qn; ++qi)
        {
            size_t base = qi * local_k * 2;
            for (size_t j = 0; j < local_k; ++j)
            {
                if (j < lr[qi].size())
                {
                    send[base + j * 2] = lr[qi][j].first;
                    send[base + j * 2 + 1] = (float)lr[qi][j].second;
                }
                else
                {
                    send[base + j * 2] = invalid;
                    send[base + j * 2 + 1] = -1.0f;
                }
            }
        }

        int send_count = (int)send.size();
        std::vector<float> all;
        if (rank == 0)
            all.resize((size_t)sz * send.size());
        MPI_Gather(send.data(), send_count, MPI_FLOAT,
                   rank == 0 ? all.data() : nullptr, send_count, MPI_FLOAT,
                   0, MPI_COMM_WORLD);

        double tgather = MPI_Wtime();
        double local_search_ms = (tscan - ts) * 1e3;
        double local_gather_ms = (tgather - tscan) * 1e3;
        double local_merge_ms = 0.0;
        double local_total_ms = (tgather - ts) * 1e3;

        // ---- merge & recall (rank 0) ----
        double total_recall = 0.0;
        if (rank == 0)
        {
            double tm0 = MPI_Wtime();
            for (size_t qi = 0; qi < qn; ++qi)
            {
                Heap fine;
                for (int r = 0; r < sz; ++r)
                {
                    size_t base = ((size_t)r * qn + qi) * local_k * 2;
                    for (size_t j = 0; j < local_k; ++j)
                    {
                        int id = (int)all[base + j * 2 + 1];
                        if (id >= 0)
                            hp(fine, all[base + j * 2], id, k);
                    }
                }

                std::set<int> gs(gt + qi * gd, gt + qi * gd + k);
                size_t hit = 0;
                Heap tmp = fine;
                while (!tmp.empty())
                {
                    if (gs.count(tmp.top().second))
                        ++hit;
                    tmp.pop();
                }
                total_recall += (float)hit / k;
            }
            double tm1 = MPI_Wtime();
            local_merge_ms = (tm1 - tm0) * 1e3;
            local_total_ms = (tm1 - ts) * 1e3;
        }

        // ---- reduce timing stats ----
        double search_min_ms = 0.0, search_max_ms = 0.0, search_sum_ms = 0.0;
        double gather_min_ms = 0.0, gather_max_ms = 0.0, gather_sum_ms = 0.0;
        double merge_min_ms = 0.0, merge_max_ms = 0.0, merge_sum_ms = 0.0;
        double total_min_ms = 0.0, total_max_ms = 0.0, total_sum_ms = 0.0;
        MPI_Reduce(&local_search_ms, &search_min_ms, 1, MPI_DOUBLE, MPI_MIN, 0, MPI_COMM_WORLD);
        MPI_Reduce(&local_search_ms, &search_max_ms, 1, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD);
        MPI_Reduce(&local_search_ms, &search_sum_ms, 1, MPI_DOUBLE, MPI_SUM, 0, MPI_COMM_WORLD);
        MPI_Reduce(&local_gather_ms, &gather_min_ms, 1, MPI_DOUBLE, MPI_MIN, 0, MPI_COMM_WORLD);
        MPI_Reduce(&local_gather_ms, &gather_max_ms, 1, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD);
        MPI_Reduce(&local_gather_ms, &gather_sum_ms, 1, MPI_DOUBLE, MPI_SUM, 0, MPI_COMM_WORLD);
        MPI_Reduce(&local_merge_ms, &merge_min_ms, 1, MPI_DOUBLE, MPI_MIN, 0, MPI_COMM_WORLD);
        MPI_Reduce(&local_merge_ms, &merge_max_ms, 1, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD);
        MPI_Reduce(&local_merge_ms, &merge_sum_ms, 1, MPI_DOUBLE, MPI_SUM, 0, MPI_COMM_WORLD);
        MPI_Reduce(&local_total_ms, &total_min_ms, 1, MPI_DOUBLE, MPI_MIN, 0, MPI_COMM_WORLD);
        MPI_Reduce(&local_total_ms, &total_max_ms, 1, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD);
        MPI_Reduce(&local_total_ms, &total_sum_ms, 1, MPI_DOUBLE, MPI_SUM, 0, MPI_COMM_WORLD);

        // ---- reduce query latency stats ----
        double local_qavg_us = 0.0;
        double local_qmax_us = 0.0;
        for (double v : query_us)
        {
            local_qavg_us += v;
            local_qmax_us = std::max(local_qmax_us, v);
        }
        local_qavg_us /= (double)qn;

        double qavg_min_us = 0.0, qavg_max_us = 0.0, qavg_sum_us = 0.0;
        double qmax_us = 0.0;
        MPI_Reduce(&local_qavg_us, &qavg_min_us, 1, MPI_DOUBLE, MPI_MIN, 0, MPI_COMM_WORLD);
        MPI_Reduce(&local_qavg_us, &qavg_max_us, 1, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD);
        MPI_Reduce(&local_qavg_us, &qavg_sum_us, 1, MPI_DOUBLE, MPI_SUM, 0, MPI_COMM_WORLD);
        MPI_Reduce(&local_qmax_us, &qmax_us, 1, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD);

        // ---- rank 0 output ----
        if (rank == 0)
        {
            std::vector<size_t> rank0_tasks((size_t)nth);
            std::vector<double> rank0_work_us((size_t)nth);
            for (int t = 0; t < nth; ++t)
            {
                rank0_tasks[(size_t)t] = thread_stats[(size_t)t].tasks;
                rank0_work_us[(size_t)t] = thread_stats[(size_t)t].work_us;
            }

            size_t tasks_min = *std::min_element(rank0_tasks.begin(), rank0_tasks.end());
            size_t tasks_max = *std::max_element(rank0_tasks.begin(), rank0_tasks.end());
            double tasks_avg = 0.0;
            for (size_t v : rank0_tasks)
                tasks_avg += (double)v;
            tasks_avg /= (double)nth;

            double work_min = *std::min_element(rank0_work_us.begin(), rank0_work_us.end());
            double work_max = *std::max_element(rank0_work_us.begin(), rank0_work_us.end());
            double work_avg = 0.0;
            for (double v : rank0_work_us)
                work_avg += v;
            work_avg /= (double)nth;

            std::cout << "[IVFPQ-OMP] np=" << np
                      << " avg_lat=" << (local_total_ms * 1e3 / qn) << " us"
                      << " recall=" << (total_recall / qn)
                      << " search_ms[min/avg/max]=" << search_min_ms << "/"
                      << (search_sum_ms / sz) << "/" << search_max_ms
                      << " gather_ms[min/avg/max]=" << gather_min_ms << "/"
                      << (gather_sum_ms / sz) << "/" << gather_max_ms
                      << " merge_ms[min/avg/max]=" << merge_min_ms << "/"
                      << (merge_sum_ms / sz) << "/" << merge_max_ms
                      << " total_ms[min/avg/max]=" << total_min_ms << "/"
                      << (total_sum_ms / sz) << "/" << total_max_ms
                      << " qavg_us[min/avg/max]=" << qavg_min_us << "/"
                      << (qavg_sum_us / sz) << "/" << qavg_max_us
                      << " qmax_us=" << qmax_us << "\n";

            std::cout << "[IVFPQ-OMP] rank0_query_us p50/p95/p99/max="
                      << percentile_us(query_us, 0.50) << "/"
                      << percentile_us(query_us, 0.95) << "/"
                      << percentile_us(query_us, 0.99) << "/"
                      << *std::max_element(query_us.begin(), query_us.end())
                      << " rank0_thread_tasks min/avg/max="
                      << tasks_min << "/" << tasks_avg << "/" << tasks_max
                      << " rank0_thread_work_us min/avg/max="
                      << work_min << "/" << work_avg << "/" << work_max
                      << "\n";

            for (int t = 0; t < nth; ++t)
            {
                std::cout << "[IVFPQ-OMP] rank0_thread[" << t << "] tasks="
                          << thread_stats[(size_t)t].tasks
                          << " work_us=" << thread_stats[(size_t)t].work_us
                          << "\n";
            }
        }
    }

    if (rank == 0)
        delete[] ab;
    delete[] qu;
    delete[] gt;
    MPI_Finalize();
    return 0;
}
