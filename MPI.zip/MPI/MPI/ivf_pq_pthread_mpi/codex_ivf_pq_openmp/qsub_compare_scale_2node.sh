#!/bin/sh
#PBS -N ivfpq_omp_cmp16
#PBS -e test.e
#PBS -o test.o
#PBS -l nodes=2:ppn=8

set -eu

ANN_DIR=/home/${USER}/ann
BIN=/home/${USER}/main
OUT_DIR=/home/${USER}/analysis_out_ivfpq_omp
OUT_FILE=${OUT_DIR}/ivfpq_omp_scale_2node.txt

mkdir -p "$OUT_DIR"

export ANN_NP_ONLY=${ANN_NP_ONLY:-13}
export ANN_CAND_PER_RANK=${ANN_CAND_PER_RANK:-352}
export ANN_LOCAL_K=${ANN_LOCAL_K:-12}
export ANN_USE_PREBUILT=${ANN_USE_PREBUILT:-1}

FILES_DIR=/home/${USER}/files

NODES=$(cat "$PBS_NODEFILE" | sort | uniq)
for node in $NODES; do
    scp master_ubss1:${ANN_DIR}/main "${node}:${BIN}" 1>&2
    ssh "${node}" "mkdir -p '${FILES_DIR}'" 1>&2 || true
    scp -r master_ubss1:${ANN_DIR}/files "${node}:/home/${USER}/" 1>&2 || true
done

: > "$OUT_FILE"
echo "============================================================" | tee -a "$OUT_FILE"
echo " IVF-PQ OpenMP scale compare | 2 nodes x 8 ppn | total workers = 16" | tee -a "$OUT_FILE"
echo " Params: np=$ANN_NP_ONLY pq_pool=$ANN_CAND_PER_RANK local_k=$ANN_LOCAL_K" | tee -a "$OUT_FILE"
echo "============================================================" | tee -a "$OUT_FILE"

for combo in "16:1" "8:2" "4:4" "2:8"; do
    NP=${combo%:*}
    NTH=${combo#*:}
    echo "" | tee -a "$OUT_FILE"
    echo "[CASE] MPI=${NP} omp=${NTH} workers=$((NP * NTH))" | tee -a "$OUT_FILE"
    export ANN_OMP_THREADS="$NTH"
    /usr/local/bin/mpiexec -np "$NP" -machinefile "$PBS_NODEFILE" "$BIN" 2>&1 | tee -a "$OUT_FILE"
done

scp "$OUT_FILE" master_ubss1:${ANN_DIR}/ 2>&1 || true
