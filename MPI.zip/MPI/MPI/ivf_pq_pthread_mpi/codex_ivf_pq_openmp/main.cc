// Codex IVF-PQ MPI+OpenMP, low-latency local-rerank variant.
// Compile: mpic++ main.cc -o main -O2 -fopenmp -std=c++17 -I../..

#include <algorithm>
#include <chrono>
#include <cstdint>
#include <cstdlib>
#include <cstring>
#include <fstream>
#include <iostream>
#include <limits>
#include <queue>
#include <set>
#include <string>
#include <vector>
#include <mpi.h>
#ifdef _OPENMP
#include <omp.h>
#else
static inline void omp_set_dynamic(int) {}
static inline void omp_set_num_threads(int) {}
static inline int omp_get_thread_num() { return 0; }
#endif
#if defined(__aarch64__) || defined(__ARM_NEON)
#include <arm_neon.h>
#endif
#include "hnswlib/hnswlib/simd_utils.h"

struct IVFList
{
    std::vector<int> ids;
};

using Heap = std::priority_queue<std::pair<float, int>>;

static inline void hp(Heap &h, float d, int id, size_t k)
{
    if (h.size() < k)
        h.push({d, id});
    else if (d < h.top().first)
    {
        h.pop();
        h.push({d, id});
    }
}

static inline int env_i(const char *name, int defv)
{
    const char *s = std::getenv(name);
    if (!s || !*s)
        return defv;
    int v = std::atoi(s);
    return v > 0 ? v : defv;
}

static inline std::string env_s(const char *name, const std::string &defv)
{
    const char *s = std::getenv(name);
    return (s && *s) ? std::string(s) : defv;
}

static inline std::string files_dir()
{
    return env_s("ANN_FILES_DIR", "files");
}

static inline std::string files_path(const std::string &name)
{
    std::string dir = files_dir();
    if (!dir.empty() && (dir.back() == '/' || dir.back() == '\\'))
        return dir + name;
    return dir + "/" + name;
}

template <typename T>
static inline void save_vec_bin(const std::string &path, const std::vector<T> &v)
{
    std::ofstream out(path, std::ios::binary);
    size_t n = v.size();
    out.write(reinterpret_cast<const char *>(&n), sizeof(n));
    if (n)
        out.write(reinterpret_cast<const char *>(v.data()), static_cast<std::streamsize>(n * sizeof(T)));
}

template <typename T>
static inline bool load_vec_bin(const std::string &path, std::vector<T> &v)
{
    std::ifstream in(path, std::ios::binary);
    if (!in)
        return false;
    size_t n = 0;
    in.read(reinterpret_cast<char *>(&n), sizeof(n));
    v.resize(n);
    if (n)
        in.read(reinterpret_cast<char *>(v.data()), static_cast<std::streamsize>(n * sizeof(T)));
    return true;
}

static inline bool file_exists(const std::string &path)
{
    std::ifstream in(path, std::ios::binary);
    return in.good();
}

static inline std::string cent_path(int K, size_t dim)
{
    return files_path("codex_ivfpq_cent_K" + std::to_string(K) + "_d" + std::to_string(dim) + ".bin");
}

static inline std::string cb_path(int K, int M, int Kpq, size_t dim)
{
    return files_path("codex_ivfpq_cb_K" + std::to_string(K) + "_M" + std::to_string(M) +
                      "_Kpq" + std::to_string(Kpq) + "_d" + std::to_string(dim) + ".bin");
}

static inline std::string codes_path(int K, int M, int Kpq, size_t n)
{
    return files_path("codex_ivfpq_codes_K" + std::to_string(K) + "_M" + std::to_string(M) +
                      "_Kpq" + std::to_string(Kpq) + "_n" + std::to_string(n) + ".bin");
}

static inline std::string assign_path(int K, size_t dim, size_t n)
{
    return files_path("codex_ivfpq_assign_K" + std::to_string(K) + "_d" + std::to_string(dim) +
                      "_n" + std::to_string(n) + ".bin");
}

static inline double percentile_us(std::vector<double> v, double p)
{
    if (v.empty())
        return 0.0;
    std::sort(v.begin(), v.end());
    size_t idx = static_cast<size_t>(p * static_cast<double>(v.size() - 1));
    return v[idx];
}

template <typename T>
static T *ld(const std::string &p, size_t &n, size_t &d)
{
    std::ifstream f(p, std::ios::binary);
    if (!f)
        return nullptr;
    int32_t h[2];
    f.read((char *)h, 8);
    n = h[0];
    d = h[1];
    T *dt = new T[n * d];
    f.read((char *)dt, n * d * sizeof(T));
    return dt;
}

static inline void bcast_v(std::vector<float> &v, int rank)
{
    size_t sz = v.size();
    MPI_Bcast(&sz, 1, MPI_UNSIGNED_LONG_LONG, 0, MPI_COMM_WORLD);
    if (rank != 0)
        v.resize(sz);
    if (sz)
        MPI_Bcast(v.data(), (int)sz, MPI_FLOAT, 0, MPI_COMM_WORLD);
}

static inline void train_ivf(const float *b, size_t n, size_t d, int K, std::vector<float> &cent, int it = 12)
{
    cent.resize((size_t)K * d);
    for (int k = 0; k < K; ++k)
    {
        int ri = rand() % n;
        std::memcpy(cent.data() + (size_t)k * d, b + (size_t)ri * d, d * sizeof(float));
    }

    std::vector<int> as(n);
    std::vector<float> nc((size_t)K * d);
    std::vector<int> cn(K);
    for (int t = 0; t < it; ++t)
    {
        for (size_t i = 0; i < n; ++i)
        {
            float best = 1e30f;
            int bk = 0;
            const float *v = b + i * d;
            for (int k = 0; k < K; ++k)
            {
                float dist = 0.0f;
                const float *c = cent.data() + (size_t)k * d;
                for (size_t j = 0; j < d; ++j)
                {
                    float df = v[j] - c[j];
                    dist += df * df;
                }
                if (dist < best)
                {
                    best = dist;
                    bk = k;
                }
            }
            as[i] = bk;
        }

        std::fill(nc.begin(), nc.end(), 0.0f);
        std::fill(cn.begin(), cn.end(), 0);
        for (size_t i = 0; i < n; ++i)
        {
            int k = as[i];
            ++cn[k];
            const float *v = b + i * d;
            for (size_t j = 0; j < d; ++j)
                nc[(size_t)k * d + j] += v[j];
        }
        for (int k = 0; k < K; ++k)
            if (cn[k] > 0)
                for (size_t j = 0; j < d; ++j)
                    cent[(size_t)k * d + j] = nc[(size_t)k * d + j] / cn[k];
    }
}

static inline std::vector<IVFList> build_ivf(const float *b, size_t n, size_t d, int K, const std::vector<float> &cent)
{
    std::vector<IVFList> lists(K);
    for (size_t i = 0; i < n; ++i)
    {
        float best = 1e30f;
        int bk = 0;
        const float *v = b + i * d;
        for (int k = 0; k < K; ++k)
        {
            float dist = 0.0f;
            const float *c = cent.data() + (size_t)k * d;
            for (size_t j = 0; j < d; ++j)
            {
                float df = v[j] - c[j];
                dist += df * df;
            }
            if (dist < best)
            {
                best = dist;
                bk = k;
            }
        }
        lists[bk].ids.push_back((int)i);
    }
    return lists;
}

static inline void compute_ivf_assign(const float *b, size_t n, size_t d, int K,
                                      const std::vector<float> &cent, std::vector<int> &assign)
{
    assign.resize(n);
    for (size_t i = 0; i < n; ++i)
    {
        float best = 1e30f;
        int bk = 0;
        const float *v = b + i * d;
        for (int k = 0; k < K; ++k)
        {
            float dist = 0.0f;
            const float *c = cent.data() + (size_t)k * d;
            for (size_t j = 0; j < d; ++j)
            {
                float df = v[j] - c[j];
                dist += df * df;
            }
            if (dist < best)
            {
                best = dist;
                bk = k;
            }
        }
        assign[i] = bk;
    }
}

static inline std::vector<IVFList> build_ivf_from_assign(const std::vector<int> &assign, int K)
{
    std::vector<IVFList> lists(K);
    for (size_t i = 0; i < assign.size(); ++i)
        lists[(size_t)assign[i]].ids.push_back((int)i);
    return lists;
}

static inline void pq_train_encode_soa(const float *b, size_t n, size_t d, int M, int Kpq,
                                       std::vector<float> &cb_SoA, uint8_t *codes, int it = 6)
{
    size_t ds = d / M;
    std::vector<float> ca((size_t)M * Kpq * ds);
    for (int m = 0; m < M; ++m)
    {
        float *cent = ca.data() + (size_t)m * Kpq * ds;
        for (int k = 0; k < Kpq; ++k)
        {
            int ri = rand() % n;
            std::memcpy(cent + (size_t)k * ds, b + (size_t)ri * d + (size_t)m * ds, ds * sizeof(float));
        }

        std::vector<int> as(n);
        std::vector<float> sm((size_t)Kpq * ds);
        std::vector<int> cn(Kpq);
        for (int t = 0; t < it; ++t)
        {
            for (size_t i = 0; i < n; ++i)
            {
                float best = 1e30f;
                int bk = 0;
                const float *sv = b + i * d + (size_t)m * ds;
                for (int k = 0; k < Kpq; ++k)
                {
                    float dist = 0.0f;
                    for (size_t j = 0; j < ds; ++j)
                    {
                        float df = sv[j] - cent[(size_t)k * ds + j];
                        dist += df * df;
                    }
                    if (dist < best)
                    {
                        best = dist;
                        bk = k;
                    }
                }
                as[i] = bk;
            }

            std::fill(sm.begin(), sm.end(), 0.0f);
            std::fill(cn.begin(), cn.end(), 0);
            for (size_t i = 0; i < n; ++i)
            {
                int k = as[i];
                ++cn[k];
                for (size_t j = 0; j < ds; ++j)
                    sm[(size_t)k * ds + j] += b[i * d + (size_t)m * ds + j];
            }
            for (int k = 0; k < Kpq; ++k)
                if (cn[k] > 0)
                    for (size_t j = 0; j < ds; ++j)
                        cent[(size_t)k * ds + j] = sm[(size_t)k * ds + j] / cn[k];
        }

        for (size_t i = 0; i < n; ++i)
        {
            float best = 1e30f;
            uint8_t bk = 0;
            const float *sv = b + i * d + (size_t)m * ds;
            for (int k = 0; k < Kpq; ++k)
            {
                float dist = 0.0f;
                for (size_t j = 0; j < ds; ++j)
                {
                    float df = sv[j] - cent[(size_t)k * ds + j];
                    dist += df * df;
                }
                if (dist < best)
                {
                    best = dist;
                    bk = (uint8_t)k;
                }
            }
            codes[i * M + m] = bk;
        }
    }

    cb_SoA.resize((size_t)M * Kpq * ds);
    for (int m = 0; m < M; ++m)
        for (int c = 0; c < Kpq; ++c)
            for (size_t dd = 0; dd < ds; ++dd)
                cb_SoA[(size_t)m * Kpq * ds + dd * Kpq + c] = ca[(size_t)m * Kpq * ds + (size_t)c * ds + dd];
}

static inline void search_local_rerank(const float *base, const uint8_t *codes, const std::vector<float> &cent,
                                       const std::vector<IVFList> &lists, const std::vector<float> &cb_SoA,
                                       const float *q, size_t d, int M, int Kpq, int np, size_t pq_pool,
                                       size_t local_k, int goff, std::vector<std::pair<float, int>> &out)
{
    size_t ds = d / M;
    int Kivf = (int)(cent.size() / d);
    np = std::min(np, Kivf);

    Heap coarse;
    for (int c = 0; c < Kivf; ++c)
        hp(coarse, InnerProductSIMDNeon(q, cent.data() + (size_t)c * d, d), c, np);

    std::vector<int> probes;
    probes.reserve(np);
    while (!coarse.empty())
    {
        probes.push_back(coarse.top().second);
        coarse.pop();
    }

    float lut[4 * 256];
    for (int m = 0; m < M; ++m)
    {
        const float *qs = q + (size_t)m * ds;
        const float *csa = cb_SoA.data() + (size_t)m * Kpq * ds;
        float *lm = lut + (size_t)m * Kpq;
        for (int c = 0; c < Kpq; c += 4)
        {
#if defined(__aarch64__) || defined(__ARM_NEON)
            float32x4_t s4 = vdupq_n_f32(0.0f);
            for (size_t j = 0; j < ds; ++j)
                s4 = vmlaq_f32(s4, vdupq_n_f32(qs[j]), vld1q_f32(csa + j * Kpq + c));
            vst1q_f32(lm + c, s4);
#else
            for (int cc = 0; cc < 4 && c + cc < Kpq; ++cc)
            {
                float dot = 0.0f;
                for (size_t j = 0; j < ds; ++j)
                    dot += qs[j] * csa[j * Kpq + c + cc];
                lm[c + cc] = dot;
            }
#endif
        }
    }

    Heap approx;
    for (int cid : probes)
    {
        for (int vi : lists[cid].ids)
        {
            const uint8_t *pq = codes + (size_t)vi * M;
            float dot = 0.0f;
            for (int m = 0; m < M; ++m)
                dot += lut[(size_t)m * Kpq + pq[m]];
            hp(approx, 1.0f - dot, vi, pq_pool);
        }
    }

    Heap fine;
    while (!approx.empty())
    {
        int local_id = approx.top().second;
        approx.pop();
        float dist = InnerProductSIMDNeon(q, base + (size_t)local_id * d, d);
        hp(fine, dist, local_id + goff, local_k);
    }

    out.clear();
    out.reserve(local_k);
    while (!fine.empty())
    {
        out.push_back(fine.top());
        fine.pop();
    }
}

struct ThreadStat
{
    double work_us = 0.0;
    size_t tasks = 0;
};

int main(int argc, char **argv)
{
    MPI_Init(&argc, &argv);
    int rank, sz;
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
    MPI_Comm_size(MPI_COMM_WORLD, &sz);
    srand(42 + rank);

    size_t tn = 0, dim = 0, qn = 0, gd = 0;
    float *ab = nullptr, *qu = nullptr;
    int *gt = nullptr;
    if (rank == 0)
    {
        std::string dp = "/anndata/";
        qu = ld<float>(dp + "DEEP100K.query.fbin", qn, dim);
        ab = ld<float>(dp + "DEEP100K.base.100k.fbin", tn, dim);
        gt = ld<int>(dp + "DEEP100K.gt.query.100k.top100.bin", qn, gd);
        qn = 2000;
    }

    MPI_Bcast(&tn, 1, MPI_UNSIGNED_LONG_LONG, 0, MPI_COMM_WORLD);
    MPI_Bcast(&dim, 1, MPI_UNSIGNED_LONG_LONG, 0, MPI_COMM_WORLD);
    MPI_Bcast(&qn, 1, MPI_UNSIGNED_LONG_LONG, 0, MPI_COMM_WORLD);
    MPI_Bcast(&gd, 1, MPI_UNSIGNED_LONG_LONG, 0, MPI_COMM_WORLD);

    size_t ln = tn / sz, rm = tn % sz;
    std::vector<int> sc(sz), ds(sz);
    size_t off = 0;
    for (int i = 0; i < sz; ++i)
    {
        size_t ni = ln + (size_t)(i < (int)rm ? 1 : 0);
        sc[i] = (int)(ni * dim);
        ds[i] = (int)(off * dim);
        off += ni;
    }

    size_t mn = ln + (size_t)(rank < (int)rm ? 1 : 0);
    std::vector<float> lb(mn * dim);
    MPI_Scatterv(ab, sc.data(), ds.data(), MPI_FLOAT, lb.data(), (int)(mn * dim), MPI_FLOAT, 0, MPI_COMM_WORLD);
    int goff = (int)(ds[rank] / dim);

    const int K = env_i("ANN_K", 200), M = 4, Kpq = 256;
    const size_t k = 10;
    const size_t cand_k = std::max((size_t)env_i("ANN_CAND_PER_RANK", 384), k);
    const size_t local_k = std::max((size_t)env_i("ANN_LOCAL_K", 20), k);
    const int nth_req = std::max(1, env_i("ANN_OMP_THREADS", env_i("ANN_NTHREADS", 8 / sz)));
    const bool build_only = env_i("ANN_BUILD_ONLY", 0) != 0;
    const bool use_prebuilt = env_i("ANN_USE_PREBUILT", 1) != 0;
    const int nth =
#ifdef _OPENMP
        nth_req;
#else
        1;
#endif

    MPI_Barrier(MPI_COMM_WORLD);
    double tb0 = MPI_Wtime();

    std::vector<float> cent, cb_SoA;
    std::vector<uint8_t> codes_all;
    std::vector<int> assign_all;
    int index_mode = 0;
    if (rank == 0)
    {
        const std::string p_cent = cent_path(K, dim);
        const std::string p_cb = cb_path(K, M, Kpq, dim);
        const std::string p_codes = codes_path(K, M, Kpq, tn);
        const std::string p_assign = assign_path(K, dim, tn);
        bool loaded = false;
        if (use_prebuilt && file_exists(p_cent) && file_exists(p_cb) && file_exists(p_codes) && file_exists(p_assign))
        {
            loaded = load_vec_bin<float>(p_cent, cent) &&
                     load_vec_bin<float>(p_cb, cb_SoA) &&
                     load_vec_bin<uint8_t>(p_codes, codes_all) &&
                     load_vec_bin<int>(p_assign, assign_all);
        }

        if (!loaded)
        {
            train_ivf(ab, tn, dim, K, cent, 12);
            codes_all.resize(tn * M);
            pq_train_encode_soa(ab, tn, dim, M, Kpq, cb_SoA, codes_all.data(), 6);
            compute_ivf_assign(ab, tn, dim, K, cent, assign_all);
            save_vec_bin<float>(p_cent, cent);
            save_vec_bin<float>(p_cb, cb_SoA);
            save_vec_bin<uint8_t>(p_codes, codes_all);
            save_vec_bin<int>(p_assign, assign_all);
            index_mode = 0;
        }
        else
        {
            index_mode = 1;
        }
    }

    MPI_Bcast(&index_mode, 1, MPI_INT, 0, MPI_COMM_WORLD);

    if (build_only)
    {
        double tb1_build = MPI_Wtime();
        if (rank == 0)
        {
            std::cout << "[Codex-IVFPQ-OMP] build only finished"
                      << " index_mode=" << (index_mode ? "load" : "train")
                      << " K=" << K << " M=" << M << " Kpq=" << Kpq
                      << " build_ms=" << (tb1_build - tb0) * 1e3 << "\n";
        }
        if (rank == 0)
            delete[] ab;
        delete[] qu;
        delete[] gt;
        MPI_Finalize();
        return 0;
    }

    bcast_v(cent, rank);
    bcast_v(cb_SoA, rank);

    std::vector<uint8_t> codes(mn * M);
    std::vector<int> local_assign(mn);
    {
        std::vector<int> scc(sz), dsc(sz);
        size_t o2 = 0;
        for (int i = 0; i < sz; ++i)
        {
            size_t ni = ln + (size_t)(i < (int)rm ? 1 : 0);
            scc[i] = (int)(ni * M);
            dsc[i] = (int)(o2 * M);
            o2 += ni;
        }
        MPI_Scatterv(rank == 0 ? codes_all.data() : nullptr, scc.data(), dsc.data(), MPI_UNSIGNED_CHAR,
                     codes.data(), (int)(mn * M), MPI_UNSIGNED_CHAR, 0, MPI_COMM_WORLD);

        std::vector<int> scc_assign(sz), dsc_assign(sz);
        size_t o3 = 0;
        for (int i = 0; i < sz; ++i)
        {
            size_t ni = ln + (size_t)(i < (int)rm ? 1 : 0);
            scc_assign[i] = (int)ni;
            dsc_assign[i] = (int)o3;
            o3 += ni;
        }
        MPI_Scatterv(rank == 0 ? assign_all.data() : nullptr, scc_assign.data(), dsc_assign.data(), MPI_INT,
                     local_assign.data(), (int)mn, MPI_INT, 0, MPI_COMM_WORLD);
    }

    auto lists = build_ivf_from_assign(local_assign, K);
    double tb1 = MPI_Wtime();

    double local_build_ms = (tb1 - tb0) * 1e3;
    double build_min_ms = 0.0, build_max_ms = 0.0, build_sum_ms = 0.0;
    double local_points_f = static_cast<double>(mn);
    double points_min = 0.0, points_max = 0.0, points_sum = 0.0;
    MPI_Reduce(&local_build_ms, &build_min_ms, 1, MPI_DOUBLE, MPI_MIN, 0, MPI_COMM_WORLD);
    MPI_Reduce(&local_build_ms, &build_max_ms, 1, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD);
    MPI_Reduce(&local_build_ms, &build_sum_ms, 1, MPI_DOUBLE, MPI_SUM, 0, MPI_COMM_WORLD);
    MPI_Reduce(&local_points_f, &points_min, 1, MPI_DOUBLE, MPI_MIN, 0, MPI_COMM_WORLD);
    MPI_Reduce(&local_points_f, &points_max, 1, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD);
    MPI_Reduce(&local_points_f, &points_sum, 1, MPI_DOUBLE, MPI_SUM, 0, MPI_COMM_WORLD);

    if (rank != 0)
    {
        qu = new float[qn * dim];
        gt = new int[qn * gd];
    }
    MPI_Bcast(qu, (int)(qn * dim), MPI_FLOAT, 0, MPI_COMM_WORLD);
    MPI_Bcast(gt, (int)(qn * gd), MPI_INT, 0, MPI_COMM_WORLD);

    if (rank == 0)
        std::cout << "[Codex-IVFPQ-OMP] MPI=" << sz << " omp=" << nth << " K=" << K
                  << " workers=" << sz * nth
                  << " pq_pool/rank=" << cand_k << " local_k=" << local_k
                  << " index_mode=" << (index_mode ? "load" : "train")
                  << " build_ms[min/avg/max]=" << build_min_ms << "/"
                  << (build_sum_ms / sz) << "/" << build_max_ms
                  << " points[min/avg/max]=" << (int)points_min << "/"
                  << (int)(points_sum / sz) << "/" << (int)points_max << "\n";

    int default_np[] = {10, 12, 14};
    int one_np = env_i("ANN_NP_ONLY", 0);
    std::vector<int> nps;
    if (one_np > 0)
        nps.push_back(one_np);
    else
        nps.assign(default_np, default_np + sizeof(default_np) / sizeof(default_np[0]));

    const float invalid = std::numeric_limits<float>::infinity();
    for (int np : nps)
    {
        std::vector<std::vector<std::pair<float, int>>> lr(qn);
        std::vector<double> query_us(qn, 0.0);
        std::vector<ThreadStat> thread_stats((size_t)nth);

        MPI_Barrier(MPI_COMM_WORLD);
        double ts = MPI_Wtime();
        omp_set_dynamic(0);
        omp_set_num_threads(nth);
#pragma omp parallel for schedule(dynamic, 8)
        for (int qi = 0; qi < (int)qn; ++qi)
        {
            int tid = omp_get_thread_num();
            auto t0 = std::chrono::steady_clock::now();
            search_local_rerank(lb.data(), codes.data(), cent, lists, cb_SoA,
                                qu + (size_t)qi * dim, dim, M, Kpq, np,
                                cand_k, local_k, goff, lr[(size_t)qi]);
            auto t1 = std::chrono::steady_clock::now();
            double us = std::chrono::duration<double, std::micro>(t1 - t0).count();
            query_us[(size_t)qi] = us;
            thread_stats[(size_t)tid].tasks += 1;
            thread_stats[(size_t)tid].work_us += us;
        }
        double tscan = MPI_Wtime();

        std::vector<float> send(qn * local_k * 2, 0.0f);
        for (size_t qi = 0; qi < qn; ++qi)
        {
            size_t base = qi * local_k * 2;
            for (size_t j = 0; j < local_k; ++j)
            {
                if (j < lr[qi].size())
                {
                    send[base + j * 2] = lr[qi][j].first;
                    send[base + j * 2 + 1] = (float)lr[qi][j].second;
                }
                else
                {
                    send[base + j * 2] = invalid;
                    send[base + j * 2 + 1] = -1.0f;
                }
            }
        }

        int send_count = (int)send.size();
        std::vector<float> all;
        if (rank == 0)
            all.resize((size_t)sz * send.size());
        MPI_Gather(send.data(), send_count, MPI_FLOAT,
                   rank == 0 ? all.data() : nullptr, send_count, MPI_FLOAT,
                   0, MPI_COMM_WORLD);

        double tgather = MPI_Wtime();
        double local_search_ms = (tscan - ts) * 1e3;
        double local_gather_ms = (tgather - tscan) * 1e3;
        double local_merge_ms = 0.0;
        double local_total_ms = (tgather - ts) * 1e3;

        double total_recall = 0.0;
        if (rank == 0)
        {
            double tm0 = MPI_Wtime();
            for (size_t qi = 0; qi < qn; ++qi)
            {
                Heap fine;
                for (int r = 0; r < sz; ++r)
                {
                    size_t base = ((size_t)r * qn + qi) * local_k * 2;
                    for (size_t j = 0; j < local_k; ++j)
                    {
                        int id = (int)all[base + j * 2 + 1];
                        if (id >= 0)
                            hp(fine, all[base + j * 2], id, k);
                    }
                }

                std::set<int> gs(gt + qi * gd, gt + qi * gd + k);
                size_t hit = 0;
                Heap tmp = fine;
                while (!tmp.empty())
                {
                    if (gs.count(tmp.top().second))
                        ++hit;
                    tmp.pop();
                }
                total_recall += (float)hit / k;
            }
            double tm1 = MPI_Wtime();
            local_merge_ms = (tm1 - tm0) * 1e3;
            local_total_ms = (tm1 - ts) * 1e3;
        }

        double search_min_ms = 0.0, search_max_ms = 0.0, search_sum_ms = 0.0;
        double gather_min_ms = 0.0, gather_max_ms = 0.0, gather_sum_ms = 0.0;
        double merge_min_ms = 0.0, merge_max_ms = 0.0, merge_sum_ms = 0.0;
        double total_min_ms = 0.0, total_max_ms = 0.0, total_sum_ms = 0.0;
        MPI_Reduce(&local_search_ms, &search_min_ms, 1, MPI_DOUBLE, MPI_MIN, 0, MPI_COMM_WORLD);
        MPI_Reduce(&local_search_ms, &search_max_ms, 1, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD);
        MPI_Reduce(&local_search_ms, &search_sum_ms, 1, MPI_DOUBLE, MPI_SUM, 0, MPI_COMM_WORLD);
        MPI_Reduce(&local_gather_ms, &gather_min_ms, 1, MPI_DOUBLE, MPI_MIN, 0, MPI_COMM_WORLD);
        MPI_Reduce(&local_gather_ms, &gather_max_ms, 1, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD);
        MPI_Reduce(&local_gather_ms, &gather_sum_ms, 1, MPI_DOUBLE, MPI_SUM, 0, MPI_COMM_WORLD);
        MPI_Reduce(&local_merge_ms, &merge_min_ms, 1, MPI_DOUBLE, MPI_MIN, 0, MPI_COMM_WORLD);
        MPI_Reduce(&local_merge_ms, &merge_max_ms, 1, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD);
        MPI_Reduce(&local_merge_ms, &merge_sum_ms, 1, MPI_DOUBLE, MPI_SUM, 0, MPI_COMM_WORLD);
        MPI_Reduce(&local_total_ms, &total_min_ms, 1, MPI_DOUBLE, MPI_MIN, 0, MPI_COMM_WORLD);
        MPI_Reduce(&local_total_ms, &total_max_ms, 1, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD);
        MPI_Reduce(&local_total_ms, &total_sum_ms, 1, MPI_DOUBLE, MPI_SUM, 0, MPI_COMM_WORLD);

        double local_qavg_us = 0.0;
        double local_qmax_us = 0.0;
        for (double v : query_us)
        {
            local_qavg_us += v;
            local_qmax_us = std::max(local_qmax_us, v);
        }
        local_qavg_us /= (double)qn;

        double qavg_min_us = 0.0, qavg_max_us = 0.0, qavg_sum_us = 0.0;
        double qmax_us = 0.0;
        MPI_Reduce(&local_qavg_us, &qavg_min_us, 1, MPI_DOUBLE, MPI_MIN, 0, MPI_COMM_WORLD);
        MPI_Reduce(&local_qavg_us, &qavg_max_us, 1, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD);
        MPI_Reduce(&local_qavg_us, &qavg_sum_us, 1, MPI_DOUBLE, MPI_SUM, 0, MPI_COMM_WORLD);
        MPI_Reduce(&local_qmax_us, &qmax_us, 1, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD);

        if (rank == 0)
        {
            std::vector<size_t> rank0_tasks((size_t)nth);
            std::vector<double> rank0_work_us((size_t)nth);
            for (int t = 0; t < nth; ++t)
            {
                rank0_tasks[(size_t)t] = thread_stats[(size_t)t].tasks;
                rank0_work_us[(size_t)t] = thread_stats[(size_t)t].work_us;
            }

            size_t tasks_min = *std::min_element(rank0_tasks.begin(), rank0_tasks.end());
            size_t tasks_max = *std::max_element(rank0_tasks.begin(), rank0_tasks.end());
            double tasks_avg = 0.0;
            for (size_t v : rank0_tasks)
                tasks_avg += (double)v;
            tasks_avg /= (double)nth;

            double work_min = *std::min_element(rank0_work_us.begin(), rank0_work_us.end());
            double work_max = *std::max_element(rank0_work_us.begin(), rank0_work_us.end());
            double work_avg = 0.0;
            for (double v : rank0_work_us)
                work_avg += v;
            work_avg /= (double)nth;

            std::cout << "[Codex-IVFPQ-OMP] np=" << np
                      << " avg_lat=" << (local_total_ms * 1e3 / qn) << " us"
                      << " recall=" << (total_recall / qn)
                      << " search_ms[min/avg/max]=" << search_min_ms << "/"
                      << (search_sum_ms / sz) << "/" << search_max_ms
                      << " gather_ms[min/avg/max]=" << gather_min_ms << "/"
                      << (gather_sum_ms / sz) << "/" << gather_max_ms
                      << " merge_ms[min/avg/max]=" << merge_min_ms << "/"
                      << (merge_sum_ms / sz) << "/" << merge_max_ms
                      << " total_ms[min/avg/max]=" << total_min_ms << "/"
                      << (total_sum_ms / sz) << "/" << total_max_ms
                      << " qavg_us[min/avg/max]=" << qavg_min_us << "/"
                      << (qavg_sum_us / sz) << "/" << qavg_max_us
                      << " qmax_us=" << qmax_us << "\n";

            std::cout << "[Codex-IVFPQ-OMP] rank0_query_us p50/p95/p99/max="
                      << percentile_us(query_us, 0.50) << "/"
                      << percentile_us(query_us, 0.95) << "/"
                      << percentile_us(query_us, 0.99) << "/"
                      << *std::max_element(query_us.begin(), query_us.end())
                      << " rank0_thread_tasks min/avg/max="
                      << tasks_min << "/" << tasks_avg << "/" << tasks_max
                      << " rank0_thread_work_us min/avg/max="
                      << work_min << "/" << work_avg << "/" << work_max
                      << "\n";

            for (int t = 0; t < nth; ++t)
            {
                std::cout << "[Codex-IVFPQ-OMP] rank0_thread[" << t << "] tasks="
                          << thread_stats[(size_t)t].tasks
                          << " work_us=" << thread_stats[(size_t)t].work_us
                          << "\n";
            }
        }
    }

    if (rank == 0)
        delete[] ab;
    delete[] qu;
    delete[] gt;
    MPI_Finalize();
    return 0;
}
