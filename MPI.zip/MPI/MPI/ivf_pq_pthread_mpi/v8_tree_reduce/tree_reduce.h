#pragma once
// ============================================================================
// v8: Distributed Tree Reduce + Cache Locality
//
// 设计目标:
//   (A) 分布式 merge: 用 MPI_Alltoallv 替代 MPI_Gather, 每个 rank 负责 merge 一部分
//       query, 消除 rank 0 的单点内存/计算瓶颈。
//       原来: 所有 rank → rank 0 (集中式, rank 0 O(sz×local_k) merge)
//       现在: 每 rank → 负责 qn/sz 个 query 的 merge (分布式, 每 rank O(local_k) merge)
//
//   (B) 查询聚类重排序: 按 primary probe cluster 对 query 分组, 同 cluster 的 query
//       连续处理, 提升 LUT 和 IVFList 数据的 L1/L2 cache 命中率。
//       原来: query 顺序 = 输入顺序 (随机 probe 分布)
//       现在: query 顺序 = 按 primary probe 聚类 (局部性优化)
//
// 关键测量指标:
//   - merge_ms 在 sz=2/4/8 下的缩放 (分布式的优势随 sz 增大)
//   - cache locality: 对比重排序前后的 search_us
//   - Alltoallv 通信量 vs Gather 通信量
// ============================================================================

#include <algorithm>
#include <chrono>
#include <cstring>
#include <iomanip>
#include <iostream>
#include <limits>
#include <mpi.h>
#include <numeric>
#include <queue>
#include <set>
#include <string>
#include <vector>
#include "../ivf_pq.h"

// ---- 查询聚类: 按 primary probe cluster 分组 ----
// 对每个 query 计算 top-1 probe cluster, 然后按 cluster id 排序
// 效果: 相同 cluster 的 query 连续处理 → LUT 和 IVFList 数据 cache 友好

struct ClusteredQuery
{
    size_t original_idx;
    int primary_probe;
};

static inline void cluster_queries(const float *queries, size_t qn, size_t d,
                                    const std::vector<float> &cent, int K,
                                    std::vector<ClusteredQuery> &clustered)
{
    clustered.resize(qn);
    for (size_t qi = 0; qi < qn; ++qi)
    {
        // 找最近的 centroid (primary probe)
        float best = 1e30f;
        int best_c = 0;
        for (int c = 0; c < K; ++c)
        {
            float dist = 0.0f;
            const float *q = queries + qi * d;
            const float *cc = cent.data() + (size_t)c * d;
            for (size_t j = 0; j < d; ++j)
            {
                float df = q[j] - cc[j];
                dist += df * df;
            }
            if (dist < best) { best = dist; best_c = c; }
        }
        clustered[qi].original_idx = qi;
        clustered[qi].primary_probe = best_c;
    }

    // 按 primary_probe 排序 (稳定排序保持同 cluster 内的原始接近顺序)
    std::stable_sort(clustered.begin(), clustered.end(),
                     [](const ClusteredQuery &a, const ClusteredQuery &b) {
                         return a.primary_probe < b.primary_probe;
                     });
}

// ---- 分布式 merge: 每个 rank 负责一部分 query ----
// 使用 Alltoallv 而非 Gather:
//   - 每个 rank 搜索全部 qn 个 query (本地搜索)
//   - 每 rank 负责 merge query 范围 [rank*qn/sz, (rank+1)*qn/sz)
//   - Alltoallv: rank_i 把 query_j 的结果发给负责 query_j 的 rank
//   - 每个 rank 独立 merge 自己负责的 query, 计算 partial recall
//   - MPI_Reduce 汇总 recall

struct TreeReduceConfig
{
    int rank, sz;
    size_t qn, local_k, k;
    size_t my_q_start, my_q_end, my_qn; // 本 rank 负责 merge 的 query 范围
};

static inline void tree_reduce_init(TreeReduceConfig &cfg, int rank, int sz,
                                     size_t qn, size_t local_k, size_t k)
{
    cfg.rank = rank;
    cfg.sz = sz;
    cfg.qn = qn;
    cfg.local_k = local_k;
    cfg.k = k;
    size_t per_rank = (qn + sz - 1) / sz;
    cfg.my_q_start = (size_t)rank * per_rank;
    cfg.my_q_end = std::min(cfg.my_q_start + per_rank, qn);
    cfg.my_qn = cfg.my_q_end - cfg.my_q_start;
}

// ---- 构建 Alltoallv 调度 ----
// send_counts[r] = 本 rank 要发给 rank r 的结果数 (每 query local_k*2 个 float)
// recv_counts[r] = 本 rank 要从 rank r 接收的结果数

static inline void tree_reduce_build_schedule(const TreeReduceConfig &cfg,
                                               std::vector<int> &send_counts,
                                               std::vector<int> &send_displs,
                                               std::vector<int> &recv_counts,
                                               std::vector<int> &recv_displs)
{
    int sz = cfg.sz;
    size_t local_k = cfg.local_k;
    send_counts.assign(sz, 0);
    recv_counts.assign(sz, 0);

    // 每 rank 负责的 query 范围固定, 计算 Alltoallv 的发送/接收量
    size_t per_rank = (cfg.qn + sz - 1) / sz;

    for (int r = 0; r < sz; ++r)
    {
        // rank r 负责 merge queries [r*per_rank, (r+1)*per_rank)
        size_t r_start = (size_t)r * per_rank;
        size_t r_end = std::min(r_start + per_rank, cfg.qn);
        size_t r_qn = r_end - r_start;

        // 本 rank (cfg.rank) 要给 rank r 发 r_qn * local_k * 2 个 float
        send_counts[r] = (int)(r_qn * local_k * 2);
        recv_counts[r] = (int)(cfg.my_qn * local_k * 2);
    }

    send_displs.resize(sz);
    recv_displs.resize(sz);
    send_displs[0] = 0;
    recv_displs[0] = 0;
    for (int i = 1; i < sz; ++i)
    {
        send_displs[i] = send_displs[i - 1] + send_counts[i - 1];
        recv_displs[i] = recv_displs[i - 1] + recv_counts[i - 1];
    }
}

// ---- 分布式搜索 + tree reduce merge ----
// 每个 rank 搜索全部 query, 然后通过 Alltoallv 分发结果,
// 每个 rank 独立 merge 自己的 query 子集

static inline void tree_reduce_search_all(
    const float *base, const uint8_t *codes,
    const std::vector<float> &cent, const std::vector<IvfPqIVFList> &lists,
    const std::vector<float> &cb_SoA,
    const float *queries, size_t qn, size_t d,
    int M, int Kpq, int np, size_t cand_k, size_t local_k, int goff,
    const int *gt, size_t gd, size_t k,
    int rank, int sz,
    double &total_recall, double &search_us, double &alltoall_us, double &merge_us)
{
    const float invalid = std::numeric_limits<float>::infinity();
    TreeReduceConfig cfg;
    tree_reduce_init(cfg, rank, sz, qn, local_k, k);

    // ---- Phase 1: 本地搜索全部 query ----
    MPI_Barrier(MPI_COMM_WORLD);
    double t_s0 = MPI_Wtime();
    std::vector<std::vector<std::pair<float, int>>> local_results(qn);
    for (size_t qi = 0; qi < qn; ++qi)
    {
        ivf_pq_search_local_rerank(base, codes, cent, lists, cb_SoA,
                                    queries + qi * d, d, M, Kpq, np,
                                    cand_k, local_k, goff, local_results[qi]);
    }
    double t_s1 = MPI_Wtime();
    search_us = (t_s1 - t_s0) * 1e6;

    // ---- Phase 2: 打包发送缓冲 (按目标 rank 组织) ----
    std::vector<int> send_counts, send_displs, recv_counts, recv_displs;
    tree_reduce_build_schedule(cfg, send_counts, send_displs, recv_counts, recv_displs);

    int send_total = send_displs[sz - 1] + send_counts[sz - 1];
    int recv_total = recv_displs[sz - 1] + recv_counts[sz - 1];
    std::vector<float> sendbuf(send_total, invalid);
    std::vector<float> recvbuf(recv_total);

    // 按目标 rank 填充 sendbuf: 每个 query 的结果写到负责它的 rank 的槽位
    size_t per_rank = (qn + sz - 1) / sz;
    std::vector<int> cur_pos(sz, 0);
    for (int r = 0; r < sz; ++r)
        cur_pos[r] = send_displs[r];

    for (size_t qi = 0; qi < qn; ++qi)
    {
        int target_rank = (int)(qi / per_rank); // 负责 merge 这个 query 的 rank
        int pos = cur_pos[target_rank];
        for (size_t j = 0; j < local_k; ++j)
        {
            if (j < local_results[qi].size())
            {
                sendbuf[(size_t)pos + j * 2] = local_results[qi][j].first;
                sendbuf[(size_t)pos + j * 2 + 1] = (float)local_results[qi][j].second;
            }
            else
            {
                sendbuf[(size_t)pos + j * 2] = invalid;
                sendbuf[(size_t)pos + j * 2 + 1] = -1.0f;
            }
        }
        cur_pos[target_rank] += (int)(local_k * 2);
    }

    // ---- Phase 3: Alltoallv 交换 ----
    double t_a0 = MPI_Wtime();
    MPI_Alltoallv(sendbuf.data(), send_counts.data(), send_displs.data(), MPI_FLOAT,
                  recvbuf.data(), recv_counts.data(), recv_displs.data(), MPI_FLOAT,
                  MPI_COMM_WORLD);
    double t_a1 = MPI_Wtime();
    alltoall_us = (t_a1 - t_a0) * 1e6;

    // ---- Phase 4: 每个 rank merge 自己负责的 query ----
    double t_m0 = MPI_Wtime();
    double partial_recall = 0.0;
    for (size_t qi_local = 0; qi_local < cfg.my_qn; ++qi_local)
    {
        size_t qi = cfg.my_q_start + qi_local;
        Heap g;
        // 从所有 sz 个 rank 的数据中合并
        for (int r = 0; r < sz; ++r)
        {
            // rank r 发来的数据在 recvbuf 中的起始位置
            size_t r_section_start = (size_t)recv_displs[r];
            size_t r_query_stride = local_k * 2;
            size_t r_offset = r_section_start + qi_local * r_query_stride;
            for (size_t j = 0; j < local_k; ++j)
            {
                int id = (int)recvbuf[r_offset + j * 2 + 1];
                if (id >= 0 && recvbuf[r_offset + j * 2] < 1e29f)
                    hp(g, recvbuf[r_offset + j * 2], id, k);
            }
        }

        std::set<int> gs(gt + qi * gd, gt + qi * gd + k);
        size_t hit = 0;
        Heap tmp = g;
        while (!tmp.empty())
        {
            if (gs.count(tmp.top().second)) ++hit;
            tmp.pop();
        }
        partial_recall += (double)hit / k;
    }
    double t_m1 = MPI_Wtime();
    merge_us = (t_m1 - t_m0) * 1e6;

    // ---- Phase 5: Reduce 汇总 recall ----
    double global_recall = 0.0;
    MPI_Reduce(&partial_recall, &global_recall, 1, MPI_DOUBLE, MPI_SUM, 0, MPI_COMM_WORLD);
    total_recall = global_recall;
}

// ---- 带 cache locality 优化的搜索 ----
// 先聚类 query, 然后按 cluster 顺序搜索
// 额外返回 locality 指标

struct CacheLocalityStats
{
    double search_us = 0.0;
    double clustering_us = 0.0;
    size_t cluster_switches = 0;    // probe cluster 切换次数 (越少 locality 越好)
    double avg_queries_per_cluster = 0.0;
};

static inline void search_with_cache_locality(
    const float *base, const uint8_t *codes,
    const std::vector<float> &cent, const std::vector<IvfPqIVFList> &lists,
    const std::vector<float> &cb_SoA,
    const float *queries, size_t qn, size_t d,
    int M, int Kpq, int np, size_t cand_k, size_t local_k, int goff,
    CacheLocalityStats &stats,
    std::vector<std::vector<std::pair<float, int>>> &out_results)
{
    // Step 1: 聚类 (额外开销, 但可摊销)
    double t_c0 = MPI_Wtime();
    std::vector<ClusteredQuery> clustered;
    int K = (int)(cent.size() / d);
    cluster_queries(queries, qn, d, cent, K, clustered);
    double t_c1 = MPI_Wtime();
    stats.clustering_us = (t_c1 - t_c0) * 1e6;
    stats.cluster_switches = 0;

    // Step 2: 按 cluster 顺序搜索
    double t_s0 = MPI_Wtime();
    out_results.resize(qn);
    int prev_probe = -1;
    size_t queries_in_current_cluster = 0;
    std::vector<size_t> cluster_counts;

    for (size_t i = 0; i < qn; ++i)
    {
        size_t orig_idx = clustered[i].original_idx;
        int cur_probe = clustered[i].primary_probe;

        if (cur_probe != prev_probe)
        {
            if (prev_probe >= 0)
            {
                stats.cluster_switches++;
                cluster_counts.push_back(queries_in_current_cluster);
            }
            prev_probe = cur_probe;
            queries_in_current_cluster = 0;
        }
        queries_in_current_cluster++;

        ivf_pq_search_local_rerank(base, codes, cent, lists, cb_SoA,
                                    queries + orig_idx * d, d, M, Kpq, np,
                                    cand_k, local_k, goff, out_results[orig_idx]);
    }
    if (queries_in_current_cluster > 0)
    {
        stats.cluster_switches++;
        cluster_counts.push_back(queries_in_current_cluster);
    }
    double t_s1 = MPI_Wtime();
    stats.search_us = (t_s1 - t_s0) * 1e6;
    stats.avg_queries_per_cluster = cluster_counts.empty() ? 0.0 :
        (double)qn / (double)cluster_counts.size();
}
