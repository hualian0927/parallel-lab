// ============================================================================
// v8: Distributed Tree Reduce + Cache Locality — 测试入口
// 编译: mpic++ main.cc -o main -O2 -std=c++17 -I../..
//
// 实验设计 (对比 3 种模式):
//
//   Mode A: Baseline (Gather to rank 0, 无重排序)
//     search → pack → MPI_Gather → rank_0_merge
//
//   Mode B: Tree Reduce (Alltoallv, 无重排序)
//     search → pack → MPI_Alltoallv → per_rank_merge → MPI_Reduce(recall)
//
//   Mode C: Tree Reduce + Cache Locality (Alltoallv + query 聚类)
//     cluster_queries → search(reordered) → pack → Alltoallv → merge → Reduce
//
// 分析维度:
//   1. merge_ms 随 sz 的缩放: Baseline O(sz×local_k) vs Tree O(local_k)
//   2. Alltoallv 通信量 vs Gather 通信量
//   3. Cache locality: cluster_switches vs queries_per_cluster → search_us 变化
//   4. 聚类开销 (clustering_us) vs 搜索节省
// ============================================================================

#include <algorithm>
#include <chrono>
#include <cstdlib>
#include <cstring>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <limits>
#include <queue>
#include <set>
#include <string>
#include <vector>
#include <mpi.h>
#include "tree_reduce.h"

int main(int argc, char **argv)
{
    MPI_Init(&argc, &argv);
    int rank, sz;
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
    MPI_Comm_size(MPI_COMM_WORLD, &sz);
    srand(42 + rank);

    // ---- 数据加载 ----
    size_t tn = 0, dim = 0, qn = 0, gd = 0;
    float *ab = nullptr, *qu = nullptr;
    int *gt = nullptr;
    if (rank == 0)
    {
        std::string dp = "/anndata/";
        qu = load_fbin_like<float>(dp + "DEEP100K.query.fbin", qn, dim);
        ab = load_fbin_like<float>(dp + "DEEP100K.base.100k.fbin", tn, dim);
        gt = load_fbin_like<int>(dp + "DEEP100K.gt.query.100k.top100.bin", qn, gd);
        qn = 2000;
    }

    MPI_Bcast(&tn, 1, MPI_UNSIGNED_LONG_LONG, 0, MPI_COMM_WORLD);
    MPI_Bcast(&dim, 1, MPI_UNSIGNED_LONG_LONG, 0, MPI_COMM_WORLD);
    MPI_Bcast(&qn, 1, MPI_UNSIGNED_LONG_LONG, 0, MPI_COMM_WORLD);
    MPI_Bcast(&gd, 1, MPI_UNSIGNED_LONG_LONG, 0, MPI_COMM_WORLD);

    // ---- 等块分发 ----
    size_t ln = tn / sz, rm = tn % sz;
    std::vector<int> sc(sz), ds(sz);
    size_t off = 0;
    for (int i = 0; i < sz; ++i)
    {
        size_t ni = ln + (size_t)(i < (int)rm ? 1 : 0);
        sc[i] = (int)(ni * dim);
        ds[i] = (int)(off * dim);
        off += ni;
    }
    size_t mn = ln + (size_t)(rank < (int)rm ? 1 : 0);
    std::vector<float> lb(mn * dim);
    MPI_Scatterv(ab, sc.data(), ds.data(), MPI_FLOAT, lb.data(), (int)(mn * dim), MPI_FLOAT, 0, MPI_COMM_WORLD);
    int goff = (int)(ds[rank] / dim);

    // ---- 参数 ----
    const int K = env_i("ANN_K", 200), M = 4, Kpq = 256;
    const size_t k = 10;
    const size_t cand_k = std::max((size_t)env_i("ANN_CAND_PER_RANK", 384), k);
    const size_t local_k = std::max((size_t)env_i("ANN_LOCAL_K", 20), k);
    const bool build_only = env_i("ANN_BUILD_ONLY", 0) != 0;
    const bool use_prebuilt = env_i("ANN_USE_PREBUILT", 1) != 0;

    MPI_Barrier(MPI_COMM_WORLD);
    double tb0 = MPI_Wtime();

    // ---- 训练/加载索引 ----
    std::vector<float> cent, cb_SoA;
    std::vector<uint8_t> codes_all;
    std::vector<int> assign_all;
    int index_mode = 0;
    if (rank == 0)
    {
        const std::string p_cent = ivf_pq_cent_path(K, dim);
        const std::string p_cb = ivf_pq_cb_path(K, M, Kpq, dim);
        const std::string p_codes = ivf_pq_codes_path(K, M, Kpq, tn);
        const std::string p_assign = ivf_pq_assign_path(K, dim, tn);
        bool loaded = false;
        if (use_prebuilt && file_exists(p_cent) && file_exists(p_cb) && file_exists(p_codes) && file_exists(p_assign))
        {
            loaded = ivf_pq_load_vec_bin<float>(p_cent, cent) &&
                     ivf_pq_load_vec_bin<float>(p_cb, cb_SoA) &&
                     ivf_pq_load_vec_bin<uint8_t>(p_codes, codes_all) &&
                     ivf_pq_load_vec_bin<int>(p_assign, assign_all);
        }
        if (!loaded)
        {
            ivf_pq_train_ivf(ab, tn, dim, K, cent, 12);
            codes_all.resize(tn * M);
            ivf_pq_train_encode_soa(ab, tn, dim, M, Kpq, cb_SoA, codes_all.data(), 6);
            ivf_pq_compute_ivf_assign(ab, tn, dim, K, cent, assign_all);
            ivf_pq_save_vec_bin<float>(p_cent, cent);
            ivf_pq_save_vec_bin<float>(p_cb, cb_SoA);
            ivf_pq_save_vec_bin<uint8_t>(p_codes, codes_all);
            ivf_pq_save_vec_bin<int>(p_assign, assign_all);
            index_mode = 0;
        }
        else { index_mode = 1; }
    }
    MPI_Bcast(&index_mode, 1, MPI_INT, 0, MPI_COMM_WORLD);

    if (build_only)
    {
        if (rank == 0)
            std::cout << "[TREE-REDUCE] build only, index_mode=" << (index_mode ? "load" : "train") << "\n";
        if (rank == 0) delete[] ab;
        delete[] qu; delete[] gt;
        MPI_Finalize();
        return 0;
    }

    bcast_vector_f32(cent, rank);
    bcast_vector_f32(cb_SoA, rank);

    // ---- 分发 codes & assign ----
    std::vector<uint8_t> codes(mn * M);
    std::vector<int> local_assign(mn);
    {
        std::vector<int> scc(sz), dsc(sz);
        size_t o2 = 0;
        for (int i = 0; i < sz; ++i)
        {
            size_t ni = ln + (size_t)(i < (int)rm ? 1 : 0);
            scc[i] = (int)(ni * M); dsc[i] = (int)(o2 * M); o2 += ni;
        }
        MPI_Scatterv(rank == 0 ? codes_all.data() : nullptr, scc.data(), dsc.data(), MPI_UNSIGNED_CHAR,
                     codes.data(), (int)(mn * M), MPI_UNSIGNED_CHAR, 0, MPI_COMM_WORLD);
        std::vector<int> scc_a(sz), dsc_a(sz);
        size_t o3 = 0;
        for (int i = 0; i < sz; ++i)
        {
            size_t ni = ln + (size_t)(i < (int)rm ? 1 : 0);
            scc_a[i] = (int)ni; dsc_a[i] = (int)o3; o3 += ni;
        }
        MPI_Scatterv(rank == 0 ? assign_all.data() : nullptr, scc_a.data(), dsc_a.data(), MPI_INT,
                     local_assign.data(), (int)mn, MPI_INT, 0, MPI_COMM_WORLD);
    }

    auto lists = ivf_pq_build_ivf_from_assign(local_assign, K);

    if (rank == 0) delete[] ab;
    if (rank != 0) { qu = new float[qn * dim]; gt = new int[qn * gd]; }
    MPI_Bcast(qu, (int)(qn * dim), MPI_FLOAT, 0, MPI_COMM_WORLD);
    MPI_Bcast(gt, (int)(qn * gd), MPI_INT, 0, MPI_COMM_WORLD);

    if (rank == 0)
    {
        std::cout << std::fixed << std::setprecision(3)
                  << "[TREE-REDUCE] MPI=" << sz
                  << " K=" << K << " M=" << M << " Kpq=" << Kpq
                  << " cand_k=" << cand_k << " local_k=" << local_k
                  << " index_mode=" << (index_mode ? "load" : "train") << "\n";

        // 通信量分析 (rank 0 计算并输出)
        size_t gather_bytes = qn * local_k * 2 * (size_t)sz * sizeof(float);
        size_t alltoall_bytes = qn * local_k * 2 * sizeof(float); // 每 rank 收/发总量相同
        std::cout << "[TREE-REDUCE] comm_analysis:"
                  << " rank0_gather_recv=" << gather_bytes << "B"
                  << " alltoall_per_rank=" << alltoall_bytes << "B"
                  << " alltoall_total=" << (alltoall_bytes * sz) << "B"
                  << " ratio=" << ((double)alltoall_bytes * sz / (double)gather_bytes)
                  << "\n";
    }

    // ================================================================
    // 实验 1: Tree Reduce vs Baseline 对比
    // ================================================================
    int default_np[] = {10, 12, 14};

    for (int np : default_np)
    {
        MPI_Barrier(MPI_COMM_WORLD);

        // ---- Mode A: Baseline (Gather) ----
        const float invalid = std::numeric_limits<float>::infinity();
        double t_total0 = MPI_Wtime();

        // search
        std::vector<std::vector<std::pair<float, int>>> local_results(qn);
        for (size_t qi = 0; qi < qn; ++qi)
        {
            ivf_pq_search_local_rerank(lb.data(), codes.data(), cent, lists, cb_SoA,
                                        qu + qi * dim, dim, M, Kpq, np,
                                        cand_k, local_k, goff, local_results[qi]);
        }
        double t_search1 = MPI_Wtime();

        // pack
        std::vector<float> sendbuf(qn * local_k * 2);
        for (size_t qi = 0; qi < qn; ++qi)
        {
            size_t base = qi * local_k * 2;
            for (size_t j = 0; j < local_k; ++j)
            {
                if (j < local_results[qi].size())
                {
                    sendbuf[base + j * 2] = local_results[qi][j].first;
                    sendbuf[base + j * 2 + 1] = (float)local_results[qi][j].second;
                }
                else
                {
                    sendbuf[base + j * 2] = invalid;
                    sendbuf[base + j * 2 + 1] = -1.0f;
                }
            }
        }
        double t_pack1 = MPI_Wtime();

        // gather
        int send_count = (int)sendbuf.size();
        std::vector<float> gatherbuf;
        if (rank == 0) gatherbuf.resize((size_t)sz * sendbuf.size());
        MPI_Gather(sendbuf.data(), send_count, MPI_FLOAT,
                   rank == 0 ? gatherbuf.data() : nullptr, send_count, MPI_FLOAT,
                   0, MPI_COMM_WORLD);
        double t_gather1 = MPI_Wtime();

        // merge (rank 0 only)
        double baseline_recall = 0.0;
        if (rank == 0)
        {
            for (size_t qi = 0; qi < qn; ++qi)
            {
                Heap g;
                for (int r = 0; r < sz; ++r)
                {
                    size_t base = ((size_t)r * qn + qi) * local_k * 2;
                    for (size_t j = 0; j < local_k; ++j)
                    {
                        int id = (int)gatherbuf[base + j * 2 + 1];
                        if (id >= 0) hp(g, gatherbuf[base + j * 2], id, k);
                    }
                }
                baseline_recall += recall_of_heap(g, gt + qi * gd, k);
            }
        }
        double t_merge1 = MPI_Wtime();

        double baseline_search = (t_search1 - t_total0) * 1e3;
        double baseline_pack = (t_pack1 - t_search1) * 1e3;
        double baseline_gather = (t_gather1 - t_pack1) * 1e3;
        double baseline_merge = rank == 0 ? (t_merge1 - t_gather1) * 1e3 : 0.0;
        double baseline_total = (t_merge1 - t_total0) * 1e3;

        // ---- Mode B+C: Tree Reduce ----
        MPI_Barrier(MPI_COMM_WORLD);

        // B: 无 cache locality
        double recall_b = 0.0, search_us_b = 0.0, a2a_us_b = 0.0, merge_us_b = 0.0;
        tree_reduce_search_all(lb.data(), codes.data(), cent, lists, cb_SoA,
                                qu, qn, dim, M, Kpq, np, cand_k, local_k, goff,
                                gt, gd, k, rank, sz,
                                recall_b, search_us_b, a2a_us_b, merge_us_b);

        // C: 带 cache locality
        CacheLocalityStats loc_stats;
        std::vector<std::vector<std::pair<float, int>>> loc_results;
        search_with_cache_locality(lb.data(), codes.data(), cent, lists, cb_SoA,
                                    qu, qn, dim, M, Kpq, np, cand_k, local_k, goff,
                                    loc_stats, loc_results);

        double t_csearch_end = MPI_Wtime();

        // C merge: 用 tree reduce 合并重排序后的结果
        double recall_c = 0.0;
        {
            TreeReduceConfig cfg;
            tree_reduce_init(cfg, rank, sz, qn, local_k, k);

            std::vector<int> send_counts, send_displs, recv_counts, recv_displs;
            tree_reduce_build_schedule(cfg, send_counts, send_displs, recv_counts, recv_displs);

            int send_total = send_displs[sz - 1] + send_counts[sz - 1];
            int recv_total = recv_displs[sz - 1] + recv_counts[sz - 1];
            std::vector<float> sb_c(send_total, invalid);
            std::vector<float> rb_c(recv_total);

            size_t per_rank = (qn + sz - 1) / sz;
            std::vector<int> cur_pos(sz, 0);
            for (int r = 0; r < sz; ++r) cur_pos[r] = send_displs[r];

            for (size_t qi = 0; qi < qn; ++qi)
            {
                int target = (int)(qi / per_rank);
                int pos = cur_pos[target];
                for (size_t j = 0; j < local_k; ++j)
                {
                    if (j < loc_results[qi].size())
                    {
                        sb_c[(size_t)pos + j * 2] = loc_results[qi][j].first;
                        sb_c[(size_t)pos + j * 2 + 1] = (float)loc_results[qi][j].second;
                    }
                    else
                    {
                        sb_c[(size_t)pos + j * 2] = invalid;
                        sb_c[(size_t)pos + j * 2 + 1] = -1.0f;
                    }
                }
                cur_pos[target] += (int)(local_k * 2);
            }

            MPI_Alltoallv(sb_c.data(), send_counts.data(), send_displs.data(), MPI_FLOAT,
                          rb_c.data(), recv_counts.data(), recv_displs.data(), MPI_FLOAT,
                          MPI_COMM_WORLD);

            double partial_c = 0.0;
            for (size_t qi_local = 0; qi_local < cfg.my_qn; ++qi_local)
            {
                size_t qi = cfg.my_q_start + qi_local;
                Heap g;
                for (int r = 0; r < sz; ++r)
                {
                    size_t r_base = (size_t)recv_displs[r] + qi_local * local_k * 2;
                    for (size_t j = 0; j < local_k; ++j)
                    {
                        int id = (int)rb_c[r_base + j * 2 + 1];
                        if (id >= 0 && rb_c[r_base + j * 2] < 1e29f)
                            hp(g, rb_c[r_base + j * 2], id, k);
                    }
                }
                std::set<int> gs(gt + qi * gd, gt + qi * gd + k);
                size_t hit = 0;
                Heap tmp = g;
                while (!tmp.empty()) { if (gs.count(tmp.top().second)) ++hit; tmp.pop(); }
                partial_c += (double)hit / k;
            }
            MPI_Reduce(&partial_c, &recall_c, 1, MPI_DOUBLE, MPI_SUM, 0, MPI_COMM_WORLD);
        }

        // ---- 输出对比 ----
        if (rank == 0)
        {
            std::cout << std::fixed << std::setprecision(3)
                      << "[TREE-REDUCE] np=" << np
                      << "\n"
                      << "  Baseline: recall=" << (baseline_recall / qn)
                      << " total_ms=" << baseline_total
                      << " search_ms=" << baseline_search
                      << " pack_ms=" << baseline_pack
                      << " gather_ms=" << baseline_gather
                      << " merge_ms=" << baseline_merge
                      << "\n"
                      << "  TreeReduce: recall=" << (recall_b / qn)
                      << " search_us=" << search_us_b
                      << " alltoall_us=" << a2a_us_b
                      << " merge_us=" << merge_us_b
                      << "\n"
                      << "  TreeReduce+CL: recall=" << (recall_c / qn)
                      << " cluster_us=" << loc_stats.clustering_us
                      << " search_us=" << loc_stats.search_us
                      << " cluster_switches=" << loc_stats.cluster_switches
                      << " queries_per_cluster=" << loc_stats.avg_queries_per_cluster
                      << "\n";

            // 关键对比指标
            double merge_reduction = baseline_merge > 0 ?
                (double)merge_us_b / 1000.0 / baseline_merge : 0.0;
            double locality_effect = search_us_b > 0 ?
                loc_stats.search_us / search_us_b : 1.0;

            std::cout << std::fixed << std::setprecision(3)
                      << "  Analysis: merge_reduction_ratio=" << merge_reduction
                      << " (tree/baseline, <1 means tree reduce wins)"
                      << " locality_search_ratio=" << locality_effect
                      << " (<1 means cache locality helps)"
                      << " cluster_overhead_us=" << loc_stats.clustering_us
                      << "\n";
        }
    }

    delete[] qu; delete[] gt;
    MPI_Finalize();
    return 0;
}
