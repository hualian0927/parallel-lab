#!/bin/sh
#PBS -N codex_ivfpq_build
#PBS -e test.e
#PBS -o test.o
#PBS -l nodes=1:ppn=8

set -eu

ANN_DIR=/home/${USER}/ann
BIN=/home/${USER}/main
FILES_DIR=/home/${USER}/files

export ANN_BUILD_ONLY=1
export ANN_USE_PREBUILT=0

mkdir -p "$FILES_DIR"

NODES=$(cat $PBS_NODEFILE | sort | uniq)
for node in $NODES; do
    scp master_ubss1:${ANN_DIR}/main ${node}:${BIN} 1>&2
    ssh "${node}" "mkdir -p '${FILES_DIR}'" 1>&2 || true
done

/usr/local/bin/mpiexec -np 1 -machinefile $PBS_NODEFILE ${BIN}

scp -r ${FILES_DIR} master_ubss1:${ANN_DIR}/ 2>&1 || true
