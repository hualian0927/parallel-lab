#!/bin/sh
#PBS -N codex_ivfpq_h
#PBS -e test.e
#PBS -o test.o
#PBS -l nodes=4:ppn=8

export ANN_NP_ONLY=${ANN_NP_ONLY:-14}
export ANN_CAND_PER_RANK=${ANN_CAND_PER_RANK:-384}
export ANN_LOCAL_K=${ANN_LOCAL_K:-20}
export ANN_NTHREADS=${ANN_NTHREADS:-4}
export ANN_USE_PREBUILT=${ANN_USE_PREBUILT:-1}

FILES_DIR=/home/${USER}/files

NODES=$(cat $PBS_NODEFILE | sort | uniq)
for node in $NODES; do
    scp master_ubss1:/home/${USER}/ann/main ${node}:/home/${USER} 1>&2
    ssh "${node}" "mkdir -p '${FILES_DIR}'" 1>&2 || true
    scp -r master_ubss1:/home/${USER}/ann/files ${node}:/home/${USER}/ 1>&2 || true
done

/usr/local/bin/mpiexec -np 8 -machinefile $PBS_NODEFILE /home/${USER}/main
