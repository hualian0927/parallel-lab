# codex_ivf_pq_pthead

This version targets lower end-to-end latency for `recall@10 > 0.95`.

The main change is a local-rerank MPI merge:

1. each rank scans its local IVF-PQ shard and keeps a larger PQ candidate pool;
2. each rank exact-reranks only that local pool;
3. rank 0 merges the exact local top-k results.

This avoids the expensive V6 pattern where every rank exact-reranks `P=1000`
candidates for every query, but also avoids trusting PQ-only scores for final
global pruning.

Compile:

```sh
mpic++ main.cc -o main -O2 -lpthread -std=c++17 -I../..
```

Offline build:

```sh
qsub qsub_build.sh
```

Useful knobs:

```sh
export ANN_NP_ONLY=12          # or leave unset to sweep 10,12,14
export ANN_CAND_PER_RANK=384   # PQ pool exact-reranked by each rank
export ANN_LOCAL_K=12          # exact results sent by each rank per query
export ANN_NTHREADS=1
```

Scripts:

- `qsub_build.sh`: offline-build global IVF/PQ training artifacts into `files/`, so search runs can exclude training overhead.
- `qsub_mpi.sh`: 4 nodes, 32 MPI ranks, 1 thread per rank. This is the main low-latency run.
- `qsub_mpi_2node.sh`: 2 nodes, 16 MPI ranks, 1 thread per rank. This is the cheaper comparison run.
- `qsub_mpi_hybrid_8x4.sh`: 4 nodes, 8 MPI ranks, 4 pthreads per rank. Keep this for direct comparison against the hybrid layout.
- `qsub_mpi_fast_safe.sh`: 4 nodes, 32 MPI ranks, 1 thread, slightly more aggressive than the baseline.
- `qsub_mpi_fast.sh`: 4 nodes, 32 MPI ranks, 1 thread, most aggressive low-latency profile.
- `qsub_compare_scale_1node.sh`: compare `8x1`, `4x2`, `2x4`, `1x8` with fixed total workers = 8.
- `qsub_compare_scale_2node.sh`: compare `16x1`, `8x2`, `4x4`, `2x8` with fixed total workers = 16.

Runtime timing output now includes:

- `build_ms[min/avg/max]`: IVF/PQ train + scatter + local IVF build imbalance across ranks
- `points[min/avg/max]`: base-point imbalance across ranks
- `search_ms[min/avg/max]`: local rerank search stage across ranks
- `gather_ms[min/avg/max]`: one-shot MPI gather stage across ranks
- `merge_ms[min/avg/max]`: final rank0 top-k merge stage
- `total_ms[min/avg/max]`: end-to-end query stage across ranks
- `qavg_us[min/avg/max]`: average per-query local search time across ranks
- `rank0_query_us p50/p95/p99/max`: rank0 local query latency distribution
- `rank0_thread_tasks min/avg/max`: pthread task balance on rank0
- `rank0_thread_work_us min/avg/max`: pthread work-time balance on rank0

Index mode:

- `index_mode=train`: no prebuilt files were found, so training/encoding was done in this run
- `index_mode=load`: prebuilt files were loaded from `files/`, so offline training was excluded from the search run

Recommended order:

1. Run `qsub_mpi_2node.sh` and check whether recall stays above 0.95.
2. Run `qsub_mpi.sh` to see if 32 MPI ranks can pull total latency close to the target.
3. If recall drops, raise `ANN_LOCAL_K` from `12` to `16` before raising `ANN_CAND_PER_RANK`.
4. When recall margin is healthy, lower latency in this order: `ANN_NP_ONLY 14 -> 13`, then `ANN_CAND_PER_RANK 384 -> 352 -> 320`, then `ANN_LOCAL_K 12 -> 10`.
