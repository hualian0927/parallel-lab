# codex_hnsw_split_mpi

Score point:
- Split dataset into `P` parts, build one HNSW per part, search in parallel with MPI, then merge top-k.
- Use pthread inside each MPI rank for query-level parallel search.

Compile:

```sh
mpic++ main.cc -o main -O2 -std=c++17 -lpthread -I../..
```

Typical workflow:

```sh
cd ~/ann
mpic++ main.cc -o main -O2 -std=c++17 -lpthread
qsub qsub_build.sh
qsub qsub_search.sh
qsub qsub_compare_scale_1node.sh
qsub qsub_compare_scale_2node.sh
```

Useful knobs:

```sh
export ANN_MPI_NP=8
export ANN_PARTS=8
export ANN_PARTITION=block   # block or random
export ANN_M=16
export ANN_EFC=150
export ANN_EF=80
export ANN_LOCAL_K=24
export ANN_THREADS=2
export ANN_BUILD_ONLY=1
```

Files:
- `qsub_build.sh`: build offline indices with teacher-style MPI script
- `qsub_search.sh`: load/search with teacher-style MPI script
- `qsub_compare_scale_1node.sh`: `8x1`, `4x2`, `2x4`, `1x8`, fixed total workers = 8
- `qsub_compare_scale_2node.sh`: `16x1`, `8x2`, `4x4`, `2x8`, fixed total workers = 16
- `perf_mpi.sh`: perf stat + perf record wrapper
- `result`: fill in measured results

Path note:
- Index files are written to `ANN_FILES_DIR` when set.
- Login node source/binary path:
  - `~/ann/main.cc`
  - `~/ann/main`
- Compute node runtime path:
  - `/home/${USER}/main`
  - `/home/${USER}/files`
- The qsub scripts follow the teacher's MPI format:
  - scp `~/ann/main` from `master_ubss1` to each node
  - scp `~/ann/files` to `/home/${USER}/files`

Parameter rule:

```sh
np <= nodes * ppn, nodes <= 4, ppn <= 8
```

For the default scripts:

```sh
nodes = 2
ppn   = 8
np    = 8
ANN_THREADS = (nodes * ppn) / np = 2
```

Runtime timing output now includes:

- `build_ms[min/avg/max]`: offline index load/build imbalance across ranks
- `points[min/avg/max]`: point-count imbalance across ranks
- `parts_owned[min/avg/max]`: split-part ownership imbalance across ranks
- `search_ms[min/avg/max]`: local HNSW search stage across ranks
- `gather_ms[min/avg/max]`: one-shot MPI gather stage across ranks
- `merge_ms[min/avg/max]`: final rank0 top-k merge stage
- `total_ms[min/avg/max]`: end-to-end query stage across ranks
- `qavg_us[min/avg/max]`: average per-query local search time across ranks
- `rank0_query_us p50/p95/p99/max`: rank0 local query latency distribution
- `rank0_thread_tasks min/avg/max`: pthread task balance on rank0
- `rank0_thread_work_us min/avg/max`: pthread work-time balance on rank0

Suggested report-scale experiments:

- `qsub_compare_scale_1node.sh`
  - `8x1`, `4x2`, `2x4`, `1x8`
  - fixed total workers = 8
  - fixed parts = 8
- `qsub_compare_scale_2node.sh`
  - `16x1`, `8x2`, `4x4`, `2x8`
  - fixed total workers = 16
  - fixed parts = 16

This is useful for explaining:

- MPI process scaling vs pthread scaling
- whether more MPI ranks or more threads give better latency
- whether large local shards or communication dominate the runtime
