#!/bin/sh
#PBS -N hsplit_cmp8
#PBS -e test.e
#PBS -o test.o
#PBS -l nodes=1:ppn=8

set -eu

ANN_DIR=/home/${USER}/ann
FILES_DIR=/home/${USER}/files
BIN=/home/${USER}/main
OUT_DIR=/home/${USER}/analysis_out_hsplit
OUT_FILE=${OUT_DIR}/hsplit_scale_1node.txt

mkdir -p "$FILES_DIR" "$OUT_DIR"

export ANN_PARTS=${ANN_PARTS:-8}
export ANN_PARTITION=${ANN_PARTITION:-block}
export ANN_M=${ANN_M:-16}
export ANN_EFC=${ANN_EFC:-150}
export ANN_EF=${ANN_EF:-80}
export ANN_LOCAL_K=${ANN_LOCAL_K:-24}
export ANN_FILES_DIR="$FILES_DIR"

if ! ssh master_ubss1 "test -f '${ANN_DIR}/main'"; then
    echo "[ERR] ${ANN_DIR}/main not found on master_ubss1"
    echo "Compile first on login node:"
    echo "  cd ${ANN_DIR}"
    echo "  mpic++ main.cc -o main -O2 -std=c++17 -lpthread"
    exit 1
fi

NODES=$(cat "$PBS_NODEFILE" | sort | uniq)
for node in $NODES; do
    scp master_ubss1:${ANN_DIR}/main "${node}:${BIN}" 1>&2
    ssh "${node}" "mkdir -p '${FILES_DIR}'" 1>&2 || true
    scp -r master_ubss1:${ANN_DIR}/files "${node}:/home/${USER}/" 1>&2 || true
done

: > "$OUT_FILE"
echo "============================================================" | tee -a "$OUT_FILE"
echo " HNSW-Split scale compare | 1 node x 8 ppn | total workers = 8" | tee -a "$OUT_FILE"
echo " Params: parts=$ANN_PARTS ef=$ANN_EF local_k=$ANN_LOCAL_K partition=$ANN_PARTITION" | tee -a "$OUT_FILE"
echo "============================================================" | tee -a "$OUT_FILE"

for combo in "8:1" "4:2" "2:4" "1:8"; do
    NP=${combo%:*}
    NTH=${combo#*:}
    echo "" | tee -a "$OUT_FILE"
    echo "[CASE] MPI=${NP} pthread=${NTH} workers=$((NP * NTH))" | tee -a "$OUT_FILE"
    export ANN_THREADS="$NTH"
    /usr/local/bin/mpiexec -np "$NP" -machinefile "$PBS_NODEFILE" "$BIN" 2>&1 | tee -a "$OUT_FILE"
done

scp "$OUT_FILE" master_ubss1:${ANN_DIR}/ 2>&1 || true
