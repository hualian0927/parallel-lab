#!/bin/sh
#PBS -N codex_hsplit_search
#PBS -e test.e
#PBS -o test.o
#PBS -l nodes=2:ppn=8

set -eu

# Cluster rule:
#   np <= nodes * ppn, nodes <= 4, ppn <= 8
# For the current default:
#   nodes=2, ppn=8, np=8 => ANN_THREADS=(2*8)/8 = 2
NP=${ANN_MPI_NP:-8}
TOTAL_CORES=16
ANN_DIR=/home/${USER}/ann
FILES_DIR=/home/${USER}/files
BIN=/home/${USER}/main

mkdir -p "$FILES_DIR"
export ANN_PARTS=${ANN_PARTS:-$NP}
export ANN_PARTITION=${ANN_PARTITION:-block}
export ANN_M=${ANN_M:-16}
export ANN_EFC=${ANN_EFC:-150}
export ANN_EF=${ANN_EF:-80}
export ANN_LOCAL_K=${ANN_LOCAL_K:-24}
export ANN_THREADS=${ANN_THREADS:-$((TOTAL_CORES / NP))}
export ANN_FILES_DIR="$FILES_DIR"

NODES=$(cat "$PBS_NODEFILE" | sort | uniq)

if ! ssh master_ubss1 "test -f '${ANN_DIR}/main'"; then
    echo "[ERR] ${ANN_DIR}/main not found"
    echo "Compile first on login node:"
    echo "  cd ${ANN_DIR}"
    echo "  mpic++ main.cc -o main -O2 -std=c++17 -lpthread"
    exit 1
fi

for node in $NODES; do
    scp master_ubss1:${ANN_DIR}/main "${node}:${BIN}" 1>&2
    ssh "${node}" "mkdir -p '${FILES_DIR}'" 1>&2 || true
    scp -r master_ubss1:${ANN_DIR}/files "${node}:/home/${USER}/" 1>&2 || true
done

/usr/local/bin/mpiexec -np "$NP" -machinefile "$PBS_NODEFILE" "$BIN"
