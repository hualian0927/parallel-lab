#include <algorithm>
#include <atomic>
#include <chrono>
#include <cstdlib>
#include <iomanip>
#include <iostream>
#include <limits>
#include <memory>
#include <pthread.h>
#include <random>
#include <string>
#include <vector>
#include "hnswlib/hnswlib/hnswlib.h"
#include "../codex_graph_index_common/common.h"

using namespace hnswlib;

static inline int env_i(const char *name, int defv)
{
    const char *s = std::getenv(name);
    if (!s || !*s)
        return defv;
    int v = std::atoi(s);
    return v > 0 ? v : defv;
}

static inline double percentile_us(std::vector<double> v, double p)
{
    if (v.empty())
        return 0.0;
    std::sort(v.begin(), v.end());
    size_t idx = static_cast<size_t>(p * static_cast<double>(v.size() - 1));
    return v[idx];
}

struct PartIndex
{
    int part_id = -1;
    size_t count = 0;
    std::unique_ptr<HierarchicalNSW<float>> index;
};

struct ThreadStat
{
    double work_us = 0.0;
    size_t tasks = 0;
};

struct WorkerArg
{
    const std::vector<PartIndex> *part_indexes;
    const float *queries;
    size_t qn = 0;
    size_t dim = 0;
    size_t local_k = 0;
    std::atomic<size_t> *next = nullptr;
    std::vector<std::vector<MinPair>> *results = nullptr;
    std::vector<double> *query_us = nullptr;
    std::vector<ThreadStat> *stats = nullptr;
    int tid = 0;
};

static std::string part_index_path(int parts, const std::string &mode, int M, int efc, int part_id)
{
    return files_path("codex_hnsw_split_parts" + std::to_string(parts) +
                      "_" + mode + "_M" + std::to_string(M) +
                      "_efc" + std::to_string(efc) +
                      "_part" + std::to_string(part_id) + ".index");
}

static inline void search_one_local(const std::vector<PartIndex> &part_indexes,
                                    const float *query, size_t local_k,
                                    std::vector<MinPair> &out)
{
    Heap local_heap;
    for (const auto &part : part_indexes)
    {
        if (!part.index)
            continue;
        auto ret = part.index->searchKnn(query, local_k);
        while (!ret.empty())
        {
            hp(local_heap, ret.top().first, static_cast<int>(ret.top().second), local_k);
            ret.pop();
        }
    }

    out.clear();
    out.reserve(local_k);
    while (!local_heap.empty())
    {
        out.push_back(local_heap.top());
        local_heap.pop();
    }
}

static void *query_worker(void *arg)
{
    WorkerArg *a = static_cast<WorkerArg *>(arg);
    while (true)
    {
        size_t qi = a->next->fetch_add(1);
        if (qi >= a->qn)
            break;

        auto t0 = std::chrono::steady_clock::now();
        search_one_local(*a->part_indexes, a->queries + qi * a->dim, a->local_k, (*a->results)[qi]);
        auto t1 = std::chrono::steady_clock::now();
        double us = std::chrono::duration<double, std::micro>(t1 - t0).count();

        (*a->query_us)[qi] = us;
        (*a->stats)[(size_t)a->tid].tasks += 1;
        (*a->stats)[(size_t)a->tid].work_us += us;
    }
    return nullptr;
}

int main(int argc, char **argv)
{
    MPI_Init(&argc, &argv);
    int rank = 0, sz = 1;
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
    MPI_Comm_size(MPI_COMM_WORLD, &sz);

    size_t tn = 0, dim = 0, qn = 0, gd = 0;
    float *base = nullptr, *queries = nullptr;
    int *gt = nullptr;
    if (rank == 0)
    {
        std::string dp = "/anndata/";
        queries = load_fbin_like<float>(dp + "DEEP100K.query.fbin", qn, dim);
        base = load_fbin_like<float>(dp + "DEEP100K.base.100k.fbin", tn, dim);
        gt = load_fbin_like<int>(dp + "DEEP100K.gt.query.100k.top100.bin", qn, gd);
        qn = 2000;
    }

    MPI_Bcast(&tn, 1, MPI_UNSIGNED_LONG_LONG, 0, MPI_COMM_WORLD);
    MPI_Bcast(&dim, 1, MPI_UNSIGNED_LONG_LONG, 0, MPI_COMM_WORLD);
    MPI_Bcast(&qn, 1, MPI_UNSIGNED_LONG_LONG, 0, MPI_COMM_WORLD);
    MPI_Bcast(&gd, 1, MPI_UNSIGNED_LONG_LONG, 0, MPI_COMM_WORLD);

    const size_t k = 10;
    const int parts = std::max(1, env_i("ANN_PARTS", std::min(8, sz)));
    const int M = env_i("ANN_M", 16);
    const int efc = env_i("ANN_EFC", 150);
    const int ef = env_i("ANN_EF", 80);
    const int nth = std::max(1, env_i("ANN_THREADS", 1));
    const size_t local_k = std::max<size_t>(k, static_cast<size_t>(env_i("ANN_LOCAL_K", 24)));
    const bool build_only = env_i("ANN_BUILD_ONLY", 0) != 0;
    const std::string part_mode = std::getenv("ANN_PARTITION") ? std::getenv("ANN_PARTITION") : "block";

    std::vector<int> group_of_vec;
    std::vector<int> owner_of_group(parts);
    for (int p = 0; p < parts; ++p)
        owner_of_group[(size_t)p] = p % sz;

    if (rank == 0)
    {
        group_of_vec.resize(tn);
        if (part_mode == "random")
        {
            std::vector<int> perm(tn);
            for (size_t i = 0; i < tn; ++i)
                perm[i] = static_cast<int>(i);
            std::mt19937 rng(42);
            std::shuffle(perm.begin(), perm.end(), rng);
            for (size_t i = 0; i < tn; ++i)
                group_of_vec[(size_t)perm[i]] = static_cast<int>(i % parts);
        }
        else
        {
            for (size_t i = 0; i < tn; ++i)
                group_of_vec[i] = static_cast<int>((i * parts) / tn);
        }
    }
    bcast_vector_i32(group_of_vec, rank);

    std::vector<float> local_data;
    std::vector<int> local_ids, local_parts;
    scatter_grouped_vectors(base, tn, dim, group_of_vec, owner_of_group, rank, sz,
                            local_data, local_ids, local_parts);

    InnerProductSpace space(dim);
    std::vector<PartIndex> part_indexes(parts);
    std::vector<std::vector<int>> pos_by_part(parts);
    for (size_t i = 0; i < local_parts.size(); ++i)
        pos_by_part[(size_t)local_parts[i]].push_back(static_cast<int>(i));

    double tb0 = MPI_Wtime();
    int local_owned_parts = 0;
    for (int p = 0; p < parts; ++p)
    {
        if (owner_of_group[(size_t)p] != rank || pos_by_part[(size_t)p].empty())
            continue;
        std::string path = part_index_path(parts, part_mode, M, efc, p);
        part_indexes[(size_t)p].part_id = p;
        part_indexes[(size_t)p].count = pos_by_part[(size_t)p].size();
        if (file_exists(path))
        {
            part_indexes[(size_t)p].index.reset(new HierarchicalNSW<float>(&space, path));
        }
        else
        {
            auto idx = std::unique_ptr<HierarchicalNSW<float>>(new HierarchicalNSW<float>(&space, pos_by_part[(size_t)p].size(), M, efc));
            for (size_t j = 0; j < pos_by_part[(size_t)p].size(); ++j)
            {
                int pos = pos_by_part[(size_t)p][j];
                idx->addPoint(local_data.data() + (size_t)pos * dim, local_ids[(size_t)pos]);
            }
            idx->saveIndex(path);
            part_indexes[(size_t)p].index = std::move(idx);
        }
        part_indexes[(size_t)p].index->ef_ = ef;
        local_owned_parts += 1;
    }
    double tb1 = MPI_Wtime();

    double local_build_ms = (tb1 - tb0) * 1e3;
    double build_min_ms = 0.0, build_max_ms = 0.0, build_sum_ms = 0.0;
    double local_points_f = static_cast<double>(local_ids.size());
    double points_min = 0.0, points_max = 0.0, points_sum = 0.0;
    double local_parts_f = static_cast<double>(local_owned_parts);
    double parts_min = 0.0, parts_max = 0.0, parts_sum = 0.0;
    MPI_Reduce(&local_build_ms, &build_min_ms, 1, MPI_DOUBLE, MPI_MIN, 0, MPI_COMM_WORLD);
    MPI_Reduce(&local_build_ms, &build_max_ms, 1, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD);
    MPI_Reduce(&local_build_ms, &build_sum_ms, 1, MPI_DOUBLE, MPI_SUM, 0, MPI_COMM_WORLD);
    MPI_Reduce(&local_points_f, &points_min, 1, MPI_DOUBLE, MPI_MIN, 0, MPI_COMM_WORLD);
    MPI_Reduce(&local_points_f, &points_max, 1, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD);
    MPI_Reduce(&local_points_f, &points_sum, 1, MPI_DOUBLE, MPI_SUM, 0, MPI_COMM_WORLD);
    MPI_Reduce(&local_parts_f, &parts_min, 1, MPI_DOUBLE, MPI_MIN, 0, MPI_COMM_WORLD);
    MPI_Reduce(&local_parts_f, &parts_max, 1, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD);
    MPI_Reduce(&local_parts_f, &parts_sum, 1, MPI_DOUBLE, MPI_SUM, 0, MPI_COMM_WORLD);

    if (rank == 0)
        delete[] base;

    if (build_only)
    {
        if (rank == 0)
        {
            std::cout << std::fixed << std::setprecision(3)
                      << "[Codex-HNSW-Split] build only finished"
                      << " MPI=" << sz
                      << " pthread=" << nth
                      << " parts=" << parts
                      << " mode=" << part_mode
                      << " M=" << M
                      << " efc=" << efc
                      << " build_ms[min/avg/max]=" << build_min_ms << "/"
                      << (build_sum_ms / sz) << "/" << build_max_ms
                      << " points[min/avg/max]=" << static_cast<int>(points_min) << "/"
                      << static_cast<int>(points_sum / sz) << "/" << static_cast<int>(points_max)
                      << " parts_owned[min/avg/max]=" << static_cast<int>(parts_min) << "/"
                      << static_cast<int>(parts_sum / sz) << "/" << static_cast<int>(parts_max)
                      << "\n";
        }
        delete[] queries;
        delete[] gt;
        MPI_Finalize();
        return 0;
    }

    if (rank != 0)
    {
        queries = new float[qn * dim];
        gt = new int[qn * gd];
    }
    MPI_Bcast(queries, static_cast<int>(qn * dim), MPI_FLOAT, 0, MPI_COMM_WORLD);
    MPI_Bcast(gt, static_cast<int>(qn * gd), MPI_INT, 0, MPI_COMM_WORLD);

    if (rank == 0)
    {
        std::cout << std::fixed << std::setprecision(3)
                  << "[Codex-HNSW-Split] MPI=" << sz
                  << " pthread=" << nth
                  << " parts=" << parts
                  << " mode=" << part_mode
                  << " M=" << M
                  << " local_k=" << local_k
                  << " ef=" << ef
                  << " build_ms[min/avg/max]=" << build_min_ms << "/"
                  << (build_sum_ms / sz) << "/" << build_max_ms
                  << " points[min/avg/max]=" << static_cast<int>(points_min) << "/"
                  << static_cast<int>(points_sum / sz) << "/" << static_cast<int>(points_max)
                  << " parts_owned[min/avg/max]=" << static_cast<int>(parts_min) << "/"
                  << static_cast<int>(parts_sum / sz) << "/" << static_cast<int>(parts_max)
                  << "\n";
    }

    std::atomic<size_t> next(0);
    std::vector<std::vector<MinPair>> local_results(qn);
    std::vector<double> query_us(qn, 0.0);
    std::vector<ThreadStat> thread_stats((size_t)nth);
    std::vector<pthread_t> threads((size_t)nth);
    std::vector<WorkerArg> args((size_t)nth);

    MPI_Barrier(MPI_COMM_WORLD);
    double ts = MPI_Wtime();
    for (int t = 0; t < nth; ++t)
    {
        args[(size_t)t].part_indexes = &part_indexes;
        args[(size_t)t].queries = queries;
        args[(size_t)t].qn = qn;
        args[(size_t)t].dim = dim;
        args[(size_t)t].local_k = local_k;
        args[(size_t)t].next = &next;
        args[(size_t)t].results = &local_results;
        args[(size_t)t].query_us = &query_us;
        args[(size_t)t].stats = &thread_stats;
        args[(size_t)t].tid = t;
        pthread_create(&threads[(size_t)t], nullptr, query_worker, &args[(size_t)t]);
    }
    for (int t = 0; t < nth; ++t)
        pthread_join(threads[(size_t)t], nullptr);
    double tsearch = MPI_Wtime();

    const float invalid = std::numeric_limits<float>::infinity();
    std::vector<float> sendbuf(qn * local_k * 2, 0.0f);
    for (size_t qi = 0; qi < qn; ++qi)
    {
        size_t base_idx = qi * local_k * 2;
        for (size_t j = 0; j < local_k; ++j)
        {
            if (j < local_results[qi].size())
            {
                sendbuf[base_idx + j * 2] = local_results[qi][j].first;
                sendbuf[base_idx + j * 2 + 1] = static_cast<float>(local_results[qi][j].second);
            }
            else
            {
                sendbuf[base_idx + j * 2] = invalid;
                sendbuf[base_idx + j * 2 + 1] = -1.0f;
            }
        }
    }

    int send_count = static_cast<int>(sendbuf.size());
    std::vector<float> gatherbuf;
    if (rank == 0)
        gatherbuf.resize((size_t)sz * sendbuf.size());

    MPI_Gather(sendbuf.data(), send_count, MPI_FLOAT,
               rank == 0 ? gatherbuf.data() : nullptr, send_count, MPI_FLOAT,
               0, MPI_COMM_WORLD);
    double tgather = MPI_Wtime();

    double local_search_ms = (tsearch - ts) * 1e3;
    double local_gather_ms = (tgather - tsearch) * 1e3;
    double local_merge_ms = 0.0;
    double local_total_ms = (tgather - ts) * 1e3;

    double total_recall = 0.0;
    if (rank == 0)
    {
        double tm0 = MPI_Wtime();
        for (size_t qi = 0; qi < qn; ++qi)
        {
            Heap g;
            for (int r = 0; r < sz; ++r)
            {
                size_t base_idx = ((size_t)r * qn + qi) * local_k * 2;
                for (size_t j = 0; j < local_k; ++j)
                {
                    int id = static_cast<int>(gatherbuf[base_idx + j * 2 + 1]);
                    if (id >= 0)
                        hp(g, gatherbuf[base_idx + j * 2], id, k);
                }
            }
            total_recall += recall_of_heap(g, gt + qi * gd, k);
        }
        double tm1 = MPI_Wtime();
        local_merge_ms = (tm1 - tm0) * 1e3;
        local_total_ms = (tm1 - ts) * 1e3;
    }

    double search_min_ms = 0.0, search_max_ms = 0.0, search_sum_ms = 0.0;
    double gather_min_ms = 0.0, gather_max_ms = 0.0, gather_sum_ms = 0.0;
    double merge_min_ms = 0.0, merge_max_ms = 0.0, merge_sum_ms = 0.0;
    double total_min_ms = 0.0, total_max_ms = 0.0, total_sum_ms = 0.0;
    MPI_Reduce(&local_search_ms, &search_min_ms, 1, MPI_DOUBLE, MPI_MIN, 0, MPI_COMM_WORLD);
    MPI_Reduce(&local_search_ms, &search_max_ms, 1, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD);
    MPI_Reduce(&local_search_ms, &search_sum_ms, 1, MPI_DOUBLE, MPI_SUM, 0, MPI_COMM_WORLD);
    MPI_Reduce(&local_gather_ms, &gather_min_ms, 1, MPI_DOUBLE, MPI_MIN, 0, MPI_COMM_WORLD);
    MPI_Reduce(&local_gather_ms, &gather_max_ms, 1, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD);
    MPI_Reduce(&local_gather_ms, &gather_sum_ms, 1, MPI_DOUBLE, MPI_SUM, 0, MPI_COMM_WORLD);
    MPI_Reduce(&local_merge_ms, &merge_min_ms, 1, MPI_DOUBLE, MPI_MIN, 0, MPI_COMM_WORLD);
    MPI_Reduce(&local_merge_ms, &merge_max_ms, 1, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD);
    MPI_Reduce(&local_merge_ms, &merge_sum_ms, 1, MPI_DOUBLE, MPI_SUM, 0, MPI_COMM_WORLD);
    MPI_Reduce(&local_total_ms, &total_min_ms, 1, MPI_DOUBLE, MPI_MIN, 0, MPI_COMM_WORLD);
    MPI_Reduce(&local_total_ms, &total_max_ms, 1, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD);
    MPI_Reduce(&local_total_ms, &total_sum_ms, 1, MPI_DOUBLE, MPI_SUM, 0, MPI_COMM_WORLD);

    double local_qavg_us = 0.0;
    double local_qmax_us = 0.0;
    for (double v : query_us)
    {
        local_qavg_us += v;
        local_qmax_us = std::max(local_qmax_us, v);
    }
    local_qavg_us /= static_cast<double>(qn);

    double qavg_min_us = 0.0, qavg_max_us = 0.0, qavg_sum_us = 0.0;
    double qmax_us = 0.0;
    MPI_Reduce(&local_qavg_us, &qavg_min_us, 1, MPI_DOUBLE, MPI_MIN, 0, MPI_COMM_WORLD);
    MPI_Reduce(&local_qavg_us, &qavg_max_us, 1, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD);
    MPI_Reduce(&local_qavg_us, &qavg_sum_us, 1, MPI_DOUBLE, MPI_SUM, 0, MPI_COMM_WORLD);
    MPI_Reduce(&local_qmax_us, &qmax_us, 1, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD);

    if (rank == 0)
    {
        std::vector<double> rank0_query_us = query_us;
        std::vector<size_t> rank0_tasks((size_t)nth, 0);
        std::vector<double> rank0_work_us((size_t)nth, 0.0);
        for (int t = 0; t < nth; ++t)
        {
            rank0_tasks[(size_t)t] = thread_stats[(size_t)t].tasks;
            rank0_work_us[(size_t)t] = thread_stats[(size_t)t].work_us;
        }

        size_t tasks_min = *std::min_element(rank0_tasks.begin(), rank0_tasks.end());
        size_t tasks_max = *std::max_element(rank0_tasks.begin(), rank0_tasks.end());
        double tasks_avg = 0.0;
        for (size_t v : rank0_tasks)
            tasks_avg += static_cast<double>(v);
        tasks_avg /= static_cast<double>(nth);

        double work_min = *std::min_element(rank0_work_us.begin(), rank0_work_us.end());
        double work_max = *std::max_element(rank0_work_us.begin(), rank0_work_us.end());
        double work_avg = 0.0;
        for (double v : rank0_work_us)
            work_avg += v;
        work_avg /= static_cast<double>(nth);

        std::cout << std::fixed << std::setprecision(3)
                  << "[Codex-HNSW-Split] avg_lat=" << (local_total_ms * 1e3 / qn)
                  << " us recall=" << (total_recall / qn)
                  << " search_ms[min/avg/max]=" << search_min_ms << "/"
                  << (search_sum_ms / sz) << "/" << search_max_ms
                  << " gather_ms[min/avg/max]=" << gather_min_ms << "/"
                  << (gather_sum_ms / sz) << "/" << gather_max_ms
                  << " merge_ms[min/avg/max]=" << merge_min_ms << "/"
                  << (merge_sum_ms / sz) << "/" << merge_max_ms
                  << " total_ms[min/avg/max]=" << total_min_ms << "/"
                  << (total_sum_ms / sz) << "/" << total_max_ms
                  << " qavg_us[min/avg/max]=" << qavg_min_us << "/"
                  << (qavg_sum_us / sz) << "/" << qavg_max_us
                  << " qmax_us=" << qmax_us
                  << "\n";

        std::cout << std::fixed << std::setprecision(3)
                  << "[Codex-HNSW-Split] rank0_query_us p50/p95/p99/max="
                  << percentile_us(rank0_query_us, 0.50) << "/"
                  << percentile_us(rank0_query_us, 0.95) << "/"
                  << percentile_us(rank0_query_us, 0.99) << "/"
                  << *std::max_element(rank0_query_us.begin(), rank0_query_us.end())
                  << " rank0_thread_tasks min/avg/max="
                  << tasks_min << "/" << tasks_avg << "/" << tasks_max
                  << " rank0_thread_work_us min/avg/max="
                  << work_min << "/" << work_avg << "/" << work_max
                  << "\n";

        for (int t = 0; t < nth; ++t)
        {
            std::cout << std::fixed << std::setprecision(3)
                      << "[Codex-HNSW-Split] rank0_thread[" << t << "] tasks="
                      << thread_stats[(size_t)t].tasks
                      << " work_us=" << thread_stats[(size_t)t].work_us
                      << "\n";
        }
    }

    delete[] queries;
    delete[] gt;
    MPI_Finalize();
    return 0;
}
