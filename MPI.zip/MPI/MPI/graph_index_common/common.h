#pragma once

#include <algorithm>
#include <cstdint>
#include <cstring>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <mpi.h>
#include <queue>
#include <set>
#include <sstream>
#include <string>
#include <vector>

using MinPair = std::pair<float, int>;
using Heap = std::priority_queue<MinPair>;

// ---- distance functions ----

static inline float ip_dist(const float *a, const float *b, size_t d)
{
    float sum = 0.0f;
    for (size_t i = 0; i < d; ++i)
        sum += a[i] * b[i];
    return 1.0f - sum;
}

static inline float l2_dist(const float *a, const float *b, size_t d)
{
    float sum = 0.0f;
    for (size_t i = 0; i < d; ++i)
    {
        float df = a[i] - b[i];
        sum += df * df;
    }
    return sum;
}

// ---- heap helper ----

static inline void hp(Heap &h, float d, int id, size_t k)
{
    if (h.size() < k)
        h.push({d, id});
    else if (d < h.top().first)
    {
        h.pop();
        h.push({d, id});
    }
}

// ---- fbin loader ----

template <typename T>
static T *load_fbin_like(const std::string &p, size_t &n, size_t &d)
{
    std::ifstream f(p, std::ios::binary);
    if (!f)
        return nullptr;
    int32_t h[2];
    f.read(reinterpret_cast<char *>(h), 8);
    n = static_cast<size_t>(h[0]);
    d = static_cast<size_t>(h[1]);
    T *dt = new T[n * d];
    f.read(reinterpret_cast<char *>(dt), n * d * sizeof(T));
    return dt;
}

static inline bool file_exists(const std::string &p)
{
    std::ifstream f(p, std::ios::binary);
    return f.good();
}

// ---- env helpers ----

static inline std::string env_or_empty(const char *name)
{
    const char *s = std::getenv(name);
    return (s && *s) ? std::string(s) : std::string();
}

static inline int env_i(const char *name, int defv)
{
    const char *s = std::getenv(name);
    if (!s || !*s)
        return defv;
    int v = std::atoi(s);
    return v > 0 ? v : defv;
}

static inline std::string files_dir()
{
    std::string p = env_or_empty("ANN_FILES_DIR");
    return p.empty() ? std::string("files") : p;
}

static inline std::string files_path(const std::string &name)
{
    std::string dir = files_dir();
    if (!dir.empty() && (dir.back() == '/' || dir.back() == '\\'))
        return dir + name;
    return dir + "/" + name;
}

// ---- recall ----

static inline float recall_of_heap(const Heap &r, const int *gt, size_t k)
{
    std::set<int> gs(gt, gt + k);
    size_t hit = 0;
    Heap tmp = r;
    while (!tmp.empty())
    {
        if (gs.count(tmp.top().second))
            ++hit;
        tmp.pop();
    }
    return static_cast<float>(hit) / k;
}

// ---- MPI gather / scatter / bcast utilities ----

static inline void gather_topk_pairs(const std::vector<MinPair> &local, size_t k, int rank, int sz,
                                     std::vector<MinPair> &merged)
{
    int lc = static_cast<int>(local.size());
    std::vector<int> counts(sz);
    MPI_Gather(&lc, 1, MPI_INT, counts.data(), 1, MPI_INT, 0, MPI_COMM_WORLD);

    std::vector<float> send(static_cast<size_t>(lc) * 2);
    for (int i = 0; i < lc; ++i)
    {
        send[(size_t)i * 2] = local[(size_t)i].first;
        send[(size_t)i * 2 + 1] = static_cast<float>(local[(size_t)i].second);
    }

    std::vector<int> displs(sz), recv_counts(sz);
    std::vector<float> recv;
    if (rank == 0)
    {
        int off = 0;
        for (int i = 0; i < sz; ++i)
        {
            recv_counts[i] = counts[i] * 2;
            displs[i] = off;
            off += recv_counts[i];
        }
        recv.resize(static_cast<size_t>(off));
    }

    MPI_Gatherv(send.data(), lc * 2, MPI_FLOAT,
                rank == 0 ? recv.data() : nullptr,
                recv_counts.data(), displs.data(), MPI_FLOAT,
                0, MPI_COMM_WORLD);

    if (rank != 0)
        return;

    Heap h;
    for (size_t i = 0; i + 1 < recv.size(); i += 2)
        hp(h, recv[i], static_cast<int>(recv[i + 1]), k);

    merged.clear();
    merged.reserve(k);
    while (!h.empty())
    {
        merged.push_back(h.top());
        h.pop();
    }
}

static inline std::string rank_tag(int sz, int rank)
{
    std::ostringstream oss;
    oss << "p" << sz << "_r" << rank;
    return oss.str();
}

// ---- vector file I/O ----

static inline void save_vector_f32(const std::string &path, const std::vector<float> &v)
{
    std::ofstream out(path, std::ios::binary);
    size_t n = v.size();
    out.write(reinterpret_cast<const char *>(&n), sizeof(n));
    if (n)
        out.write(reinterpret_cast<const char *>(v.data()), static_cast<std::streamsize>(n * sizeof(float)));
}

static inline bool load_vector_f32(const std::string &path, std::vector<float> &v)
{
    std::ifstream in(path, std::ios::binary);
    if (!in)
        return false;
    size_t n = 0;
    in.read(reinterpret_cast<char *>(&n), sizeof(n));
    v.resize(n);
    if (n)
        in.read(reinterpret_cast<char *>(v.data()), static_cast<std::streamsize>(n * sizeof(float)));
    return true;
}

static inline void save_vector_i32(const std::string &path, const std::vector<int> &v)
{
    std::ofstream out(path, std::ios::binary);
    size_t n = v.size();
    out.write(reinterpret_cast<const char *>(&n), sizeof(n));
    if (n)
        out.write(reinterpret_cast<const char *>(v.data()), static_cast<std::streamsize>(n * sizeof(int)));
}

static inline bool load_vector_i32(const std::string &path, std::vector<int> &v)
{
    std::ifstream in(path, std::ios::binary);
    if (!in)
        return false;
    size_t n = 0;
    in.read(reinterpret_cast<char *>(&n), sizeof(n));
    v.resize(n);
    if (n)
        in.read(reinterpret_cast<char *>(v.data()), static_cast<std::streamsize>(n * sizeof(int)));
    return true;
}

static inline void bcast_vector_f32(std::vector<float> &v, int rank)
{
    size_t n = v.size();
    MPI_Bcast(&n, 1, MPI_UNSIGNED_LONG_LONG, 0, MPI_COMM_WORLD);
    if (rank != 0)
        v.resize(n);
    if (n)
        MPI_Bcast(v.data(), static_cast<int>(n), MPI_FLOAT, 0, MPI_COMM_WORLD);
}

static inline void bcast_vector_i32(std::vector<int> &v, int rank)
{
    size_t n = v.size();
    MPI_Bcast(&n, 1, MPI_UNSIGNED_LONG_LONG, 0, MPI_COMM_WORLD);
    if (rank != 0)
        v.resize(n);
    if (n)
        MPI_Bcast(v.data(), static_cast<int>(n), MPI_INT, 0, MPI_COMM_WORLD);
}

static inline void scatter_grouped_vectors(
    const float *base, size_t n, size_t d,
    const std::vector<int> &group_of_vec,
    const std::vector<int> &owner_of_group,
    int rank, int sz,
    std::vector<float> &local_data,
    std::vector<int> &local_ids,
    std::vector<int> &local_groups)
{
    std::vector<int> vec_counts(sz, 0), data_counts(sz, 0), vec_displs(sz, 0), data_displs(sz, 0);
    std::vector<float> packed_data;
    std::vector<int> packed_ids, packed_groups;

    if (rank == 0)
    {
        for (size_t i = 0; i < n; ++i)
        {
            int owner = owner_of_group[(size_t)group_of_vec[i]];
            ++vec_counts[owner];
        }
        for (int i = 0; i < sz; ++i)
        {
            data_counts[i] = vec_counts[i] * static_cast<int>(d);
            if (i > 0)
            {
                vec_displs[i] = vec_displs[i - 1] + vec_counts[i - 1];
                data_displs[i] = data_displs[i - 1] + data_counts[i - 1];
            }
        }

        packed_data.resize(n * d);
        packed_ids.resize(n);
        packed_groups.resize(n);
        std::vector<int> cur_vec(sz, 0), cur_data(sz, 0);
        for (int i = 0; i < sz; ++i)
        {
            cur_vec[i] = vec_displs[i];
            cur_data[i] = data_displs[i];
        }
        for (size_t i = 0; i < n; ++i)
        {
            int g = group_of_vec[i];
            int owner = owner_of_group[(size_t)g];
            int pos_vec = cur_vec[owner]++;
            int pos_data = cur_data[owner];
            cur_data[owner] += static_cast<int>(d);
            packed_ids[(size_t)pos_vec] = static_cast<int>(i);
            packed_groups[(size_t)pos_vec] = g;
            std::memcpy(packed_data.data() + pos_data, base + i * d, d * sizeof(float));
        }
    }

    int local_vecs = 0;
    MPI_Scatter(vec_counts.data(), 1, MPI_INT, &local_vecs, 1, MPI_INT, 0, MPI_COMM_WORLD);
    local_data.resize((size_t)local_vecs * d);
    local_ids.resize(local_vecs);
    local_groups.resize(local_vecs);

    MPI_Scatterv(rank == 0 ? packed_data.data() : nullptr, data_counts.data(), data_displs.data(), MPI_FLOAT,
                 local_data.data(), local_vecs * static_cast<int>(d), MPI_FLOAT, 0, MPI_COMM_WORLD);
    MPI_Scatterv(rank == 0 ? packed_ids.data() : nullptr, vec_counts.data(), vec_displs.data(), MPI_INT,
                 local_ids.data(), local_vecs, MPI_INT, 0, MPI_COMM_WORLD);
    MPI_Scatterv(rank == 0 ? packed_groups.data() : nullptr, vec_counts.data(), vec_displs.data(), MPI_INT,
                 local_groups.data(), local_vecs, MPI_INT, 0, MPI_COMM_WORLD);
}

// ---- latency percentile ----

static inline double percentile_us(std::vector<double> v, double p)
{
    if (v.empty())
        return 0.0;
    std::sort(v.begin(), v.end());
    size_t idx = static_cast<size_t>(p * static_cast<double>(v.size() - 1));
    return v[idx];
}
