#!/bin/sh
#PBS -N codex_ivfpq_simd_1n
#PBS -e test.e
#PBS -o test.o
#PBS -l nodes=1:ppn=8

set -eu

ANN_DIR=/home/${USER}/ann
BIN=/home/${USER}/main
FILES_DIR=/home/${USER}/files

export ANN_USE_PREBUILT=${ANN_USE_PREBUILT:-1}
export ANN_FILES_DIR=${FILES_DIR}
export ANN_NP_ONLY=${ANN_NP_ONLY:-0}
export ANN_LOCAL_K=${ANN_LOCAL_K:-10}
export ANN_P=${ANN_P:-1000}

NODES=$(cat $PBS_NODEFILE | sort | uniq)
for node in $NODES; do
    scp master_ubss1:${ANN_DIR}/main ${node}:${BIN} 1>&2
    ssh "${node}" "mkdir -p '${FILES_DIR}'" 1>&2 || true
    scp -r master_ubss1:${ANN_DIR}/files ${node}:/home/${USER}/ 1>&2 || true
done

/usr/local/bin/mpiexec -np 8 -machinefile $PBS_NODEFILE ${BIN}
