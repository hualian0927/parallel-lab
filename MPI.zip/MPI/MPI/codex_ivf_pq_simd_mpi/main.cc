// Codex IVF-PQ-SIMD MPI baseline.
// Compile: mpic++ main.cc -o main -O2 -std=c++17 -I../..

#include <algorithm>
#include <chrono>
#include <cstdint>
#include <cstdlib>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <limits>
#include <string>
#include <vector>
#include "ivf_pq_mpi_local.h"

static inline int env_i(const char *name, int defv)
{
    const char *s = std::getenv(name);
    if (!s || !*s)
        return defv;
    int v = std::atoi(s);
    return v > 0 ? v : defv;
}

static inline std::string env_s(const char *name, const std::string &defv)
{
    const char *s = std::getenv(name);
    return (s && *s) ? std::string(s) : defv;
}

static inline std::string files_dir()
{
    return env_s("ANN_FILES_DIR", "files");
}

static inline std::string files_path_local(const std::string &name)
{
    std::string dir = files_dir();
    if (!dir.empty() && (dir.back() == '/' || dir.back() == '\\'))
        return dir + name;
    return dir + "/" + name;
}

template <typename T>
static inline void save_vec_bin(const std::string &path, const std::vector<T> &v)
{
    std::ofstream out(path, std::ios::binary);
    size_t n = v.size();
    out.write(reinterpret_cast<const char *>(&n), sizeof(n));
    if (n)
        out.write(reinterpret_cast<const char *>(v.data()), static_cast<std::streamsize>(n * sizeof(T)));
}

template <typename T>
static inline bool load_vec_bin(const std::string &path, std::vector<T> &v)
{
    std::ifstream in(path, std::ios::binary);
    if (!in)
        return false;
    size_t n = 0;
    in.read(reinterpret_cast<char *>(&n), sizeof(n));
    v.resize(n);
    if (n)
        in.read(reinterpret_cast<char *>(v.data()), static_cast<std::streamsize>(n * sizeof(T)));
    return true;
}

static inline bool file_exists_local(const std::string &path)
{
    std::ifstream in(path, std::ios::binary);
    return in.good();
}

static inline std::string cent_path(int K, size_t dim)
{
    return files_path_local("codex_ivfpq_simd_cent_K" + std::to_string(K) + "_d" + std::to_string(dim) + ".bin");
}

static inline std::string cb_path(int K, int M, int Kpq, size_t dim)
{
    return files_path_local("codex_ivfpq_simd_cb_K" + std::to_string(K) + "_M" + std::to_string(M) +
                            "_Kpq" + std::to_string(Kpq) + "_d" + std::to_string(dim) + ".bin");
}

static inline std::string codes_path(int K, int M, int Kpq, size_t n)
{
    return files_path_local("codex_ivfpq_simd_codes_K" + std::to_string(K) + "_M" + std::to_string(M) +
                            "_Kpq" + std::to_string(Kpq) + "_n" + std::to_string(n) + ".bin");
}

static inline std::string assign_path(int K, size_t dim, size_t n)
{
    return files_path_local("codex_ivfpq_simd_assign_K" + std::to_string(K) + "_d" + std::to_string(dim) +
                            "_n" + std::to_string(n) + ".bin");
}

static inline void compute_ivf_assign(const float *b, size_t n, size_t d, int K,
                                      const std::vector<float> &cent, std::vector<int> &assign)
{
    assign.resize(n);
    for (size_t i = 0; i < n; ++i)
    {
        float best = 1e30f;
        int bk = 0;
        const float *v = b + i * d;
        for (int k = 0; k < K; ++k)
        {
            float dist = 0.0f;
            const float *c = cent.data() + (size_t)k * d;
            for (size_t j = 0; j < d; ++j)
            {
                float df = v[j] - c[j];
                dist += df * df;
            }
            if (dist < best)
            {
                best = dist;
                bk = k;
            }
        }
        assign[i] = bk;
    }
}

static inline std::vector<IVFList> build_ivf_from_assign(const std::vector<int> &assign, int K)
{
    std::vector<IVFList> lists(K);
    for (size_t i = 0; i < assign.size(); ++i)
        if (assign[i] >= 0 && assign[i] < K)
            lists[(size_t)assign[i]].ids.push_back((int)i);
    return lists;
}

static inline double percentile_us(std::vector<double> v, double p)
{
    if (v.empty())
        return 0.0;
    std::sort(v.begin(), v.end());
    size_t idx = static_cast<size_t>(p * static_cast<double>(v.size() - 1));
    return v[idx];
}

int main(int argc, char **argv)
{
    MPI_Init(&argc, &argv);
    int rank = 0, sz = 1;
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
    MPI_Comm_size(MPI_COMM_WORLD, &sz);
    srand(42 + rank);

    size_t tn = 0, dim = 0, qn = 0, gd = 0;
    float *ab = nullptr, *qu = nullptr;
    int *gt = nullptr;
    if (rank == 0)
    {
        std::string dp = "/anndata/";
        qu = ld<float>(dp + "DEEP100K.query.fbin", qn, dim);
        ab = ld<float>(dp + "DEEP100K.base.100k.fbin", tn, dim);
        gt = ld<int>(dp + "DEEP100K.gt.query.100k.top100.bin", qn, gd);
        if (!qu || !ab || !gt)
        {
            std::cerr << "[Codex-IVFPQ-SIMD] failed to load dataset files from " << dp << "\n";
            MPI_Abort(MPI_COMM_WORLD, 2);
        }
        qn = 2000;
    }

    MPI_Bcast(&tn, 1, MPI_UNSIGNED_LONG_LONG, 0, MPI_COMM_WORLD);
    MPI_Bcast(&dim, 1, MPI_UNSIGNED_LONG_LONG, 0, MPI_COMM_WORLD);
    MPI_Bcast(&qn, 1, MPI_UNSIGNED_LONG_LONG, 0, MPI_COMM_WORLD);
    MPI_Bcast(&gd, 1, MPI_UNSIGNED_LONG_LONG, 0, MPI_COMM_WORLD);

    size_t ln = tn / sz, rm = tn % sz;
    std::vector<int> sc(sz), ds(sz);
    size_t off = 0;
    for (int i = 0; i < sz; ++i)
    {
        size_t ni = ln + (size_t)(i < (int)rm ? 1 : 0);
        sc[i] = (int)(ni * dim);
        ds[i] = (int)(off * dim);
        off += ni;
    }

    size_t mn = ln + (size_t)(rank < (int)rm ? 1 : 0);
    std::vector<float> lb(mn * dim);
    MPI_Scatterv(ab, sc.data(), ds.data(), MPI_FLOAT, lb.data(), (int)(mn * dim), MPI_FLOAT, 0, MPI_COMM_WORLD);
    int goff = (int)(ds[rank] / dim);

    const int K = env_i("ANN_K", 200);
    const int M = env_i("ANN_M", 4);
    const int Kpq = env_i("ANN_KPQ", 256);
    const size_t P = std::max<size_t>(10, (size_t)env_i("ANN_P", 1000));
    const size_t k = 10;
    const size_t local_k = std::max<size_t>(k, (size_t)env_i("ANN_LOCAL_K", 10));
    const bool build_only = env_i("ANN_BUILD_ONLY", 0) != 0;
    const bool use_prebuilt = env_i("ANN_USE_PREBUILT", 1) != 0;

    MPI_Barrier(MPI_COMM_WORLD);
    double tb0 = MPI_Wtime();

    std::vector<float> cent, cb_SoA;
    std::vector<uint8_t> codes_all;
    std::vector<int> assign_all;
    int index_mode = 0; // 0=train, 1=load
    if (rank == 0)
    {
        const std::string p_cent = cent_path(K, dim);
        const std::string p_cb = cb_path(K, M, Kpq, dim);
        const std::string p_codes = codes_path(K, M, Kpq, tn);
        const std::string p_assign = assign_path(K, dim, tn);
        bool loaded = false;
        if (use_prebuilt && file_exists_local(p_cent) && file_exists_local(p_cb) &&
            file_exists_local(p_codes) && file_exists_local(p_assign))
        {
            loaded = load_vec_bin<float>(p_cent, cent) &&
                     load_vec_bin<float>(p_cb, cb_SoA) &&
                     load_vec_bin<uint8_t>(p_codes, codes_all) &&
                     load_vec_bin<int>(p_assign, assign_all);
            const size_t expect_cb = (size_t)M * (size_t)Kpq * (dim / (size_t)M);
            const size_t expect_codes = tn * (size_t)M;
            if (loaded && (cent.size() != (size_t)K * dim ||
                           cb_SoA.size() != expect_cb ||
                           codes_all.size() != expect_codes ||
                           assign_all.size() != tn))
            {
                std::cerr << "[Codex-IVFPQ-SIMD] prebuilt index shape mismatch, rebuild from scratch\n";
                loaded = false;
                cent.clear();
                cb_SoA.clear();
                codes_all.clear();
                assign_all.clear();
            }
        }

        if (!loaded)
        {
            cent.resize((size_t)K * dim);
            train_ivf(ab, tn, dim, K, cent, 10);
            codes_all.resize(tn * M);
            pq_train_encode(ab, tn, dim, M, Kpq, cb_SoA, codes_all.data(), 8);
            compute_ivf_assign(ab, tn, dim, K, cent, assign_all);
            save_vec_bin<float>(p_cent, cent);
            save_vec_bin<float>(p_cb, cb_SoA);
            save_vec_bin<uint8_t>(p_codes, codes_all);
            save_vec_bin<int>(p_assign, assign_all);
            index_mode = 0;
        }
        else
        {
            index_mode = 1;
        }
    }

    MPI_Bcast(&index_mode, 1, MPI_INT, 0, MPI_COMM_WORLD);

    if (build_only)
    {
        double tb1_build = MPI_Wtime();
        if (rank == 0)
        {
            std::cout << "[Codex-IVFPQ-SIMD] build only finished"
                      << " index_mode=" << (index_mode ? "load" : "train")
                      << " K=" << K << " M=" << M << " Kpq=" << Kpq
                      << " build_ms=" << (tb1_build - tb0) * 1e3 << "\n";
        }
        if (rank == 0)
            delete[] ab;
        delete[] qu;
        delete[] gt;
        MPI_Finalize();
        return 0;
    }

    size_t szf = cent.size();
    MPI_Bcast(&szf, 1, MPI_UNSIGNED_LONG_LONG, 0, MPI_COMM_WORLD);
    if (rank != 0)
        cent.resize(szf);
    if (szf)
        MPI_Bcast(cent.data(), (int)szf, MPI_FLOAT, 0, MPI_COMM_WORLD);

    szf = cb_SoA.size();
    MPI_Bcast(&szf, 1, MPI_UNSIGNED_LONG_LONG, 0, MPI_COMM_WORLD);
    if (rank != 0)
        cb_SoA.resize(szf);
    if (szf)
        MPI_Bcast(cb_SoA.data(), (int)szf, MPI_FLOAT, 0, MPI_COMM_WORLD);

    std::vector<uint8_t> codes(mn * M);
    std::vector<int> local_assign(mn);
    {
        std::vector<int> sc_c(sz), ds_c(sz);
        size_t off2 = 0;
        for (int i = 0; i < sz; ++i)
        {
            size_t ni = ln + (size_t)(i < (int)rm ? 1 : 0);
            sc_c[i] = (int)(ni * M);
            ds_c[i] = (int)(off2 * M);
            off2 += ni;
        }
        MPI_Scatterv(rank == 0 ? codes_all.data() : nullptr, sc_c.data(), ds_c.data(), MPI_UNSIGNED_CHAR,
                     codes.data(), (int)(mn * M), MPI_UNSIGNED_CHAR, 0, MPI_COMM_WORLD);

        std::vector<int> sc_a(sz), ds_a(sz);
        size_t off3 = 0;
        for (int i = 0; i < sz; ++i)
        {
            size_t ni = ln + (size_t)(i < (int)rm ? 1 : 0);
            sc_a[i] = (int)ni;
            ds_a[i] = (int)off3;
            off3 += ni;
        }
        MPI_Scatterv(rank == 0 ? assign_all.data() : nullptr, sc_a.data(), ds_a.data(), MPI_INT,
                     local_assign.data(), (int)mn, MPI_INT, 0, MPI_COMM_WORLD);
    }

    auto lists = build_ivf_from_assign(local_assign, K);
    for (size_t i = 0; i < local_assign.size(); ++i)
    {
        if (local_assign[i] < 0 || local_assign[i] >= K)
        {
            std::cerr << "[Codex-IVFPQ-SIMD] invalid local IVF assignment on rank " << rank
                      << " idx=" << i << " val=" << local_assign[i] << "\n";
            MPI_Abort(MPI_COMM_WORLD, 3);
        }
    }
    double tb1 = MPI_Wtime();

    double local_build_ms = (tb1 - tb0) * 1e3;
    double build_min_ms = 0.0, build_max_ms = 0.0, build_sum_ms = 0.0;
    double local_points_f = (double)mn;
    double points_min = 0.0, points_max = 0.0, points_sum = 0.0;
    MPI_Reduce(&local_build_ms, &build_min_ms, 1, MPI_DOUBLE, MPI_MIN, 0, MPI_COMM_WORLD);
    MPI_Reduce(&local_build_ms, &build_max_ms, 1, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD);
    MPI_Reduce(&local_build_ms, &build_sum_ms, 1, MPI_DOUBLE, MPI_SUM, 0, MPI_COMM_WORLD);
    MPI_Reduce(&local_points_f, &points_min, 1, MPI_DOUBLE, MPI_MIN, 0, MPI_COMM_WORLD);
    MPI_Reduce(&local_points_f, &points_max, 1, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD);
    MPI_Reduce(&local_points_f, &points_sum, 1, MPI_DOUBLE, MPI_SUM, 0, MPI_COMM_WORLD);

    if (rank == 0)
        delete[] ab;

    if (rank != 0)
    {
        qu = new float[qn * dim];
        gt = new int[qn * gd];
    }
    MPI_Bcast(qu, (int)(qn * dim), MPI_FLOAT, 0, MPI_COMM_WORLD);
    MPI_Bcast(gt, (int)(qn * gd), MPI_INT, 0, MPI_COMM_WORLD);

    if (rank == 0)
    {
        std::cout << std::fixed << std::setprecision(3)
                  << "[Codex-IVFPQ-SIMD] MPI=" << sz
                  << " K=" << K
                  << " M=" << M
                  << " Kpq=" << Kpq
                  << " P=" << P
                  << " local_k=" << local_k
                  << " index_mode=" << (index_mode ? "load" : "train")
                  << " build_ms[min/avg/max]=" << build_min_ms << "/"
                  << (build_sum_ms / sz) << "/" << build_max_ms
                  << " points[min/avg/max]=" << (int)points_min << "/"
                  << (int)(points_sum / sz) << "/" << (int)points_max
                  << "\n";
    }

    int default_np[] = {8, 10, 12, 14};
    int one_np = env_i("ANN_NP_ONLY", 0);
    std::vector<int> np_vals;
    if (one_np > 0)
        np_vals.push_back(one_np);
    else
        np_vals.assign(default_np, default_np + sizeof(default_np) / sizeof(default_np[0]));

    const float invalid = std::numeric_limits<float>::infinity();
    for (int np : np_vals)
    {
        std::vector<std::vector<std::pair<float, int>>> local_results(qn);
        std::vector<double> query_us(qn, 0.0);

        MPI_Barrier(MPI_COMM_WORLD);
        double ts = MPI_Wtime();
        for (size_t qi = 0; qi < qn; ++qi)
        {
            auto t0 = std::chrono::steady_clock::now();
            ivf_pq_search(lb.data(), codes.data(), cent, lists, cb_SoA, qu + qi * dim, dim,
                          local_k, M, Kpq, np, P, local_results[qi]);
            auto t1 = std::chrono::steady_clock::now();
            query_us[qi] = std::chrono::duration<double, std::micro>(t1 - t0).count();
        }
        double tsearch = MPI_Wtime();

        std::vector<float> sendbuf(qn * local_k * 2, 0.0f);
        for (size_t qi = 0; qi < qn; ++qi)
        {
            size_t base = qi * local_k * 2;
            for (size_t j = 0; j < local_k; ++j)
            {
                if (j < local_results[qi].size())
                {
                    sendbuf[base + j * 2] = local_results[qi][j].first;
                    sendbuf[base + j * 2 + 1] = (float)(local_results[qi][j].second + goff);
                }
                else
                {
                    sendbuf[base + j * 2] = invalid;
                    sendbuf[base + j * 2 + 1] = -1.0f;
                }
            }
        }

        int send_count = (int)sendbuf.size();
        std::vector<float> gatherbuf;
        if (rank == 0)
            gatherbuf.resize((size_t)sz * sendbuf.size());

        MPI_Gather(sendbuf.data(), send_count, MPI_FLOAT,
                   rank == 0 ? gatherbuf.data() : nullptr, send_count, MPI_FLOAT,
                   0, MPI_COMM_WORLD);
        double tgather = MPI_Wtime();

        double local_search_ms = (tsearch - ts) * 1e3;
        double local_gather_ms = (tgather - tsearch) * 1e3;
        double local_merge_ms = 0.0;
        double local_total_ms = (tgather - ts) * 1e3;

        double total_recall = 0.0;
        if (rank == 0)
        {
            double tm0 = MPI_Wtime();
            for (size_t qi = 0; qi < qn; ++qi)
            {
                Heap g;
                for (int r = 0; r < sz; ++r)
                {
                    size_t base = ((size_t)r * qn + qi) * local_k * 2;
                    for (size_t j = 0; j < local_k; ++j)
                    {
                        int id = (int)gatherbuf[base + j * 2 + 1];
                        if (id >= 0)
                            hp(g, gatherbuf[base + j * 2], id, k);
                    }
                }
                std::set<int> gs(gt + qi * gd, gt + qi * gd + k);
                size_t hit = 0;
                Heap tmp = g;
                while (!tmp.empty())
                {
                    if (gs.count(tmp.top().second))
                        ++hit;
                    tmp.pop();
                }
                total_recall += (double)hit / k;
            }
            double tm1 = MPI_Wtime();
            local_merge_ms = (tm1 - tm0) * 1e3;
            local_total_ms = (tm1 - ts) * 1e3;
        }

        double search_min_ms = 0.0, search_max_ms = 0.0, search_sum_ms = 0.0;
        double gather_min_ms = 0.0, gather_max_ms = 0.0, gather_sum_ms = 0.0;
        double merge_min_ms = 0.0, merge_max_ms = 0.0, merge_sum_ms = 0.0;
        double total_min_ms = 0.0, total_max_ms = 0.0, total_sum_ms = 0.0;
        MPI_Reduce(&local_search_ms, &search_min_ms, 1, MPI_DOUBLE, MPI_MIN, 0, MPI_COMM_WORLD);
        MPI_Reduce(&local_search_ms, &search_max_ms, 1, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD);
        MPI_Reduce(&local_search_ms, &search_sum_ms, 1, MPI_DOUBLE, MPI_SUM, 0, MPI_COMM_WORLD);
        MPI_Reduce(&local_gather_ms, &gather_min_ms, 1, MPI_DOUBLE, MPI_MIN, 0, MPI_COMM_WORLD);
        MPI_Reduce(&local_gather_ms, &gather_max_ms, 1, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD);
        MPI_Reduce(&local_gather_ms, &gather_sum_ms, 1, MPI_DOUBLE, MPI_SUM, 0, MPI_COMM_WORLD);
        MPI_Reduce(&local_merge_ms, &merge_min_ms, 1, MPI_DOUBLE, MPI_MIN, 0, MPI_COMM_WORLD);
        MPI_Reduce(&local_merge_ms, &merge_max_ms, 1, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD);
        MPI_Reduce(&local_merge_ms, &merge_sum_ms, 1, MPI_DOUBLE, MPI_SUM, 0, MPI_COMM_WORLD);
        MPI_Reduce(&local_total_ms, &total_min_ms, 1, MPI_DOUBLE, MPI_MIN, 0, MPI_COMM_WORLD);
        MPI_Reduce(&local_total_ms, &total_max_ms, 1, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD);
        MPI_Reduce(&local_total_ms, &total_sum_ms, 1, MPI_DOUBLE, MPI_SUM, 0, MPI_COMM_WORLD);

        double local_qavg_us = 0.0;
        double local_qmax_us = 0.0;
        for (double v : query_us)
        {
            local_qavg_us += v;
            local_qmax_us = std::max(local_qmax_us, v);
        }
        local_qavg_us /= (double)qn;

        double qavg_min_us = 0.0, qavg_max_us = 0.0, qavg_sum_us = 0.0;
        double qmax_us = 0.0;
        MPI_Reduce(&local_qavg_us, &qavg_min_us, 1, MPI_DOUBLE, MPI_MIN, 0, MPI_COMM_WORLD);
        MPI_Reduce(&local_qavg_us, &qavg_max_us, 1, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD);
        MPI_Reduce(&local_qavg_us, &qavg_sum_us, 1, MPI_DOUBLE, MPI_SUM, 0, MPI_COMM_WORLD);
        MPI_Reduce(&local_qmax_us, &qmax_us, 1, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD);

        if (rank == 0)
        {
            std::cout << std::fixed << std::setprecision(3)
                      << "[Codex-IVFPQ-SIMD] np=" << np
                      << " avg_lat=" << (local_total_ms * 1e3 / qn) << " us"
                      << " recall=" << (total_recall / qn)
                      << " search_ms[min/avg/max]=" << search_min_ms << "/"
                      << (search_sum_ms / sz) << "/" << search_max_ms
                      << " gather_ms[min/avg/max]=" << gather_min_ms << "/"
                      << (gather_sum_ms / sz) << "/" << gather_max_ms
                      << " merge_ms[min/avg/max]=" << merge_min_ms << "/"
                      << (merge_sum_ms / sz) << "/" << merge_max_ms
                      << " total_ms[min/avg/max]=" << total_min_ms << "/"
                      << (total_sum_ms / sz) << "/" << total_max_ms
                      << " qavg_us[min/avg/max]=" << qavg_min_us << "/"
                      << (qavg_sum_us / sz) << "/" << qavg_max_us
                      << " qmax_us=" << qmax_us
                      << "\n";

            std::cout << std::fixed << std::setprecision(3)
                      << "[Codex-IVFPQ-SIMD] rank0_query_us p50/p95/p99/max="
                      << percentile_us(query_us, 0.50) << "/"
                      << percentile_us(query_us, 0.95) << "/"
                      << percentile_us(query_us, 0.99) << "/"
                      << *std::max_element(query_us.begin(), query_us.end())
                      << "\n";
        }
    }

    delete[] qu;
    delete[] gt;
    MPI_Finalize();
    return 0;
}
