#!/bin/sh
#PBS -N ivfpqsimd_cmp16
#PBS -e test.e
#PBS -o test.o
#PBS -l nodes=2:ppn=8

set -eu

ANN_DIR=/home/${USER}/ann
BIN=/home/${USER}/main
FILES_DIR=/home/${USER}/files
OUT_DIR=/home/${USER}/analysis_out_ivfpq_simd
OUT_FILE=${OUT_DIR}/ivfpq_simd_scale_2node.txt

mkdir -p "${OUT_DIR}"
export ANN_USE_PREBUILT=1
export ANN_FILES_DIR=${FILES_DIR}
export ANN_NP_ONLY=${ANN_NP_ONLY:-12}
export ANN_LOCAL_K=${ANN_LOCAL_K:-10}
export ANN_P=${ANN_P:-1000}

NODES=$(cat $PBS_NODEFILE | sort | uniq)
for node in $NODES; do
    scp master_ubss1:${ANN_DIR}/main ${node}:${BIN} 1>&2
    ssh "${node}" "mkdir -p '${FILES_DIR}'" 1>&2 || true
    scp -r master_ubss1:${ANN_DIR}/files ${node}:/home/${USER}/ 1>&2 || true
done

: > "${OUT_FILE}"
echo "============================================================" | tee -a "${OUT_FILE}"
echo " IVF-PQ-SIMD MPI scale compare | 2 nodes x 8 ppn | pure MPI" | tee -a "${OUT_FILE}"
echo " Params: nprobe=${ANN_NP_ONLY} P=${ANN_P} local_k=${ANN_LOCAL_K}" | tee -a "${OUT_FILE}"
echo "============================================================" | tee -a "${OUT_FILE}"

for NP in 16 8 4 2; do
    echo "" | tee -a "${OUT_FILE}"
    echo "[CASE] MPI=${NP}" | tee -a "${OUT_FILE}"
    /usr/local/bin/mpiexec -np "${NP}" -machinefile $PBS_NODEFILE ${BIN} 2>&1 | tee -a "${OUT_FILE}"
done

scp "${OUT_FILE}" master_ubss1:${ANN_DIR}/ 2>&1 || true
