#pragma once

#include <algorithm>
#include <cstdlib>
#include <cstring>
#include <fstream>
#include <iostream>
#include <limits>
#include <mpi.h>
#include <queue>
#include <set>
#include <utility>
#include <vector>

#include "hnswlib/hnswlib/ivf_train.h"
#include "hnswlib/hnswlib/simd_utils.h"

using Heap = std::priority_queue<std::pair<float, int>>;

static inline void hp(Heap &h, float d, int id, size_t k)
{
    if (h.size() < k)
        h.push({d, id});
    else if (d < h.top().first)
    {
        h.pop();
        h.push({d, id});
    }
}

template <typename T>
static inline T *ld(const std::string &p, size_t &n, size_t &d)
{
    std::ifstream f(p, std::ios::binary);
    if (!f)
        return nullptr;
    int32_t h[2];
    f.read(reinterpret_cast<char *>(h), 8);
    n = static_cast<size_t>(h[0]);
    d = static_cast<size_t>(h[1]);
    T *dt = new T[n * d];
    f.read(reinterpret_cast<char *>(dt), static_cast<std::streamsize>(n * d * sizeof(T)));
    return dt;
}

static inline std::vector<IVFList> build_ivf(const float *b, size_t n, size_t d, int K, const std::vector<float> &cent)
{
    std::vector<IVFList> lists(K);
    for (size_t i = 0; i < n; ++i)
    {
        float best = 1e30f;
        int bk = 0;
        const float *v = b + i * d;
        for (int k = 0; k < K; ++k)
        {
            float dist = 0.0f;
            const float *c = cent.data() + static_cast<size_t>(k) * d;
            for (size_t j = 0; j < d; ++j)
            {
                float df = v[j] - c[j];
                dist += df * df;
            }
            if (dist < best)
            {
                best = dist;
                bk = k;
            }
        }
        lists[bk].ids.push_back(static_cast<int>(i));
    }
    return lists;
}

static inline void pq_train_encode(const float *b, size_t n, size_t d, int M, int Kpq,
                                   std::vector<float> &cb_SoA, uint8_t *codes, int iter = 8)
{
    size_t ds = d / static_cast<size_t>(M);
    std::vector<float> cb_AoS(static_cast<size_t>(M) * Kpq * ds);
    for (int m = 0; m < M; ++m)
    {
        float *c = cb_AoS.data() + static_cast<size_t>(m) * Kpq * ds;
        for (int k = 0; k < Kpq; ++k)
        {
            int ri = rand() % static_cast<int>(n);
            std::memcpy(c + static_cast<size_t>(k) * ds, b + static_cast<size_t>(ri) * d + static_cast<size_t>(m) * ds, ds * sizeof(float));
        }

        std::vector<int> as(n);
        std::vector<float> sm(static_cast<size_t>(Kpq) * ds);
        std::vector<int> cn(Kpq);
        for (int itn = 0; itn < iter; ++itn)
        {
            for (size_t i = 0; i < n; ++i)
            {
                float best = 1e30f;
                int bk = 0;
                const float *sv = b + i * d + static_cast<size_t>(m) * ds;
                for (int k = 0; k < Kpq; ++k)
                {
                    float dist = 0.0f;
                    for (size_t j = 0; j < ds; ++j)
                    {
                        float df = sv[j] - c[static_cast<size_t>(k) * ds + j];
                        dist += df * df;
                    }
                    if (dist < best)
                    {
                        best = dist;
                        bk = k;
                    }
                }
                as[i] = bk;
            }
            std::fill(sm.begin(), sm.end(), 0.0f);
            std::fill(cn.begin(), cn.end(), 0);
            for (size_t i = 0; i < n; ++i)
            {
                int k = as[i];
                ++cn[k];
                for (size_t j = 0; j < ds; ++j)
                    sm[static_cast<size_t>(k) * ds + j] += b[i * d + static_cast<size_t>(m) * ds + j];
            }
            for (int k = 0; k < Kpq; ++k)
                if (cn[k] > 0)
                    for (size_t j = 0; j < ds; ++j)
                        c[static_cast<size_t>(k) * ds + j] = sm[static_cast<size_t>(k) * ds + j] / cn[k];
        }

        for (size_t i = 0; i < n; ++i)
        {
            float best = 1e30f;
            uint8_t bk = 0;
            const float *sv = b + i * d + static_cast<size_t>(m) * ds;
            for (int k = 0; k < Kpq; ++k)
            {
                float dist = 0.0f;
                for (size_t j = 0; j < ds; ++j)
                {
                    float df = sv[j] - c[static_cast<size_t>(k) * ds + j];
                    dist += df * df;
                }
                if (dist < best)
                {
                    best = dist;
                    bk = static_cast<uint8_t>(k);
                }
            }
            codes[i * static_cast<size_t>(M) + m] = bk;
        }
    }

    cb_SoA.resize(static_cast<size_t>(M) * Kpq * ds);
    for (int m = 0; m < M; ++m)
        for (int c = 0; c < Kpq; ++c)
            for (size_t dd = 0; dd < ds; ++dd)
                cb_SoA[static_cast<size_t>(m) * Kpq * ds + dd * Kpq + c] =
                    cb_AoS[static_cast<size_t>(m) * Kpq * ds + static_cast<size_t>(c) * ds + dd];
}

static inline void ivf_pq_search(const float *b, const uint8_t *codes, const std::vector<float> &cent,
                                 const std::vector<IVFList> &ls, const std::vector<float> &cb_SoA,
                                 const float *q, size_t d, size_t k, int M, int Kpq, int np, size_t P,
                                 std::vector<std::pair<float, int>> &out)
{
    size_t ds = d / static_cast<size_t>(M);
    int Kivf = static_cast<int>(cent.size() / d);
    np = std::min(np, Kivf);

    Heap coarse;
    for (int c = 0; c < Kivf; ++c)
    {
        float dt = InnerProductSIMDNeon(q, cent.data() + static_cast<size_t>(c) * d, d);
        hp(coarse, dt, c, static_cast<size_t>(np));
    }

    std::vector<int> probes;
    while (!coarse.empty())
    {
        probes.push_back(coarse.top().second);
        coarse.pop();
    }

    Heap cand;
    for (int cid : probes)
    {
        float lut[4][256];
        for (int m = 0; m < M; ++m)
        {
            const float *qs = q + static_cast<size_t>(m) * ds;
            const float *csa = cb_SoA.data() + static_cast<size_t>(m) * Kpq * ds;
            for (int c = 0; c < Kpq; c += 4)
            {
#if defined(__aarch64__) || defined(__ARM_NEON)
                float32x4_t s4 = vdupq_n_f32(0.0f);
                for (size_t j = 0; j < ds; ++j)
                    s4 = vmlaq_f32(s4, vdupq_n_f32(qs[j]), vld1q_f32(csa + j * Kpq + c));
                vst1q_f32(&lut[m][c], s4);
#else
                for (int cc = 0; cc < 4 && c + cc < Kpq; ++cc)
                {
                    float dt = 0.0f;
                    for (size_t j = 0; j < ds; ++j)
                        dt += qs[j] * csa[j * Kpq + c + cc];
                    lut[m][c + cc] = dt;
                }
#endif
            }
        }

        for (int vi : ls[cid].ids)
        {
            const uint8_t *pq = codes + static_cast<size_t>(vi) * M;
            float dot = lut[0][pq[0]] + lut[1][pq[1]] + lut[2][pq[2]] + lut[3][pq[3]];
            hp(cand, 1.0f - dot, vi, P);
        }
    }

    Heap fine;
    while (!cand.empty())
    {
        auto p = cand.top();
        cand.pop();
        float ex = InnerProductSIMDNeon(q, b + static_cast<size_t>(p.second) * d, d);
        hp(fine, ex, p.second, k);
    }

    out.clear();
    out.reserve(k);
    while (!fine.empty())
    {
        out.push_back(fine.top());
        fine.pop();
    }
}
