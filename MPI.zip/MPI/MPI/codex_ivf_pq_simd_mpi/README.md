# codex_ivf_pq_simd_mpi

This is a basic IVF-PQ-SIMD MPI baseline:

1. rank 0 trains global IVF centroids and PQ codebooks, or loads them from `files/`;
2. base vectors are split across MPI ranks;
3. each rank keeps its local inverted lists and performs local IVF-PQ-SIMD search;
4. rank 0 merges local top-k results into global top-k.

Compile in this folder:

```sh
mpic++ main.cc -o main -O2 -std=c++17 -I../..
```

If you use the flat remote `~/ann` layout, copy both `main.cc` and `ivf_pq_mpi_local.h` into `~/ann/`, then compile:

```sh
cd ~/ann
mpic++ main.cc -o main -O2 -std=c++17
```

Offline build:

```sh
qsub qsub_build.sh
```

Typical workflow:

```sh
cd ~/ann
mpic++ main.cc -o main -O2 -std=c++17 -I../..
qsub qsub_build.sh
qsub qsub_mpi_1node.sh
qsub qsub_mpi.sh
qsub qsub_compare_scale_1node.sh
qsub qsub_compare_scale_2node.sh
```

Useful knobs:

```sh
export ANN_NP_ONLY=12
export ANN_P=1000
export ANN_LOCAL_K=10
export ANN_USE_PREBUILT=1
```

Scripts:

- `qsub_build.sh`: offline-build global IVF/PQ files into `files/`
- `qsub_mpi_1node.sh`: 1 node, 8 MPI ranks, default nprobe sweep if `ANN_NP_ONLY=0`
- `qsub_mpi.sh`: 2 nodes, 16 MPI ranks, default nprobe sweep if `ANN_NP_ONLY=0`
- `qsub_compare_scale_1node.sh`: compare `MPI=8,4,2,1` at fixed `nprobe`
- `qsub_compare_scale_2node.sh`: compare `MPI=16,8,4,2` at fixed `nprobe`

Runtime timing output includes:

- `build_ms[min/avg/max]`
- `points[min/avg/max]`
- `search_ms[min/avg/max]`
- `gather_ms[min/avg/max]`
- `merge_ms[min/avg/max]`
- `total_ms[min/avg/max]`
- `qavg_us[min/avg/max]`
- `qmax_us`
- `rank0_query_us p50/p95/p99/max`

Index mode:

- `index_mode=train`: no prebuilt IVF/PQ files were found, so training/encoding happened in this run
- `index_mode=load`: prebuilt files were loaded from `files/`, so offline training was excluded from the search run
