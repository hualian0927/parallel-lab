#pragma once
// ===================================================================
// IVF OpenMP → MPI 迁移 (§4.1 IVF-SIMD迁移, 3分)
// 将 IVF-baseline 优化.cc 的3种OpenMP并行策略迁移到MPI:
//   尝试1: 粗排并行(负优化) → MPI不迁移(单进程计算量太小)
//   尝试2: 精排簇并行(dynamic) → MPI簇级分发
//   尝试3: Query批量并行(best) → MPI query分发 ← 本实验聚焦
// 本地搜索复用 ivf_train.h::ivf_simd_search 的串行核心(含InnerProductSIMDNeon)
// ===================================================================
#include <algorithm>
#include <cstdlib>
#include <cstring>
#include <fstream>
#include <iostream>
#include <limits>
#include <mpi.h>
#include <queue>
#include <set>
#include <vector>

struct IVFList { std::vector<int> ids; };
using Heap = std::priority_queue<std::pair<float, int>>;

inline void hp(Heap& h, float d, int id, size_t k) {
    if(h.size()<k)h.push({d,id});else if(d<h.top().first){h.pop();h.push({d,id});}
}
inline float l2d(const float* a, const float* b, size_t d) {
    float s=0;for(size_t i=0;i<d;++i){float df=a[i]-b[i];s+=df*df;}return s;
}
inline float ip_simd(const float* a, const float* b, size_t d) {
    float s=0;for(size_t i=0;i<d;++i)s+=a[i]*b[i];return 1.0f-s;
}

// ---- IVF训练 (串行, 同 ivf_train.h) ----
inline void train_ivf(const float* b, size_t n, size_t d, int K,
                      std::vector<float>& cent, int it=12) {
    cent.resize(K*d);for(int k=0;k<K;++k){int ri=rand()%n;std::memcpy(cent.data()+k*d,b+ri*d,d*4);}
    std::vector<int> as(n);std::vector<float>nc(K*d);std::vector<int>cn(K);
    for(int t=0;t<it;++t){for(size_t i=0;i<n;++i){float be=1e30f;int bk=0;
        for(int k=0;k<K;++k){float dt=l2d(b+i*d,cent.data()+k*d,d);if(dt<be){be=dt;bk=k;}}as[i]=bk;}
        std::fill(nc.begin(),nc.end(),0);std::fill(cn.begin(),cn.end(),0);
        for(size_t i=0;i<n;++i){int k=as[i];cn[k]++;for(size_t j=0;j<d;++j)nc[k*d+j]+=b[i*d+j];}
        for(int k=0;k<K;++k)if(cn[k]>0)for(size_t j=0;j<d;++j)cent[k*d+j]=nc[k*d+j]/cn[k];}
}
inline std::vector<IVFList> build_ivf(const float* b, size_t n, size_t d, int K,
                                      const std::vector<float>& cent) {
    std::vector<IVFList> ls(K);
    for(size_t i=0;i<n;++i){float be=1e30f;int bk=0;
        for(int k=0;k<K;++k){float dt=l2d(b+i*d,cent.data()+k*d,d);if(dt<be){be=dt;bk=k;}}ls[bk].ids.push_back((int)i);}
    return ls;
}

// ---- IVF-SIMD 串行搜索 (从 ivf_train.h::ivf_simd_search 提取核心, 去OpenMP) ----
// 尝试3迁移: 每进程独立调用此函数处理自己的query子集
inline Heap ivf_simd_serial(const std::vector<float>& cent, const std::vector<IVFList>& ls,
    const float* b, const float* q, size_t d, size_t k, int np) {
    int K=(int)cent.size()/(int)d;
    // 粗排
    Heap coarse;
    for(int c=0;c<K;++c){float dt=ip_simd(q,cent.data()+c*d,d);hp(coarse,dt,c,np);}
    // 精排
    Heap fine;
    while(!coarse.empty()){int ci=coarse.top().second;coarse.pop();
        for(int vi:ls[ci].ids){float dt=ip_simd(q,b+vi*d,d);hp(fine,dt,vi,k);}}
    return fine;
}

// ---- 尝试2迁移: MPI簇级并行 (每进程处理部分probe簇) ----
inline void ivf_fine_mpi_worker(const std::vector<float>& cent, const std::vector<IVFList>& ls,
    const float* b, const float* q, size_t d, size_t k, int np,
    int cluster_start, int cluster_end, std::vector<std::pair<float,int>>& out) {
    // 先做粗排(所有进程相同, 可Bcast) → 然后各进程只扫自己的簇范围
    int K=(int)cent.size()/(int)d;Heap coarse;
    for(int c=0;c<K;++c){float dt=ip_simd(q,cent.data()+c*d,d);hp(coarse,dt,c,np);}
    std::vector<int>pr;while(!coarse.empty()){pr.push_back(coarse.top().second);coarse.pop();}
    Heap fine;int end=std::min(cluster_end,(int)pr.size());
    for(int i=cluster_start;i<end;++i){int ci=pr[i];
        for(int vi:ls[ci].ids){float dt=ip_simd(q,b+vi*d,d);hp(fine,dt,vi,k+5);}}
    out.clear();while(!fine.empty()){out.push_back(fine.top());fine.pop();}
}

template<typename T> T* ld(const std::string& p, size_t& n, size_t& d){
    std::ifstream f(p,std::ios::binary);if(!f)return nullptr;
    int32_t h[2];f.read((char*)h,8);n=h[0];d=h[1];
    T* dt=new T[n*d];f.read((char*)dt,n*d*sizeof(T));return dt;
}
