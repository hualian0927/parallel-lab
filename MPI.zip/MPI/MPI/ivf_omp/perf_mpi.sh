#!/bin/bash
# perf分析 OpenMP→MPI迁移
BIN="./main"
echo "=== perf stat ==="
perf stat -e cpu-cycles,instructions,cache-misses,context-switches,cpu-migrations -o perf_stat.txt -- mpirun -np 4 $BIN
cat perf_stat.txt
echo "=== perf record ==="
perf record -g --call-graph dwarf -e cpu-cycles:pp -o perf_record.data -- mpirun -np 4 $BIN
perf report -i perf_record.data --stdio --sort=symbol --percent-limit=1.0 | head -30
