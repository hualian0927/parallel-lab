#!/bin/sh
BIN=./main
NP=${ANN_MPI_NP:-8}
OUT=${ANN_PERF_PREFIX:-perf_ivfhnsw}

perf stat -e cpu-cycles,instructions,cache-references,cache-misses,context-switches \
    -o ${OUT}_stat.txt -- mpiexec -np ${NP} ${BIN}

perf record -g --call-graph dwarf -o ${OUT}.data -- mpiexec -np ${NP} ${BIN}
perf report -i ${OUT}.data --stdio --sort=symbol --percent-limit=1.0 > ${OUT}_report.txt

