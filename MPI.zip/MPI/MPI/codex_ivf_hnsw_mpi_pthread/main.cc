#include <algorithm>
#include <atomic>
#include <chrono>
#include <cstdlib>
#include <cstring>
#include <iostream>
#include <memory>
#include <pthread.h>
#include <string>
#include <vector>
#include "hnswlib/hnswlib/hnswlib.h"
#include "../codex_graph_index_common/common.h"

using namespace hnswlib;

static inline int env_i(const char *name, int defv)
{
    const char *s = std::getenv(name);
    if (!s || !*s)
        return defv;
    int v = std::atoi(s);
    return v > 0 ? v : defv;
}

static inline std::string local_files_dir()
{
    const char *s = std::getenv("ANN_FILES_DIR");
    return (s && *s) ? std::string(s) : std::string("files");
}

static inline std::string local_files_path(const std::string &name)
{
    std::string dir = local_files_dir();
    if (!dir.empty() && (dir.back() == '/' || dir.back() == '\\'))
        return dir + name;
    return dir + "/" + name;
}

static void train_ivf(const float *base, size_t n, size_t d, int K, std::vector<float> &cent, int it = 6)
{
    cent.resize((size_t)K * d);
    for (int k = 0; k < K; ++k)
        std::memcpy(cent.data() + (size_t)k * d, base + (size_t)(k % n) * d, d * sizeof(float));

    std::vector<int> as(n);
    std::vector<float> nc((size_t)K * d);
    std::vector<int> cn(K);
    for (int t = 0; t < it; ++t)
    {
        for (size_t i = 0; i < n; ++i)
        {
            float best = 1e30f;
            int bk = 0;
            for (int k = 0; k < K; ++k)
            {
                float dist = l2_dist(base + i * d, cent.data() + (size_t)k * d, d);
                if (dist < best)
                {
                    best = dist;
                    bk = k;
                }
            }
            as[i] = bk;
        }
        std::fill(nc.begin(), nc.end(), 0.0f);
        std::fill(cn.begin(), cn.end(), 0);
        for (size_t i = 0; i < n; ++i)
        {
            int k = as[i];
            ++cn[k];
            for (size_t j = 0; j < d; ++j)
                nc[(size_t)k * d + j] += base[i * d + j];
        }
        for (int k = 0; k < K; ++k)
            if (cn[k] > 0)
                for (size_t j = 0; j < d; ++j)
                    cent[(size_t)k * d + j] = nc[(size_t)k * d + j] / cn[k];
    }
}

struct ClusterIndex
{
    int cid = -1;
    std::unique_ptr<HierarchicalNSW<float>> index;
};

struct ThreadStat
{
    double work_us = 0.0;
    size_t tasks = 0;
};

static std::string centroids_path(int K)
{
    return local_files_path("codex_ivf_hnsw_centroids_K" + std::to_string(K) + ".bin");
}

static std::string cluster_index_path(int sz, int rank, int K, int cid, int M, int efc)
{
    return local_files_path("codex_ivf_hnsw_" + rank_tag(sz, rank) +
                            "_K" + std::to_string(K) +
                            "_c" + std::to_string(cid) +
                            "_M" + std::to_string(M) +
                            "_efc" + std::to_string(efc) + ".index");
}

static std::vector<int> select_probes(const float *q, const std::vector<float> &cent, size_t d, int K, int nprobe)
{
    Heap coarse;
    for (int c = 0; c < K; ++c)
        hp(coarse, l2_dist(q, cent.data() + (size_t)c * d, d), c, nprobe);
    std::vector<int> probes;
    while (!coarse.empty())
    {
        probes.push_back(coarse.top().second);
        coarse.pop();
    }
    return probes;
}

static void search_one_local(const float *q, size_t d, const std::vector<float> &cent,
                             const std::vector<ClusterIndex> &clusters, size_t cluster_k, size_t local_k, int K, int nprobe,
                             std::vector<MinPair> &out)
{
    Heap local;
    std::vector<int> probes = select_probes(q, cent, d, K, nprobe);
    for (int cid : probes)
    {
        if (!clusters[(size_t)cid].index)
            continue;
        auto ret = clusters[(size_t)cid].index->searchKnn(q, cluster_k);
        while (!ret.empty())
        {
            hp(local, ret.top().first, static_cast<int>(ret.top().second), local_k);
            ret.pop();
        }
    }
    out.clear();
    while (!local.empty())
    {
        out.push_back(local.top());
        local.pop();
    }
}

struct WorkerArg
{
    const float *queries;
    size_t qn, d, cluster_k, local_k;
    const std::vector<float> *cent;
    const std::vector<ClusterIndex> *clusters;
    int K, nprobe;
    int tid;
    std::atomic<size_t> *next;
    std::vector<std::vector<MinPair>> *out;
    std::vector<ThreadStat> *stats;
    std::vector<double> *query_us;
};

static void *worker(void *arg)
{
    WorkerArg *a = static_cast<WorkerArg *>(arg);
    while (true)
    {
        size_t qi = a->next->fetch_add(1);
        if (qi >= a->qn)
            break;
        auto ts = std::chrono::steady_clock::now();
        search_one_local(a->queries + qi * a->d, a->d, *a->cent, *a->clusters,
                         a->cluster_k, a->local_k, a->K, a->nprobe, (*a->out)[qi]);
        auto te = std::chrono::steady_clock::now();
        double us = std::chrono::duration<double, std::micro>(te - ts).count();
        (*a->stats)[(size_t)a->tid].work_us += us;
        (*a->stats)[(size_t)a->tid].tasks += 1;
        (*a->query_us)[qi] = us;
    }
    return nullptr;
}

static double percentile_us(std::vector<double> v, double p)
{
    if (v.empty())
        return 0.0;
    std::sort(v.begin(), v.end());
    size_t idx = static_cast<size_t>(p * (v.size() - 1));
    return v[idx];
}

int main(int argc, char **argv)
{
    MPI_Init(&argc, &argv);
    int rank = 0, sz = 1;
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
    MPI_Comm_size(MPI_COMM_WORLD, &sz);

    double t_build0 = MPI_Wtime();

    size_t tn = 0, dim = 0, qn = 0, gd = 0;
    float *base = nullptr, *queries = nullptr;
    int *gt = nullptr;
    if (rank == 0)
    {
        std::string dp = "/anndata/";
        queries = load_fbin_like<float>(dp + "DEEP100K.query.fbin", qn, dim);
        base = load_fbin_like<float>(dp + "DEEP100K.base.100k.fbin", tn, dim);
        gt = load_fbin_like<int>(dp + "DEEP100K.gt.query.100k.top100.bin", qn, gd);
        qn = 2000;
    }

    MPI_Bcast(&tn, 1, MPI_UNSIGNED_LONG_LONG, 0, MPI_COMM_WORLD);
    MPI_Bcast(&dim, 1, MPI_UNSIGNED_LONG_LONG, 0, MPI_COMM_WORLD);
    MPI_Bcast(&qn, 1, MPI_UNSIGNED_LONG_LONG, 0, MPI_COMM_WORLD);
    MPI_Bcast(&gd, 1, MPI_UNSIGNED_LONG_LONG, 0, MPI_COMM_WORLD);

    const size_t k = 10;
    const int Kivf = env_i("ANN_KIVF", 64);
    const int nprobe = env_i("ANN_NPROBE", 7);
    const int M = env_i("ANN_HNSW_M", 16);
    const int efc = env_i("ANN_EFC", 150);
    const int ef = env_i("ANN_EF", 80);
    const int nth = env_i("ANN_THREADS", 1);
    const size_t cluster_k = (size_t)std::max(env_i("ANN_CLUSTER_K", 20), (int)k);
    const size_t local_k = (size_t)std::max(env_i("ANN_LOCAL_K", 24), (int)cluster_k);
    const bool build_only = env_i("ANN_BUILD_ONLY", 0) != 0;

    std::vector<float> centroids;
    if (rank == 0)
    {
        std::string cpath = centroids_path(Kivf);
        if (!load_vector_f32(cpath, centroids))
        {
            train_ivf(base, tn, dim, Kivf, centroids);
            save_vector_f32(cpath, centroids);
        }
    }
    bcast_vector_f32(centroids, rank);

    std::vector<int> group_of_vec, owner_of_group(Kivf);
    for (int c = 0; c < Kivf; ++c)
        owner_of_group[(size_t)c] = c % sz;
    if (rank == 0)
    {
        group_of_vec.resize(tn);
        for (size_t i = 0; i < tn; ++i)
        {
            float best = 1e30f;
            int bk = 0;
            for (int c = 0; c < Kivf; ++c)
            {
                float dist = l2_dist(base + i * dim, centroids.data() + (size_t)c * dim, dim);
                if (dist < best)
                {
                    best = dist;
                    bk = c;
                }
            }
            group_of_vec[i] = bk;
        }
    }
    bcast_vector_i32(group_of_vec, rank);

    std::vector<float> local_data;
    std::vector<int> local_ids, local_clusters;
    scatter_grouped_vectors(base, tn, dim, group_of_vec, owner_of_group, rank, sz,
                            local_data, local_ids, local_clusters);

    InnerProductSpace space(dim);
    std::vector<std::vector<int>> pos_by_cluster(Kivf);
    for (size_t i = 0; i < local_clusters.size(); ++i)
        pos_by_cluster[(size_t)local_clusters[i]].push_back(static_cast<int>(i));

    std::vector<ClusterIndex> clusters(Kivf);
    for (int cid = 0; cid < Kivf; ++cid)
    {
        if (owner_of_group[(size_t)cid] != rank || pos_by_cluster[(size_t)cid].empty())
            continue;
        clusters[(size_t)cid].cid = cid;
        std::string path = cluster_index_path(sz, rank, Kivf, cid, M, efc);
        if (file_exists(path))
        {
            clusters[(size_t)cid].index.reset(new HierarchicalNSW<float>(&space, path));
        }
        else
        {
            auto idx = std::unique_ptr<HierarchicalNSW<float>>(new HierarchicalNSW<float>(&space, pos_by_cluster[(size_t)cid].size(), M, efc));
            for (size_t j = 0; j < pos_by_cluster[(size_t)cid].size(); ++j)
            {
                int pos = pos_by_cluster[(size_t)cid][j];
                idx->addPoint(local_data.data() + (size_t)pos * dim, local_ids[(size_t)pos]);
            }
            idx->saveIndex(path);
            clusters[(size_t)cid].index = std::move(idx);
        }
        clusters[(size_t)cid].index->ef_ = ef;
    }
    double t_build1 = MPI_Wtime();

    if (rank == 0)
        delete[] base;

    unsigned long long local_points_ull = static_cast<unsigned long long>(local_ids.size());
    unsigned long long local_cluster_ull = 0;
    for (int cid = 0; cid < Kivf; ++cid)
        if (clusters[(size_t)cid].index)
            ++local_cluster_ull;

    double build_ms = (t_build1 - t_build0) * 1e3;
    double build_ms_min = 0.0, build_ms_max = 0.0, build_ms_sum = 0.0;
    unsigned long long points_min = 0, points_max = 0, points_sum = 0;
    unsigned long long cluster_min = 0, cluster_max = 0, cluster_sum = 0;
    MPI_Reduce(&build_ms, &build_ms_min, 1, MPI_DOUBLE, MPI_MIN, 0, MPI_COMM_WORLD);
    MPI_Reduce(&build_ms, &build_ms_max, 1, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD);
    MPI_Reduce(&build_ms, &build_ms_sum, 1, MPI_DOUBLE, MPI_SUM, 0, MPI_COMM_WORLD);
    MPI_Reduce(&local_points_ull, &points_min, 1, MPI_UNSIGNED_LONG_LONG, MPI_MIN, 0, MPI_COMM_WORLD);
    MPI_Reduce(&local_points_ull, &points_max, 1, MPI_UNSIGNED_LONG_LONG, MPI_MAX, 0, MPI_COMM_WORLD);
    MPI_Reduce(&local_points_ull, &points_sum, 1, MPI_UNSIGNED_LONG_LONG, MPI_SUM, 0, MPI_COMM_WORLD);
    MPI_Reduce(&local_cluster_ull, &cluster_min, 1, MPI_UNSIGNED_LONG_LONG, MPI_MIN, 0, MPI_COMM_WORLD);
    MPI_Reduce(&local_cluster_ull, &cluster_max, 1, MPI_UNSIGNED_LONG_LONG, MPI_MAX, 0, MPI_COMM_WORLD);
    MPI_Reduce(&local_cluster_ull, &cluster_sum, 1, MPI_UNSIGNED_LONG_LONG, MPI_SUM, 0, MPI_COMM_WORLD);

    if (build_only)
    {
        if (rank == 0)
            std::cout << "[Codex-IVF-HNSW] build only finished, K=" << Kivf
                      << " nprobe=" << nprobe << " M=" << M << " efc=" << efc
                      << " build_ms[min/avg/max]=" << std::fixed << std::setprecision(3)
                      << build_ms_min << "/" << (build_ms_sum / sz) << "/" << build_ms_max
                      << " points[min/avg/max]=" << points_min << "/" << (points_sum / sz) << "/" << points_max
                      << " clusters[min/avg/max]=" << cluster_min << "/" << (cluster_sum / sz) << "/" << cluster_max
                      << "\n";
        delete[] queries;
        delete[] gt;
        MPI_Finalize();
        return 0;
    }

    if (rank != 0)
    {
        queries = new float[qn * dim];
        gt = new int[qn * gd];
    }
    MPI_Bcast(queries, static_cast<int>(qn * dim), MPI_FLOAT, 0, MPI_COMM_WORLD);
    MPI_Bcast(gt, static_cast<int>(qn * gd), MPI_INT, 0, MPI_COMM_WORLD);

    if (rank == 0)
        std::cout << "[Codex-IVF-HNSW] MPI=" << sz
                  << " pthread=" << nth
                  << " K=" << Kivf
                  << " nprobe=" << nprobe
                  << " cluster_k=" << cluster_k
                  << " local_k=" << local_k
                  << " ef=" << ef
                  << " build_ms[min/avg/max]=" << std::fixed << std::setprecision(3)
                  << build_ms_min << "/" << (build_ms_sum / sz) << "/" << build_ms_max
                  << " points[min/avg/max]=" << points_min << "/" << (points_sum / sz) << "/" << points_max
                  << " clusters[min/avg/max]=" << cluster_min << "/" << (cluster_sum / sz) << "/" << cluster_max
                  << "\n";

    std::vector<std::vector<MinPair>> local_results(qn);
    std::vector<ThreadStat> thread_stats((size_t)nth);
    std::vector<double> query_us(qn, 0.0);
    std::atomic<size_t> next(0);
    std::vector<pthread_t> th(nth);
    std::vector<WorkerArg> args((size_t)nth);

    MPI_Barrier(MPI_COMM_WORLD);
    double ts = MPI_Wtime();
    for (int t = 0; t < nth; ++t)
    {
        args[(size_t)t] = {queries, qn, dim, cluster_k, local_k, &centroids, &clusters, Kivf, nprobe, t, &next, &local_results, &thread_stats, &query_us};
        pthread_create(&th[t], nullptr, worker, &args[(size_t)t]);
    }
    for (int t = 0; t < nth; ++t)
        pthread_join(th[t], nullptr);
    double tsearch = MPI_Wtime();

    const float invalid = 1e30f;
    std::vector<float> sendbuf(qn * local_k * 2, invalid);
    for (size_t qi = 0; qi < qn; ++qi)
    {
        size_t base = qi * local_k * 2;
        for (size_t j = 0; j < local_k; ++j)
        {
            if (j < local_results[qi].size())
            {
                sendbuf[base + j * 2] = local_results[qi][j].first;
                sendbuf[base + j * 2 + 1] = (float)local_results[qi][j].second;
            }
            else
            {
                sendbuf[base + j * 2] = invalid;
                sendbuf[base + j * 2 + 1] = -1.0f;
            }
        }
    }

    std::vector<float> gatherbuf;
    int send_count = (int)sendbuf.size();
    if (rank == 0)
        gatherbuf.resize((size_t)sz * sendbuf.size());
    MPI_Gather(sendbuf.data(), send_count, MPI_FLOAT,
               rank == 0 ? gatherbuf.data() : nullptr, send_count, MPI_FLOAT,
               0, MPI_COMM_WORLD);
    double tgather = MPI_Wtime();

    float total_recall = 0.0f;
    if (rank == 0)
    {
        for (size_t qi = 0; qi < qn; ++qi)
        {
            Heap g;
            for (int r = 0; r < sz; ++r)
            {
                size_t base = ((size_t)r * qn + qi) * local_k * 2;
                for (size_t j = 0; j < local_k; ++j)
                {
                    int id = (int)gatherbuf[base + j * 2 + 1];
                    if (id >= 0 && gatherbuf[base + j * 2] < invalid * 0.5f)
                        hp(g, gatherbuf[base + j * 2], id, k);
                }
            }
            total_recall += recall_of_heap(g, gt + qi * gd, k);
        }
    }
    double te = MPI_Wtime();

    double local_search_ms = (tsearch - ts) * 1e3;
    double local_gather_ms = (tgather - tsearch) * 1e3;
    double local_merge_ms = rank == 0 ? (te - tgather) * 1e3 : 0.0;
    double local_total_ms = (te - ts) * 1e3;
    double search_min = 0.0, search_max = 0.0, search_sum = 0.0;
    double gather_min = 0.0, gather_max = 0.0, gather_sum = 0.0;
    double merge_min = 0.0, merge_max = 0.0, merge_sum = 0.0;
    double total_min = 0.0, total_max = 0.0, total_sum = 0.0;
    MPI_Reduce(&local_search_ms, &search_min, 1, MPI_DOUBLE, MPI_MIN, 0, MPI_COMM_WORLD);
    MPI_Reduce(&local_search_ms, &search_max, 1, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD);
    MPI_Reduce(&local_search_ms, &search_sum, 1, MPI_DOUBLE, MPI_SUM, 0, MPI_COMM_WORLD);
    MPI_Reduce(&local_gather_ms, &gather_min, 1, MPI_DOUBLE, MPI_MIN, 0, MPI_COMM_WORLD);
    MPI_Reduce(&local_gather_ms, &gather_max, 1, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD);
    MPI_Reduce(&local_gather_ms, &gather_sum, 1, MPI_DOUBLE, MPI_SUM, 0, MPI_COMM_WORLD);
    MPI_Reduce(&local_merge_ms, &merge_min, 1, MPI_DOUBLE, MPI_MIN, 0, MPI_COMM_WORLD);
    MPI_Reduce(&local_merge_ms, &merge_max, 1, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD);
    MPI_Reduce(&local_merge_ms, &merge_sum, 1, MPI_DOUBLE, MPI_SUM, 0, MPI_COMM_WORLD);
    MPI_Reduce(&local_total_ms, &total_min, 1, MPI_DOUBLE, MPI_MIN, 0, MPI_COMM_WORLD);
    MPI_Reduce(&local_total_ms, &total_max, 1, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD);
    MPI_Reduce(&local_total_ms, &total_sum, 1, MPI_DOUBLE, MPI_SUM, 0, MPI_COMM_WORLD);

    double qsum = 0.0;
    double qmax = 0.0;
    for (size_t qi = 0; qi < qn; ++qi)
    {
        qsum += query_us[qi];
        if (query_us[qi] > qmax)
            qmax = query_us[qi];
    }
    double qavg = qn ? qsum / qn : 0.0;
    double qp50 = percentile_us(query_us, 0.50);
    double qp95 = percentile_us(query_us, 0.95);
    double qp99 = percentile_us(query_us, 0.99);
    double qavg_max = 0.0, qavg_min = 0.0, qavg_sum = 0.0, qmax_max = 0.0;
    MPI_Reduce(&qavg, &qavg_min, 1, MPI_DOUBLE, MPI_MIN, 0, MPI_COMM_WORLD);
    MPI_Reduce(&qavg, &qavg_max, 1, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD);
    MPI_Reduce(&qavg, &qavg_sum, 1, MPI_DOUBLE, MPI_SUM, 0, MPI_COMM_WORLD);
    MPI_Reduce(&qmax, &qmax_max, 1, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD);

    if (rank == 0)
    {
        size_t task_min = thread_stats.empty() ? 0 : thread_stats[0].tasks;
        size_t task_max = 0;
        size_t task_sum = 0;
        double work_min = thread_stats.empty() ? 0.0 : thread_stats[0].work_us;
        double work_max = 0.0;
        double work_sum = 0.0;
        for (int t = 0; t < nth; ++t)
        {
            task_min = std::min(task_min, thread_stats[(size_t)t].tasks);
            task_max = std::max(task_max, thread_stats[(size_t)t].tasks);
            task_sum += thread_stats[(size_t)t].tasks;
            work_min = std::min(work_min, thread_stats[(size_t)t].work_us);
            work_max = std::max(work_max, thread_stats[(size_t)t].work_us);
            work_sum += thread_stats[(size_t)t].work_us;
        }

        std::cout << std::fixed << std::setprecision(3)
                  << "[Codex-IVF-HNSW] avg_lat=" << (te - ts) * 1e6 / qn
                  << " us recall=" << total_recall / qn
                  << " search_ms[min/avg/max]=" << search_min << "/" << (search_sum / sz) << "/" << search_max
                  << " gather_ms[min/avg/max]=" << gather_min << "/" << (gather_sum / sz) << "/" << gather_max
                  << " merge_ms[min/avg/max]=" << merge_min << "/" << (merge_sum / sz) << "/" << merge_max
                  << " total_ms[min/avg/max]=" << total_min << "/" << (total_sum / sz) << "/" << total_max
                  << " qavg_us[min/avg/max]=" << qavg_min << "/" << (qavg_sum / sz) << "/" << qavg_max
                  << " qmax_us=" << qmax_max
                  << "\n";
        std::cout << "[Codex-IVF-HNSW] rank0_query_us p50/p95/p99/max="
                  << qp50 << "/" << qp95 << "/" << qp99 << "/" << qmax
                  << " rank0_thread_tasks min/avg/max=" << task_min << "/" << (task_sum / nth) << "/" << task_max
                  << " rank0_thread_work_us min/avg/max=" << work_min << "/" << (work_sum / nth) << "/" << work_max
                  << "\n";
        for (int t = 0; t < nth; ++t)
        {
            std::cout << "[Codex-IVF-HNSW] rank0_thread[" << t << "]"
                      << " tasks=" << thread_stats[(size_t)t].tasks
                      << " work_us=" << thread_stats[(size_t)t].work_us
                      << "\n";
        }
    }

    delete[] queries;
    delete[] gt;
    MPI_Finalize();
    return 0;
}
