// ===================================================================
// IVF-Hybrid-MPI (§4.1 MPI+Pthread混合, 4分)
// 核心对比: 固定总核心8, 测试不同MPI/pthread配比
//   (np=8,t=1) 纯MPI vs (np=4,t=2) vs (np=2,t=4) vs (np=1,t=8) 纯pthread
// 分析: 进程启动开销 vs 线程同步开销, 通信/计算比
// 编译: mpic++ main.cc -o main -O2 -lpthread -std=c++17 -I../..
// ===================================================================
#include "ivf_hybrid.h"

int main(int argc, char** argv) {
    MPI_Init(&argc, &argv);
    int rank, sz; MPI_Comm_rank(MPI_COMM_WORLD, &rank); MPI_Comm_size(MPI_COMM_WORLD, &sz);
    srand(42+rank);
    const int nth = 2; // 每进程 pthread 数

    size_t tn=0,dim=0,qn=0,gd=0;
    float *ab=nullptr,*qu=nullptr; int* gt=nullptr;
    if(rank==0){std::string dp="/anndata/";
        qu=ld<float>(dp+"DEEP100K.query.fbin",qn,dim);
        ab=ld<float>(dp+"DEEP100K.base.100k.fbin",tn,dim);
        gt=ld<int>(dp+"DEEP100K.gt.query.100k.top100.bin",qn,gd); qn=2000;}

    MPI_Bcast(&tn,1,MPI_UNSIGNED_LONG_LONG,0,MPI_COMM_WORLD);
    MPI_Bcast(&dim,1,MPI_UNSIGNED_LONG_LONG,0,MPI_COMM_WORLD);
    MPI_Bcast(&qn,1,MPI_UNSIGNED_LONG_LONG,0,MPI_COMM_WORLD);
    MPI_Bcast(&gd,1,MPI_UNSIGNED_LONG_LONG,0,MPI_COMM_WORLD);

    // Scatterv 数据分发
    size_t ln=tn/sz,rm=tn%sz;
    std::vector<int>sc(sz),ds(sz); size_t off=0;
    for(int i=0;i<sz;++i){sc[i]=(int)((ln+(i<(int)rm?1:0))*dim);ds[i]=(int)(off*dim);off+=ln+(i<(int)rm?1:0);}
    size_t mn=ln+(rank<(int)rm?1:0);
    std::vector<float>lb(mn*dim);
    MPI_Scatterv(ab,sc.data(),ds.data(),MPI_FLOAT,lb.data(),(int)(mn*dim),MPI_FLOAT,0,MPI_COMM_WORLD);
    int goff=ds[rank]/(int)dim;
    if(rank==0)delete[] ab;

    // ---- 复用 ivf_pthread.h: pthread训练+构建 ----
    const int K=128,np=8;
    std::vector<float>cent;
    train_ivf_pthread(lb.data(),mn,dim,K,cent,nth);
    auto ls=build_ivf_pthread(lb.data(),mn,dim,K,cent,nth);
    for(auto&L:ls)for(int&vid:L.ids)vid+=goff; // adjust IDs

    if(rank!=0){qu=new float[qn*dim];gt=new int[qn*gd];}
    MPI_Bcast(qu,(int)(qn*dim),MPI_FLOAT,0,MPI_COMM_WORLD);
    MPI_Bcast(gt,(int)(qn*gd),MPI_INT,0,MPI_COMM_WORLD);

    const size_t k=10;
    double ts=MPI_Wtime();

    // ---- 复用 ivf_pthread.h: inter-query batch pthread search ----
    std::vector<float> lats, recs;
    ivf_simd_batch_pthread(cent,ls,lb.data(),qu,dim,qn,k,np,nth,lats,recs,gt,gd);

    // MPI Gatherv: 各进程的 per-query latency/recall
    //   (简化: 仅 rank 0 统计平均recall; 完整merge见ivf_basic)
    float local_rec=0; for(size_t i=0;i<qn;++i)local_rec+=recs[i];
    float global_rec=0;
    MPI_Reduce(&local_rec,&global_rec,1,MPI_FLOAT,MPI_SUM,0,MPI_COMM_WORLD);

    double te=MPI_Wtime();
    if(rank==0){std::cout<<std::fixed<<std::setprecision(3);
        std::cout<<"[IVF-Hybrid] MPI_procs="<<sz<<" pthreads_per_proc="<<nth
            <<" total_cores="<<sz*nth<<" K="<<K<<" np="<<np
            <<" wall="<<(te-ts)*1000<<"ms avg_lat="<<(te-ts)*1e6/qn<<"us"
            <<" recall="<<global_rec/(qn*sz)<<"\n";}

    delete[] qu;delete[] gt;MPI_Finalize();return 0;
}
