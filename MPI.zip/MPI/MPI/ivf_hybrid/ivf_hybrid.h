#pragma once
// ===================================================================
// IVF-Hybrid-MPI (§4.1 MPI+Pthread混合, 4分)
// 直接复用 ivf_pthread.h 全部功能:
//   train_ivf_pthread / build_ivf_pthread (pthread训练+构建)
//   ivf_simd_batch_pthread (inter-query batch, atomic fetch_add)
//   ivf_simd_fine_pthread (intra-query fine-parallel)
// MPI层: Scatterv数据分发 + Bcast query + Gatherv归并
// 总并行度 = MPI_procs × pthread_threads
// ===================================================================
#include <algorithm>
#include <chrono>
#include <cstdlib>
#include <cstring>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <mpi.h>
#include <queue>
#include <set>
#include <sys/time.h>
#include <vector>
#include "hnswlib/hnswlib/simd_utils.h"
#include "hnswlib/hnswlib/ivf_pthread.h"

template<typename T> T* ld(const std::string& p, size_t& n, size_t& d){
    std::ifstream f(p,std::ios::binary);if(!f)return nullptr;
    int32_t h[2];f.read((char*)h,8);n=h[0];d=h[1];
    T* dt=new T[n*d];f.read((char*)dt,n*d*sizeof(T));return dt;
}
