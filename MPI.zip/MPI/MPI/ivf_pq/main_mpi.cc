// IVF-PQ-MPI (纯MPI, 复用fa_codec.h)
#include <chrono><iomanip>"ivf_pq_train_mpi.h"
int main(int argc,char**argv){MPI_Init(&argc,&argv);int rank,sz;MPI_Comm_rank(MPI_COMM_WORLD,&rank);MPI_Comm_size(MPI_COMM_WORLD,&sz);srand(42+rank);
    size_t tn=0,dim=0,qn=0,gd=0;float*ab=nullptr,*qu=nullptr;int*gt=nullptr;
    if(rank==0){std::string dp="/anndata/";qu=ld<float>(dp+"DEEP100K.query.fbin",qn,dim);ab=ld<float>(dp+"DEEP100K.base.100k.fbin",tn,dim);gt=ld<int>(dp+"DEEP100K.gt.query.100k.top100.bin",qn,gd);qn=2000;}
    MPI_Bcast(&tn,1,MPI_UNSIGNED_LONG_LONG,0,MPI_COMM_WORLD);MPI_Bcast(&dim,1,MPI_UNSIGNED_LONG_LONG,0,MPI_COMM_WORLD);MPI_Bcast(&qn,1,MPI_UNSIGNED_LONG_LONG,0,MPI_COMM_WORLD);MPI_Bcast(&gd,1,MPI_UNSIGNED_LONG_LONG,0,MPI_COMM_WORLD);
    size_t ln=tn/sz,rm=tn%sz;std::vector<int>sc(sz),ds(sz);size_t off=0;
    for(int i=0;i<sz;++i){size_t ni=ln+(size_t)(i<(int)rm?1:0);sc[i]=(int)(ni*dim);ds[i]=(int)(off*dim);off+=ni;}
    size_t mn=ln+(size_t)(rank<(int)rm?1:0);std::vector<float>lb(mn*dim);
    MPI_Scatterv(ab,sc.data(),ds.data(),MPI_FLOAT,lb.data(),(int)(mn*dim),MPI_FLOAT,0,MPI_COMM_WORLD);int goff=(int)(ds[rank]/dim);
    const int K=200,M=4,Kpq=256;const size_t P=1000,k=10;int np_vals[]={8,12,16,20,24,32};
    std::vector<float>cent;fa_engine::Codec codec;
    if(rank==0){train_ivf(ab,tn,dim,K,cent,12);codec.build(ab,tn,dim,M,Kpq,6);std::cout<<"[IVF-PQ-MPI] K="<<K<<" M="<<M<<" trained\n";}
    bcast_vec(cent,rank);bcast_codec(codec,rank);if(rank==0)delete[] ab;
    auto lists=build_ivf(lb.data(),mn,dim,K,cent);
    if(rank!=0){qu=new float[qn*dim];gt=new int[qn*gd];}MPI_Bcast(qu,(int)(qn*dim),MPI_FLOAT,0,MPI_COMM_WORLD);MPI_Bcast(gt,(int)(qn*gd),MPI_INT,0,MPI_COMM_WORLD);
    for(int ni=0;ni<(int)(sizeof(np_vals)/sizeof(np_vals[0]));++ni){int np=np_vals[ni];double ts=MPI_Wtime();float tr=0;
    for(size_t i=0;i<qn;++i){std::vector<std::pair<float,int>>lr;ivf_pq_search(lb.data(),codec,cent,lists,qu+i*dim,dim,k,np,P,lr);for(auto&p:lr)p.second+=goff;
        int lc=(int)lr.size();std::vector<float>lbuf(lc*2);for(int j=0;j<lc;++j){lbuf[j*2]=lr[j].first;lbuf[j*2+1]=(float)lr[j].second;}
        std::vector<int>ac(sz);MPI_Gather(&lc,1,MPI_INT,ac.data(),1,MPI_INT,0,MPI_COMM_WORLD);std::vector<float>abuf;std::vector<int>rd(sz),acf(sz);
        if(rank==0){int t=0;for(int j=0;j<sz;++j){acf[j]=ac[j]*2;rd[j]=t*2;t+=ac[j];}abuf.resize(t*2);}
        MPI_Gatherv(lbuf.data(),lc*2,MPI_FLOAT,abuf.data(),acf.data(),rd.data(),MPI_FLOAT,0,MPI_COMM_WORLD);
        if(rank==0){Heap g;int tp=(int)abuf.size()/2;for(int j=0;j<tp;++j)hp(g,abuf[j*2],(int)abuf[j*2+1],k);std::set<int>gs(gt+i*gd,gt+i*gd+k);size_t h=0;Heap t2=g;while(!t2.empty()){if(gs.count(t2.top().second))++h;t2.pop();}tr+=(float)h/k;}}
    double te=MPI_Wtime();if(rank==0)std::cout<<"[IVF-PQ-MPI] np="<<np<<" lat="<<(te-ts)*1e6/qn<<"us recall="<<tr/qn<<"\n";}
    delete[] qu;delete[] gt;MPI_Finalize();return 0;}
