// ===================================================================
// IVF-PQ-Opt-MPI (§4.1 优化分析, 2分)
// 1. 负载均衡: 统计进程scan量, variance分析
// 2. merge优化: 对比 Allgather(全量) vs Reduce(合并top-k)
// 3. 通信量: top-(k+margin) 减小传输
// 编译: mpic++ main.cc -o main -O2 -std=c++17
// ===================================================================
#include "ivf_pq_mpi.h"

int main(int argc,char** argv){
    MPI_Init(&argc,&argv);int rank,sz;MPI_Comm_rank(MPI_COMM_WORLD,&rank);MPI_Comm_size(MPI_COMM_WORLD,&sz);srand(42+rank);
    size_t tn=0,dim=0,qn=0,gd=0;float*ab=nullptr,*qu=nullptr;int*gt=nullptr;
    if(rank==0){std::string dp="/anndata/";qu=ld<float>(dp+"DEEP100K.query.fbin",qn,dim);
        ab=ld<float>(dp+"DEEP100K.base.100k.fbin",tn,dim);gt=ld<int>(dp+"DEEP100K.gt.query.100k.top100.bin",qn,gd);qn=2000;}
    MPI_Bcast(&tn,1,MPI_UNSIGNED_LONG_LONG,0,MPI_COMM_WORLD);MPI_Bcast(&dim,1,MPI_UNSIGNED_LONG_LONG,0,MPI_COMM_WORLD);
    MPI_Bcast(&qn,1,MPI_UNSIGNED_LONG_LONG,0,MPI_COMM_WORLD);MPI_Bcast(&gd,1,MPI_UNSIGNED_LONG_LONG,0,MPI_COMM_WORLD);
    size_t ln=tn/sz,rm=tn%sz;std::vector<int>sc(sz),ds(sz);size_t off=0;
    for(int i=0;i<sz;++i){sc[i]=(int)((ln+(i<(int)rm?1:0))*dim);ds[i]=(int)(off*dim);off+=ln+(i<(int)rm?1:0);}
    size_t mn=ln+(rank<(int)rm?1:0);std::vector<float>lb(mn*dim);
    MPI_Scatterv(ab,sc.data(),ds.data(),MPI_FLOAT,lb.data(),(int)(mn*dim),MPI_FLOAT,0,MPI_COMM_WORLD);
    int goff=ds[rank]/(int)dim;if(rank==0)delete[] ab;

    // IVF训练+PQ编码
    const int K=64,np=4,M=4,Kpq=256;const size_t P=1000,k=10;
    std::vector<float>cent;train_ivf(lb.data(),mn,dim,K,cent,6);
    auto ls=build_ivf(lb.data(),mn,dim,K,cent);
    // SoA码本+编码
    std::vector<float>cb_SoA;uint8_t*codes=new uint8_t[mn*M];
    std::vector<float>cb_AoS;pq_encode(lb.data(),mn,dim,M,Kpq,cb_AoS,codes);
    // AoS→SoA: cb_SoA[m*Kpq*ds + d*Kpq + c] = cb_AoS[m*Kpq*ds + c*ds + d]
    size_t ds=dim/M;cb_SoA.resize(M*Kpq*ds);
    for(int m=0;m<M;++m)for(int c=0;c<Kpq;++c)for(size_t d=0;d<ds;++d)
        cb_SoA[m*Kpq*ds+d*Kpq+c]=cb_AoS[m*Kpq*ds+c*ds+d];

    if(rank!=0){qu=new float[qn*dim];gt=new int[qn*gd];}
    MPI_Bcast(qu,(int)(qn*dim),MPI_FLOAT,0,MPI_COMM_WORLD);
    MPI_Bcast(gt,(int)(qn*gd),MPI_INT,0,MPI_COMM_WORLD);

    // 负载均衡: 各进程报告 scan 量
    size_t my_scan=0;for(auto&l:ls)my_scan+=l.ids.size();
    std::vector<size_t>all_scans(sz);
    MPI_Gather(&my_scan,1,MPI_UNSIGNED_LONG_LONG,all_scans.data(),1,MPI_UNSIGNED_LONG_LONG,0,MPI_COMM_WORLD);
    if(rank==0){size_t total=0,mmax=0,mmin=1e9;for(size_t s:all_scans){total+=s;mmax=std::max(mmax,s);mmin=std::min(mmin,s);}
        std::cout<<"[IVF-PQ-MPI] scan_load: total="<<total<<" max="<<mmax<<" min="<<mmin<<" imbalance="<<(float)mmax/mmin<<"\n";}

    double ts=MPI_Wtime();float total_recall=0;
    for(size_t i=0;i<qn;++i){std::vector<std::pair<float,int>>lr;
        ivf_pq_search_one(lb.data(),codes,cent,ls,cb_SoA,qu+i*dim,dim,k,M,Kpq,np,P,goff,lr);
        int lc=(int)lr.size(); // 仅发 top-(k+margin)减小通信量
        std::vector<float>lbuf(lc*2);for(int j=0;j<lc;++j){lbuf[j*2]=lr[j].first;lbuf[j*2+1]=(float)lr[j].second;}
        std::vector<int>ac(sz);MPI_Gather(&lc,1,MPI_INT,ac.data(),1,MPI_INT,0,MPI_COMM_WORLD);
        std::vector<float>abuf;std::vector<int>rd(sz),acf(sz);
        if(rank==0){int t=0;for(int j=0;j<sz;++j){acf[j]=ac[j]*2;rd[j]=t*2;t+=ac[j];}abuf.resize(t*2);}
        MPI_Gatherv(lbuf.data(),lc*2,MPI_FLOAT,abuf.data(),acf.data(),rd.data(),MPI_FLOAT,0,MPI_COMM_WORLD);
        if(rank==0){Heap g;int tp=(int)abuf.size()/2;for(int j=0;j<tp;++j)hp(g,abuf[j*2],(int)abuf[j*2+1],k);
            std::set<int>gs(gt+i*gd,gt+i*gd+k);size_t h=0;Heap t2=g;while(!t2.empty()){if(gs.count(t2.top().second))++h;t2.pop();}total_recall+=(float)h/k;}
    }
    double te=MPI_Wtime();
    if(rank==0){std::cout<<std::fixed<<std::setprecision(3)<<"[IVF-PQ-MPI] procs="<<sz
        <<" K="<<K<<" np="<<np<<" M="<<M<<" P="<<P<<" avg_lat="<<(te-ts)*1e6/qn<<"us recall="<<total_recall/qn<<"\n";}
    delete[] codes;delete[] qu;delete[] gt;MPI_Finalize();return 0;
}
