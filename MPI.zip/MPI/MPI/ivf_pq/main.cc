// IVF-PQ MPI: 单进程先测IVF-PQ正确性, 再扩展MPI
// 编译: mpic++ main.cc -o main -O2 -std=c++17
#include "ivf_pq_mpi.h"

int main(int argc,char** argv){
    MPI_Init(&argc,&argv);int rank,sz;MPI_Comm_rank(MPI_COMM_WORLD,&rank);MPI_Comm_size(MPI_COMM_WORLD,&sz);srand(42+rank);

    size_t tn=0,dim=0,qn=0,gd=0;float*ab=nullptr,*qu=nullptr;int*gt=nullptr;
    if(rank==0){std::string dp="/anndata/";qu=ld<float>(dp+"DEEP100K.query.fbin",qn,dim);
        ab=ld<float>(dp+"DEEP100K.base.100k.fbin",tn,dim);gt=ld<int>(dp+"DEEP100K.gt.query.100k.top100.bin",qn,gd);qn=2000;}
    MPI_Bcast(&tn,1,MPI_UNSIGNED_LONG_LONG,0,MPI_COMM_WORLD);MPI_Bcast(&dim,1,MPI_UNSIGNED_LONG_LONG,0,MPI_COMM_WORLD);
    MPI_Bcast(&qn,1,MPI_UNSIGNED_LONG_LONG,0,MPI_COMM_WORLD);MPI_Bcast(&gd,1,MPI_UNSIGNED_LONG_LONG,0,MPI_COMM_WORLD);

    // Scatterv base
    size_t ln=tn/sz,rm=tn%sz;std::vector<int>sc(sz),ds(sz);size_t off=0;
    for(int i=0;i<sz;++i){sc[i]=(int)((ln+(i<(int)rm?1:0))*dim);ds[i]=(int)(off*dim);off+=ln+(i<(int)rm?1:0);}
    size_t mn=ln+(rank<(int)rm?1:0);std::vector<float>lb(mn*dim);
    MPI_Scatterv(ab,sc.data(),ds.data(),MPI_FLOAT,lb.data(),(int)(mn*dim),MPI_FLOAT,0,MPI_COMM_WORLD);
    int goff=ds[rank]/(int)dim;

    // Rank0训练IVF centroids+PQ码本(全量), Bcast, Scatterv codes
    const int K=200,np=8,M=4,Kpq=256;const size_t P=1000,k=10;
    std::vector<float>cent,cb_SoA;uint8_t*codes_all=nullptr;std::vector<uint8_t>codes(mn*M);
    if(rank==0){
        cent.resize(K*dim);train_ivf(ab,tn,dim,K,cent,10);
        codes_all=new uint8_t[tn*M];pq_train_encode(ab,tn,dim,M,Kpq,cb_SoA,codes_all,6);
        std::cout<<"[IVF-PQ] K="<<K<<" M="<<M<<" trained\n";
    }
    size_t csz=cent.size();MPI_Bcast(&csz,1,MPI_UNSIGNED_LONG_LONG,0,MPI_COMM_WORLD);
    if(rank!=0)cent.resize(csz);MPI_Bcast(cent.data(),(int)csz,MPI_FLOAT,0,MPI_COMM_WORLD);
    csz=cb_SoA.size();MPI_Bcast(&csz,1,MPI_UNSIGNED_LONG_LONG,0,MPI_COMM_WORLD);
    if(rank!=0)cb_SoA.resize(csz);MPI_Bcast(cb_SoA.data(),(int)csz,MPI_FLOAT,0,MPI_COMM_WORLD);
    // Scatterv PQ codes (M bytes per vector)
    {std::vector<int>sc_c(sz),ds_c(sz);size_t off2=0;
    for(int i=0;i<sz;++i){size_t ni=ln+(i<(int)rm?1:0);sc_c[i]=(int)(ni*M);ds_c[i]=(int)(off2*M);off2+=ni;}
    MPI_Scatterv(codes_all,sc_c.data(),ds_c.data(),MPI_UINT8_T,codes.data(),(int)(mn*M),MPI_UINT8_T,0,MPI_COMM_WORLD);}
    if(rank==0){delete[] codes_all;delete[] ab;}
    auto ls=build_ivf(lb.data(),mn,dim,K,cent);

    if(rank!=0){qu=new float[qn*dim];gt=new int[qn*gd];}
    MPI_Bcast(qu,(int)(qn*dim),MPI_FLOAT,0,MPI_COMM_WORLD);
    MPI_Bcast(gt,(int)(qn*gd),MPI_INT,0,MPI_COMM_WORLD);

    // 单query测试
    if(rank==0){
        std::vector<std::pair<float,int>>lr;
        ivf_pq_search(lb.data(),codes.data(),cent,ls,cb_SoA,qu,dim,k,M,Kpq,np,P,lr);
        std::cout<<"[DEBUG q0] lc="<<lr.size()<<" GT top5:";
        for(size_t j=0;j<5;++j)std::cout<<" "<<gt[j];
        std::cout<<" | result top5:";
        for(size_t j=0;j<std::min(lr.size(),(size_t)5);++j)std::cout<<" "<<lr[j].second;
        std::cout<<"\n";
    }

    // 批量搜索+MPI merge
    double ts=MPI_Wtime();float tr=0;
    for(size_t i=0;i<qn;++i){
        std::vector<std::pair<float,int>>lr;
        ivf_pq_search(lb.data(),codes.data(),cent,ls,cb_SoA,qu+i*dim,dim,k,M,Kpq,np,P,lr);
        for(auto&p:lr)p.second+=goff;
        int lc=(int)lr.size();std::vector<float>lbuf(lc*2);
        for(int j=0;j<lc;++j){lbuf[j*2]=lr[j].first;lbuf[j*2+1]=(float)lr[j].second;}
        std::vector<int>ac(sz);MPI_Gather(&lc,1,MPI_INT,ac.data(),1,MPI_INT,0,MPI_COMM_WORLD);
        std::vector<float>abuf;std::vector<int>rd(sz),acf(sz);
        if(rank==0){int t=0;for(int j=0;j<sz;++j){acf[j]=ac[j]*2;rd[j]=t*2;t+=ac[j];}abuf.resize(t*2);}
        MPI_Gatherv(lbuf.data(),lc*2,MPI_FLOAT,abuf.data(),acf.data(),rd.data(),MPI_FLOAT,0,MPI_COMM_WORLD);
        if(rank==0){Heap g;int tp=(int)abuf.size()/2;for(int j=0;j<tp;++j)hp(g,abuf[j*2],(int)abuf[j*2+1],k);
            std::set<int>gs(gt+i*gd,gt+i*gd+k);size_t h=0;Heap t2=g;while(!t2.empty()){if(gs.count(t2.top().second))++h;t2.pop();}tr+=(float)h/k;}
    }
    double te=MPI_Wtime();
    if(rank==0){std::cout<<"[IVF-PQ-MPI] procs="<<sz<<" K="<<K<<" np="<<np<<" M="<<M<<" P="<<P<<" lat="<<(te-ts)*1e6/qn<<"us recall="<<tr/qn<<"\n";}
    if(rank==0)delete[] codes_all;delete[] qu;delete[] gt;MPI_Finalize();return 0;
}
