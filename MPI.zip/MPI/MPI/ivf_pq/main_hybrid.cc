// IVF-PQ Hybrid: MPI(4进程) + Pthread(2线程/进程) + fa_codec.h
#include <chrono><iomanip><atomic><pthread.h>"ivf_pq_train_mpi.h"

struct BatchPQArg{const float*b;const fa_engine::Codec*codec;const std::vector<float>*cent;const std::vector<IVFList>*ls;
    const float*queries;size_t d,qn,k;int np;size_t P;std::atomic<size_t>*next;std::vector<std::vector<std::pair<float,int>>>*results;};
static void*batch_pq_worker(void*arg){BatchPQArg*a=(BatchPQArg*)arg;
    while(true){size_t qi=a->next->fetch_add(1);if(qi>=a->qn)break;ivf_pq_search(a->b,*a->codec,*a->cent,*a->ls,a->queries+qi*a->d,a->d,a->k,a->np,a->P,(*a->results)[qi]);}return nullptr;}

int main(int argc,char**argv){MPI_Init(&argc,&argv);int rank,sz;MPI_Comm_rank(MPI_COMM_WORLD,&rank);MPI_Comm_size(MPI_COMM_WORLD,&sz);srand(42+rank);const int nth=2;
    size_t tn=0,dim=0,qn=0,gd=0;float*ab=nullptr,*qu=nullptr;int*gt=nullptr;
    if(rank==0){std::string dp="/anndata/";qu=ld<float>(dp+"DEEP100K.query.fbin",qn,dim);ab=ld<float>(dp+"DEEP100K.base.100k.fbin",tn,dim);gt=ld<int>(dp+"DEEP100K.gt.query.100k.top100.bin",qn,gd);qn=2000;}
    MPI_Bcast(&tn,1,MPI_UNSIGNED_LONG_LONG,0,MPI_COMM_WORLD);MPI_Bcast(&dim,1,MPI_UNSIGNED_LONG_LONG,0,MPI_COMM_WORLD);MPI_Bcast(&qn,1,MPI_UNSIGNED_LONG_LONG,0,MPI_COMM_WORLD);MPI_Bcast(&gd,1,MPI_UNSIGNED_LONG_LONG,0,MPI_COMM_WORLD);
    size_t ln=tn/sz,rm=tn%sz;std::vector<int>sc(sz),ds(sz);size_t off=0;
    for(int i=0;i<sz;++i){size_t ni=ln+(size_t)(i<(int)rm?1:0);sc[i]=(int)(ni*dim);ds[i]=(int)(off*dim);off+=ni;}
    size_t mn=ln+(size_t)(rank<(int)rm?1:0);std::vector<float>lb(mn*dim);
    MPI_Scatterv(ab,sc.data(),ds.data(),MPI_FLOAT,lb.data(),(int)(mn*dim),MPI_FLOAT,0,MPI_COMM_WORLD);int goff=(int)(ds[rank]/dim);
    const int K=200,M=4,Kpq=256,np=8;const size_t P=1000,k=10;
    std::vector<float>cent;fa_engine::Codec codec;
    if(rank==0){train_ivf(ab,tn,dim,K,cent,12);codec.build(ab,tn,dim,M,Kpq,6);std::cout<<"[IVF-PQ-Hybrid] K="<<K<<'\n';}
    bcast_vec(cent,rank);bcast_codec(codec,rank);if(rank==0)delete[] ab;
    auto lists=build_ivf(lb.data(),mn,dim,K,cent);
    if(rank!=0){qu=new float[qn*dim];gt=new int[qn*gd];}MPI_Bcast(qu,(int)(qn*dim),MPI_FLOAT,0,MPI_COMM_WORLD);MPI_Bcast(gt,(int)(qn*gd),MPI_INT,0,MPI_COMM_WORLD);
    double ts=MPI_Wtime();
    std::vector<std::vector<std::pair<float,int>>>all_lr;
    {std::atomic<size_t>next(0);all_lr.resize(qn);std::vector<pthread_t>th(nth);BatchPQArg arg={lb.data(),&codec,&cent,&lists,qu,dim,qn,k,np,P,&next,&all_lr};
    for(int t=0;t<nth;++t)pthread_create(&th[t],nullptr,batch_pq_worker,&arg);for(int t=0;t<nth;++t)pthread_join(th[t],nullptr);}
    double te=MPI_Wtime();
    // MPI gather all results
    size_t my_total=0;for(auto&v:all_lr)my_total+=v.size();std::vector<size_t>all_t(sz);MPI_Gather(&my_total,1,MPI_UNSIGNED_LONG_LONG,all_t.data(),1,MPI_UNSIGNED_LONG_LONG,0,MPI_COMM_WORLD);
    std::vector<float>my_buf(my_total*2);size_t pos=0;for(auto&v:all_lr)for(auto&p:v){my_buf[pos++]=p.first;my_buf[pos++]=(float)(p.second+goff);}
    std::vector<float>all_buf;std::vector<int>rc(sz),rds(sz);if(rank==0){size_t t=0;for(int j=0;j<sz;++j){rc[j]=(int)(all_t[j]*2);rds[j]=(int)(t*2);t+=all_t[j];}all_buf.resize(t*2);}
    MPI_Gatherv(my_buf.data(),(int)(my_total*2),MPI_FLOAT,all_buf.data(),rc.data(),rds.data(),MPI_FLOAT,0,MPI_COMM_WORLD);
    std::vector<size_t>per_qc(sz*qn,0);for(size_t i=0;i<qn;++i)per_qc[rank*qn+i]=all_lr[i].size();
    std::vector<size_t>all_qc(sz*qn);MPI_Reduce(per_qc.data(),all_qc.data(),(int)(sz*qn),MPI_UNSIGNED_LONG_LONG,MPI_SUM,0,MPI_COMM_WORLD);
    float tr=0;if(rank==0){size_t bp=0;for(size_t qi=0;qi<qn;++qi){Heap g;for(int p=0;p<sz;++p){size_t cnt=all_qc[p*qn+qi];for(size_t j=0;j<cnt;++j){hp(g,all_buf[bp],(int)all_buf[bp+1],k);bp+=2;}}std::set<int>gs(gt+qi*gd,gt+qi*gd+k);size_t h=0;Heap t2=g;while(!t2.empty()){if(gs.count(t2.top().second))++h;t2.pop();}tr+=(float)h/k;}}
    if(rank==0)std::cout<<"[IVF-PQ-Hybrid] MPI="<<sz<<" pthread="<<nth<<" np="<<np<<" search="<<(te-ts)*1e6/qn<<"us recall="<<tr/qn<<"\n";
    delete[] qu;delete[] gt;MPI_Finalize();return 0;}
