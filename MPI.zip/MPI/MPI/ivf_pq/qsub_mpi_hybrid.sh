#!/bin/sh
#PBS -N ivf_pq_qsub_mpi_hybrid
#PBS -e test.e
#PBS -o test.o
#PBS -l nodes=1:ppn=8
NODES=$(cat $PBS_NODEFILE | sort | uniq)
for node in $NODES; do
    scp master_ubss1:/home/${USER}/ann/main ${node}:/home/${USER} 1>&2
done
/usr/local/bin/mpiexec -np 4 -machinefile $PBS_NODEFILE /home/${USER}/main
