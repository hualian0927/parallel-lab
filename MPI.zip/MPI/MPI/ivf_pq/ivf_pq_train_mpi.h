#pragma once
// IVF-PQ-MPI: IVF训练(ivf_train.h逻辑) + fa_codec.h Codec + MPI
#include <algorithm><cstdlib><cstring><fstream><iostream><limits>
#include <mpi.h><queue><set><vector>
#include "hnswlib/hnswlib/simd_utils.h"
#include "hnswlib/hnswlib/fa_codec.h"

struct IVFList{std::vector<int>ids;};
using Heap=std::priority_queue<std::pair<float,int>>;
static inline void hp(Heap& h,float d,int id,size_t lim){if(h.size()<lim)h.push({d,id});else if(d<h.top().first){h.pop();h.push({d,id});}}

// ---- IVF训练(L2, 从ivf_train.h迁移) ----
static inline void train_ivf(const float*b,size_t n,size_t d,int K,std::vector<float>&cent,int it=12){
    cent.resize(K*d);for(int k=0;k<K;++k){int ri=rand()%n;const float*s=b+ri*d;for(size_t j=0;j<d;++j)cent[k*d+j]=s[j];}
    std::vector<int>as(n);std::vector<float>nc(K*d);std::vector<int>cn(K);
    for(int t=0;t<it;++t){for(size_t i=0;i<n;++i){float be=1e30f;int bk=0;const float*v=b+i*d;
        for(int k=0;k<K;++k){float dt=0;const float*c=cent.data()+k*d;for(size_t j=0;j<d;++j){float df=v[j]-c[j];dt+=df*df;}if(dt<be){be=dt;bk=k;}}as[i]=bk;}
        std::fill(nc.begin(),nc.end(),0);std::fill(cn.begin(),cn.end(),0);
        for(size_t i=0;i<n;++i){int k=as[i];cn[k]++;const float*v=b+i*d;for(size_t j=0;j<d;++j)nc[k*d+j]+=v[j];}
        for(int k=0;k<K;++k)if(cn[k]>0)for(size_t j=0;j<d;++j)cent[k*d+j]=nc[k*d+j]/cn[k];}
}
static inline std::vector<IVFList> build_ivf(const float*b,size_t n,size_t d,int K,const std::vector<float>&cent){
    std::vector<IVFList>ls(K);for(size_t i=0;i<n;++i){float be=1e30f;int bk=0;const float*v=b+i*d;
        for(int k=0;k<K;++k){float dt=0;const float*c=cent.data()+k*d;for(size_t j=0;j<d;++j){float df=v[j]-c[j];dt+=df*df;}if(dt<be){be=dt;bk=k;}}ls[bk].ids.push_back((int)i);}return ls;
}

// ---- IVF-PQ搜索(复用Codec::fill_lut + codec_dist) ----
static inline void ivf_pq_search(const float*b,const fa_engine::Codec&codec,const std::vector<float>&cent,
    const std::vector<IVFList>&ls,const float*q,size_t d,size_t k,int np,size_t P,std::vector<std::pair<float,int>>&out){
    int Kivf=(int)cent.size()/(int)d;Heap coarse;
    for(int c=0;c<Kivf;++c){float dt=InnerProductSIMDNeon(q,cent.data()+c*d,d);hp(coarse,dt,c,np);}
    std::vector<int>pr;while(!coarse.empty()){pr.push_back(coarse.top().second);coarse.pop();}
    Heap gc;
    for(int cid:pr){float lut[4*256];codec.fill_lut(q,lut);
        for(int vi:ls[cid].ids){float dist=codec_dist(lut,codec.codes.data()+vi*codec.M,codec.M);hp(gc,dist,vi,P);}}
    Heap fine;while(!gc.empty()){auto p=gc.top();gc.pop();float ex=InnerProductSIMDNeon(q,b+p.second*d,d);hp(fine,ex,p.second,k);}
    out.clear();while(!fine.empty()){out.push_back(fine.top());fine.pop();}
}

// ---- Bcast helpers ----
static inline void bcast_vec(std::vector<float>&v,int rank){size_t sz=v.size();MPI_Bcast(&sz,1,MPI_UNSIGNED_LONG_LONG,0,MPI_COMM_WORLD);if(rank!=0)v.resize(sz);MPI_Bcast(v.data(),(int)sz,MPI_FLOAT,0,MPI_COMM_WORLD);}
static inline void bcast_codec(fa_engine::Codec&c,int rank){bcast_vec(c.centroids,rank);size_t sz=c.codes.size();MPI_Bcast(&sz,1,MPI_UNSIGNED_LONG_LONG,0,MPI_COMM_WORLD);if(rank!=0)c.codes.resize(sz);MPI_Bcast(c.codes.data(),(int)sz,MPI_UNSIGNED_CHAR,0,MPI_COMM_WORLD);int fields[3]={c.M,c.ksub,c.dsub};MPI_Bcast(fields,3,MPI_INT,0,MPI_COMM_WORLD);if(rank!=0){c.M=fields[0];c.ksub=fields[1];c.dsub=fields[2];}}

template<typename T>T*ld(const std::string&p,size_t&n,size_t&d){std::ifstream f(p,std::ios::binary);if(!f)return nullptr;int32_t h[2];f.read((char*)h,8);n=h[0];d=h[1];T*dt=new T[n*d];f.read((char*)dt,n*d*sizeof(T));return dt;}
