#pragma once
// ===================================================================
// IVF-PQ Hybrid: MPI进程间 + Pthread进程内query级并行
// 复用 ivf_pq_train_mpi.h 的 IVF-PQ 搜索 + ivf_pthread.h 的 atomic dispatch
// ===================================================================
#include <atomic>
#include <pthread.h>
#include <sys/time.h>
#include "ivf_pq_train_mpi.h"

// ---- Pthread batch worker: atomic fetch_add 分发 query ----
struct BatchPQArg {
    const float* base; const uint8_t* codes;
    const std::vector<float>* cent; const std::vector<IVFList>* lists;
    const std::vector<float>* cb_SoA;
    const float* queries;
    size_t d, qn, k; int M, Kpq, np; size_t P;
    std::atomic<size_t>* next_query;
    std::vector<std::vector<std::pair<float,int>>>* results; // per-query
};

static inline void* batch_pq_worker(void* arg) {
    BatchPQArg* a = static_cast<BatchPQArg*>(arg);
    while (true) {
        size_t qi = a->next_query->fetch_add(1, std::memory_order_relaxed);
        if (qi >= a->qn) break;
        ivf_pq_search(a->base, a->codes, *a->cent, *a->lists, *a->cb_SoA,
                       a->queries + qi * a->d, a->d, a->k,
                       a->M, a->Kpq, a->np, a->P, (*a->results)[qi]);
    }
    return nullptr;
}

// 进程内 pthread 批量搜索
static inline void batch_search_pthread(
    const float* base, const uint8_t* codes,
    const std::vector<float>& cent, const std::vector<IVFList>& lists,
    const std::vector<float>& cb_SoA,
    const float* queries, size_t d, size_t qn, size_t k,
    int M, int Kpq, int np, size_t P, int nthreads,
    std::vector<std::vector<std::pair<float,int>>>& results) {
    results.resize(qn);
    std::atomic<size_t> next(0);
    std::vector<pthread_t> threads(nthreads);
    BatchPQArg arg = {base, codes, &cent, &lists, &cb_SoA, queries,
                      d, qn, k, M, Kpq, np, P, &next, &results};
    for (int t = 0; t < nthreads; ++t)
        pthread_create(&threads[t], nullptr, batch_pq_worker, &arg);
    for (int t = 0; t < nthreads; ++t)
        pthread_join(threads[t], nullptr);
}
