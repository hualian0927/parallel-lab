#pragma once
// IVF-PQ MPI: 直接 include 服务器已验证的 ivf_train.h + simd_utils.h
#include <algorithm>
#include <cstdlib>
#include <cstring>
#include <fstream>
#include <iostream>
#include <limits>
#include <mpi.h>
#include <queue>
#include <set>
#include <vector>
#include "hnswlib/hnswlib/simd_utils.h"
#include "hnswlib/hnswlib/ivf_train.h"

using Heap=std::priority_queue<std::pair<float,int>>;
inline void hp(Heap& h,float d,int id,size_t k){if(h.size()<k)h.push({d,id});else if(d<h.top().first){h.pop();h.push({d,id});}}

// PQ编码 (M=4, K=256), 码本AoS→SoA
inline void pq_train_encode(const float*b,size_t n,size_t d,int M,int Kpq,
    std::vector<float>&cb_SoA,uint8_t* codes,int iter=8){
    size_t ds=d/M;std::vector<float>cb_AoS(M*Kpq*ds);
    for(int m=0;m<M;++m){float*c=cb_AoS.data()+m*Kpq*ds;
        for(int k=0;k<Kpq;++k){int ri=rand()%n;std::memcpy(c+k*ds,b+ri*d+m*ds,ds*4);}
        std::vector<int>as(n);std::vector<float>sm(Kpq*ds);std::vector<int>cn(Kpq);
        for(int it=0;it<iter;++it){for(size_t i=0;i<n;++i){float be=1e30f;int bk=0;
            const float*sv=b+i*d+m*ds;for(int k=0;k<Kpq;++k){float dt=0;
                for(size_t j=0;j<ds;++j){float df=sv[j]-c[k*ds+j];dt+=df*df;}
                if(dt<be){be=dt;bk=k;}}as[i]=bk;}
            std::fill(sm.begin(),sm.end(),0);std::fill(cn.begin(),cn.end(),0);
            for(size_t i=0;i<n;++i){int k=as[i];cn[k]++;for(size_t j=0;j<ds;++j)sm[k*ds+j]+=b[i*d+m*ds+j];}
            for(int k=0;k<Kpq;++k)if(cn[k]>0)for(size_t j=0;j<ds;++j)c[k*ds+j]=sm[k*ds+j]/cn[k];}
        for(size_t i=0;i<n;++i){float be=1e30f;uint8_t bk=0;const float*sv=b+i*d+m*ds;
            for(int k=0;k<Kpq;++k){float dt=0;for(size_t j=0;j<ds;++j){float df=sv[j]-c[k*ds+j];dt+=df*df;}
                if(dt<be){be=dt;bk=(uint8_t)k;}}codes[i*M+m]=bk;}}
    cb_SoA.resize(M*Kpq*ds);for(int m=0;m<M;++m)for(int c=0;c<Kpq;++c)
        for(size_t dd=0;dd<ds;++dd)cb_SoA[m*Kpq*ds+dd*Kpq+c]=cb_AoS[m*Kpq*ds+c*ds+dd];
}

// IVF-PQ搜索(单query) — 使用ivf_train.h的InnerProductSIMDNeon
inline void ivf_pq_search(const float*b,const uint8_t*codes,const std::vector<float>&cent,
    const std::vector<IVFList>&ls,const std::vector<float>&cb_SoA,const float*q,
    size_t d,size_t k,int M,int Kpq,int np,size_t P,std::vector<std::pair<float,int>>&out){
    size_t ds=d/M;int Kivf=(int)cent.size()/(int)d;
    Heap coarse;for(int c=0;c<Kivf;++c){float dt=InnerProductSIMDNeon(q,cent.data()+c*d,d);hp(coarse,dt,c,np);}
    std::vector<int>pr;while(!coarse.empty()){pr.push_back(coarse.top().second);coarse.pop();}
    Heap gc;
    for(int cid:pr){
        float lut[4][256];for(int m=0;m<M;++m){const float*qs=q+m*ds;const float*csa=cb_SoA.data()+m*Kpq*ds;
            for(int c=0;c<Kpq;c+=4){
#if defined(__aarch64__)||defined(__ARM_NEON)
                float32x4_t s4=vdupq_n_f32(0.0f);for(size_t j=0;j<ds;++j){
                    s4=vmlaq_f32(s4,vdupq_n_f32(qs[j]),vld1q_f32(csa+j*Kpq+c));}
                vst1q_f32(&lut[m][c],s4);
#else
                for(int cc=0;cc<4&&c+cc<Kpq;++cc){float dt=0;for(size_t j=0;j<ds;++j)dt+=qs[j]*csa[j*Kpq+c+cc];lut[m][c+cc]=dt;}
#endif
            }}
        for(int vi:ls[cid].ids){const uint8_t*pq=codes+vi*M;
            float dot=lut[0][pq[0]]+lut[1][pq[1]]+lut[2][pq[2]]+lut[3][pq[3]];
            hp(gc,1.0f-dot,vi,P);}
    }
    Heap fine;while(!gc.empty()){auto p=gc.top();gc.pop();
        float ex=InnerProductSIMDNeon(q,b+p.second*d,d);hp(fine,ex,p.second,k);}
    out.clear();while(!fine.empty()){out.push_back(fine.top());fine.pop();}
}

template<typename T>T*ld(const std::string&p,size_t&n,size_t&d){
    std::ifstream f(p,std::ios::binary);if(!f)return nullptr;
    int32_t h[2];f.read((char*)h,8);n=h[0];d=h[1];T*dt=new T[n*d];f.read((char*)dt,n*d*sizeof(T));return dt;
}
