#!/bin/sh
#PBS -N codex_h2h_prec
#PBS -e test.e
#PBS -o test.o
#PBS -l nodes=1:ppn=8

set -eu

SCRIPT_DIR=$(cd "$(dirname "$0")" && pwd)
if [ -n "${ANN_WORKDIR:-}" ] && [ -d "${ANN_WORKDIR}" ]; then
    DIR="$ANN_WORKDIR"
elif [ -n "${PBS_O_WORKDIR:-}" ] && [ -d "${PBS_O_WORKDIR}" ]; then
    DIR="$PBS_O_WORKDIR"
else
    DIR="$SCRIPT_DIR"
fi
cd "$DIR"
if [ -d "$DIR/hnswlib" ]; then
    ROOT="$DIR"
elif [ -d "$DIR/../../hnswlib" ]; then
    ROOT=$(cd "$DIR/../.." && pwd)
else
    ROOT="$DIR"
fi

FILES_DIR="$ROOT/files"
OUT_DIR="$DIR/analysis_out"
CASE=${ANN_CASE:-route5_80}
mkdir -p "$FILES_DIR" "$OUT_DIR"
export ANN_FILES_DIR="$FILES_DIR"
export ANN_MPI_NP=${ANN_MPI_NP:-8}
export ANN_BIN=/home/${USER}/main

mpic++ "$DIR/main.cc" -o /home/${USER}/main -O2 -std=c++17 -lpthread -I"$ROOT"

NODES=$(cat "$PBS_NODEFILE" | sort | uniq)
for node in $NODES; do
    scp /home/${USER}/main "${node}:/home/${USER}" 1>&2
    if [ "$node" != "$(hostname)" ]; then
        ssh "$node" "mkdir -p '$FILES_DIR'" 1>&2
        scp -r "$FILES_DIR"/. "${node}:$FILES_DIR" 1>&2
    fi
done

OUT_PREFIX="$OUT_DIR/perf_record_${CASE}"
perf record -F 99 -g --call-graph dwarf -o "${OUT_PREFIX}.data" -- \
    sh "$DIR/run_case.sh" | tee "${OUT_PREFIX}.run.txt"
perf report -i "${OUT_PREFIX}.data" --stdio --sort=comm,dso,symbol --percent-limit=1.0 > "${OUT_PREFIX}.report.txt"
