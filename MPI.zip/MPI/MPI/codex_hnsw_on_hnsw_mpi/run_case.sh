#!/bin/sh
set -eu

CASE=${ANN_CASE:-route5_80}
NP=${ANN_MPI_NP:-8}
BIN=${ANN_BIN:-/home/${USER}/main}

export ANN_FILES_DIR=${ANN_FILES_DIR:-$(pwd)/files}
export ANN_PARTS=${ANN_PARTS:-8}
export ANN_PARTITION=${ANN_PARTITION:-ip}
export ANN_M=${ANN_M:-24}
export ANN_EFC=${ANN_EFC:-220}
export ANN_ROUTER_M=${ANN_ROUTER_M:-8}
export ANN_ROUTER_EF=${ANN_ROUTER_EF:-8}
export ANN_REPS_PER_PART=${ANN_REPS_PER_PART:-8}

case "$CASE" in
    baseline_all)
        export ANN_RECALL_FIRST=1
        export ANN_ROUTE=8
        export ANN_ROUTE_CAND=8
        export ANN_EF=120
        export ANN_ROUTER_MODE=all
        ;;
    route5_80)
        export ANN_RECALL_FIRST=0
        export ANN_ROUTE=5
        export ANN_ROUTE_CAND=8
        export ANN_EF=80
        export ANN_ROUTER_MODE=exact
        ;;
    route5_72)
        export ANN_RECALL_FIRST=0
        export ANN_ROUTE=5
        export ANN_ROUTE_CAND=8
        export ANN_EF=72
        export ANN_ROUTER_MODE=exact
        ;;
    route5_64)
        export ANN_RECALL_FIRST=0
        export ANN_ROUTE=5
        export ANN_ROUTE_CAND=8
        export ANN_EF=64
        export ANN_ROUTER_MODE=exact
        ;;
    route4_96)
        export ANN_RECALL_FIRST=0
        export ANN_ROUTE=4
        export ANN_ROUTE_CAND=8
        export ANN_EF=96
        export ANN_ROUTER_MODE=exact
        ;;
    route4_80)
        export ANN_RECALL_FIRST=0
        export ANN_ROUTE=4
        export ANN_ROUTE_CAND=8
        export ANN_EF=80
        export ANN_ROUTER_MODE=exact
        ;;
    *)
        echo "Unknown ANN_CASE=$CASE" 1>&2
        exit 2
        ;;
esac

echo "[CFG] case=$CASE np=$NP route=$ANN_ROUTE route_cand=$ANN_ROUTE_CAND mode=$ANN_PARTITION reps=$ANN_REPS_PER_PART router=$ANN_ROUTER_MODE recall_first=$ANN_RECALL_FIRST M=$ANN_M ef=$ANN_EF"

if [ -n "${PBS_NODEFILE:-}" ] && [ -f "${PBS_NODEFILE:-}" ]; then
    /usr/local/bin/mpiexec -np "$NP" -machinefile "$PBS_NODEFILE" "$BIN"
else
    mpiexec -np "$NP" "$BIN"
fi
