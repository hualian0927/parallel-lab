# codex_hnsw_on_hnsw_mpi

Score point:
- A custom HNSW-on-HNSW strategy.
- Build a top-level HNSW over partition centroids, then search only routed partitions.

Compile:

```sh
mpic++ main.cc -o main -O2 -std=c++17 -lpthread -I../..
```

Typical workflow:

```sh
qsub qsub_build.sh
qsub qsub_search.sh
```

Analysis workflow:

```sh
qsub qsub_case_compare.sh
ANN_CASE=route5_80 qsub qsub_perf_stat.sh
ANN_CASE=route5_80 qsub qsub_perf_record.sh
qsub qsub_layout_info.sh
```

Latency tuning from the recall-first baseline:

```sh
qsub qsub_search_balance.sh
qsub qsub_search_fast_safe.sh
qsub qsub_search_fast.sh
qsub qsub_search_tune_5x72.sh
qsub qsub_search_tune_5x64.sh
qsub qsub_search_tune_5x56.sh
qsub qsub_search_verified_5x72.sh
qsub qsub_search_verified_5x64.sh
qsub qsub_search_verified_4x96.sh
qsub qsub_search_verified_4x80.sh
```

The qsub scripts recompile `main.cc` into `/home/${USER}/main` before running, so
parameter and code changes are not blocked by an old binary.

Path note:
- Offline partition files and HNSW indices are written to `ANN_FILES_DIR`.
- The qsub scripts default this to repo-root `files/`, alongside `hnswlib/`.

Useful knobs:

```sh
export ANN_PARTS=8
export ANN_RECALL_FIRST=1
export ANN_ROUTE=8
export ANN_ROUTE_CAND=8
export ANN_PARTITION=ip       # ip, ivf, block, or random
export ANN_M=24
export ANN_EFC=220
export ANN_EF=120
export ANN_ROUTER_M=8
export ANN_ROUTER_EF=8
export ANN_REPS_PER_PART=8
export ANN_ROUTER_MODE=all    # all, exact, or hnsw
```

Suggested search-only sweep after a strong baseline:

- `qsub_search_balance.sh`: `route=6`, `ef=96`
- `qsub_search_fast_safe.sh`: `route=5`, `ef=80`
- `qsub_search_fast.sh`: `route=4`, `ef=64`
- `qsub_search_tune_5x72.sh`: keep `route=5`, reduce `ef` to `72`
- `qsub_search_tune_5x64.sh`: keep `route=5`, reduce `ef` to `64`
- `qsub_search_tune_5x56.sh`: keep `route=5`, reduce `ef` to `56`
- Verified scripts print `[CFG]` before `mpiexec` so you can confirm the active config.
- `qsub_search_verified_5x72.sh`: trusted `route=5`, `ef=72`
- `qsub_search_verified_5x64.sh`: trusted `route=5`, `ef=64`
- `qsub_search_verified_4x96.sh`: trusted `route=4`, `ef=96`
- `qsub_search_verified_4x80.sh`: trusted `route=4`, `ef=80`

Analysis scripts:

- `run_case.sh`: unified case launcher for reproducible configs
- `qsub_case_compare.sh`: run baseline / good / negative-optimization cases in one job
- `qsub_perf_stat.sh`: collect `perf stat` counters for one chosen case
- `qsub_perf_record.sh`: collect hotspot call stacks with `perf record/report`
- `qsub_layout_info.sh`: collect nodefile, rank placement, CPU/NUMA info
- `perf_mpi.sh`: interactive version of the same perf workflow
- All `qsub_*.sh` scripts now prefer `PBS_O_WORKDIR`, which avoids writing into `/var/spool/torque/...` when Torque copies the script before execution.
- If the compute nodes do not see the same absolute path as `PBS_O_WORKDIR`, set `ANN_WORKDIR=$(pwd)` before `qsub` to pin the real project directory.

Recommended cases for the report:

- `baseline_all`: recall-first upper bound, searches all routed parts
- `route5_80`: current strong time/recall point
- `route5_72`: slightly faster, still high recall
- `route4_96`: fewer routed parts, useful to compare routing miss risk
- `route5_64` / `route4_80`: negative optimization examples
