#!/bin/sh
# ===================================================================
# HNSW-on-HNSW MPI perf 分析 (自包含: 编译+分发+perf stat/record)
# 用法: qsub perf_mpi.sh
# ===================================================================
#PBS -N codex_h2h_perf
#PBS -e test.e
#PBS -o test.o
#PBS -l nodes=1:ppn=8

set -eu

SCRIPT_DIR=$(cd "$(dirname "$0")" && pwd)
if [ -n "${PBS_O_WORKDIR:-}" ] && [ -d "${PBS_O_WORKDIR}" ]; then
    DIR="$PBS_O_WORKDIR"
else
    DIR="$SCRIPT_DIR"
fi
cd "$DIR"

# 确定 include 根目录 (hnswlib 所在)
if [ -d "$DIR/hnswlib" ]; then
    ROOT="$DIR"
elif [ -d "$DIR/../../hnswlib" ]; then
    ROOT=$(cd "$DIR/../.." && pwd)
else
    ROOT="$DIR"
fi

FILES_DIR="$ROOT/files"
OUT_DIR="$DIR/analysis_out"
CASE=${ANN_CASE:-route5_80}
NP=${ANN_MPI_NP:-8}
mkdir -p "$FILES_DIR" "$OUT_DIR"

export ANN_FILES_DIR="$FILES_DIR"
export ANN_MPI_NP="$NP"
export ANN_BIN=/home/${USER}/main
export ANN_CASE="$CASE"

# 1. 编译
mpic++ "$DIR/main.cc" -o /home/${USER}/main -O2 -std=c++17 -lpthread -I"$ROOT"

# 2. 分发到计算节点
NODES=$(cat "$PBS_NODEFILE" | sort | uniq)
for node in $NODES; do
    scp /home/${USER}/main "${node}:/home/${USER}" 1>&2
    if [ "$node" != "$(hostname)" ]; then
        ssh "$node" "mkdir -p '$FILES_DIR'" 1>&2
        scp -r "$FILES_DIR"/. "${node}:$FILES_DIR" 1>&2
    fi
done

# 3. perf stat
echo "=== perf stat ==="
PREFIX="$OUT_DIR/perf_${CASE}"
perf stat \
    -e task-clock,cycles,instructions,branches,branch-misses \
    -e cache-references,cache-misses,context-switches,cpu-migrations,page-faults \
    -o "${PREFIX}_stat.txt" -- \
    sh "$DIR/run_case.sh" | tee "${PREFIX}_run.txt"

# 4. perf record + report
echo "=== perf record ==="
perf record -F 99 -g --call-graph dwarf -o "${PREFIX}.data" -- \
    sh "$DIR/run_case.sh" > "${PREFIX}_record_run.txt" 2>&1

perf report -i "${PREFIX}.data" --stdio --sort=comm,dso,symbol --percent-limit=1.0 > "${PREFIX}_report.txt"

echo "=== Done. Output: $OUT_DIR ==="
ls -la "$OUT_DIR"/perf_${CASE}*
