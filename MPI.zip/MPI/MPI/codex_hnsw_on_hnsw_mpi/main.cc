#include <algorithm>
#include <cstdlib>
#include <cstring>
#include <iostream>
#include <memory>
#include <random>
#include <string>
#include <vector>
#include "hnswlib/hnswlib/hnswlib.h"
#include "hnswlib/hnswlib/common.h"

using namespace hnswlib;

static inline int env_i(const char *name, int defv)
{
    const char *s = std::getenv(name);
    if (!s || !*s)
        return defv;
    int v = std::atoi(s);
    return v > 0 ? v : defv;
}

static inline std::string local_files_dir()
{
    const char *s = std::getenv("ANN_FILES_DIR");
    return (s && *s) ? std::string(s) : std::string("files");
}

static inline std::string local_files_path(const std::string &name)
{
    std::string dir = local_files_dir();
    if (!dir.empty() && (dir.back() == '/' || dir.back() == '\\'))
        return dir + name;
    return dir + "/" + name;
}

struct PartIndex
{
    int part_id = -1;
    std::unique_ptr<HierarchicalNSW<float>> index;
};

static std::string part_index_path(int parts, const std::string &mode, int M, int efc, int part_id)
{
    return local_files_path("codex_h2h_parts" + std::to_string(parts) +
                            "_" + mode + "_M" + std::to_string(M) +
                            "_efc" + std::to_string(efc) +
                            "_part" + std::to_string(part_id) + ".index");
}

static std::string router_index_path(int parts, const std::string &mode, int reps, int M, int efc)
{
    return local_files_path("codex_h2h_router_parts" + std::to_string(parts) +
                            "_" + mode + "_M" + std::to_string(M) +
                            "_r" + std::to_string(reps) +
                            "_efc" + std::to_string(efc) + ".index");
}

static std::string router_rep_path(int parts, const std::string &mode, int reps)
{
    return local_files_path("codex_h2h_router_reps_parts" + std::to_string(parts) +
                            "_" + mode + "_r" + std::to_string(reps) + ".bin");
}

static std::string router_owner_path(int parts, const std::string &mode, int reps)
{
    return local_files_path("codex_h2h_router_owner_parts" + std::to_string(parts) +
                            "_" + mode + "_r" + std::to_string(reps) + ".bin");
}

static std::string part_assign_path(int parts, const std::string &mode)
{
    return local_files_path("codex_h2h_assign_parts" + std::to_string(parts) + "_" + mode + ".bin");
}

static std::string part_center_path(int parts, const std::string &mode)
{
    return local_files_path("codex_h2h_centers_parts" + std::to_string(parts) + "_" + mode + ".bin");
}

static void train_part_centers_ivf(const float *base, size_t n, size_t d, int parts,
                                   std::vector<float> &centers, std::vector<int> &assign, int it = 8)
{
    centers.resize((size_t)parts * d);
    assign.resize(n);
    for (int p = 0; p < parts; ++p)
        std::memcpy(centers.data() + (size_t)p * d, base + (size_t)(p % n) * d, d * sizeof(float));

    std::vector<float> next_centers((size_t)parts * d);
    std::vector<int> counts(parts);
    for (int t = 0; t < it; ++t)
    {
        for (size_t i = 0; i < n; ++i)
        {
            float best = 1e30f;
            int bp = 0;
            for (int p = 0; p < parts; ++p)
            {
                float dist = l2_dist(base + i * d, centers.data() + (size_t)p * d, d);
                if (dist < best)
                {
                    best = dist;
                    bp = p;
                }
            }
            assign[i] = bp;
        }

        std::fill(next_centers.begin(), next_centers.end(), 0.0f);
        std::fill(counts.begin(), counts.end(), 0);
        for (size_t i = 0; i < n; ++i)
        {
            int p = assign[i];
            ++counts[(size_t)p];
            for (size_t j = 0; j < d; ++j)
                next_centers[(size_t)p * d + j] += base[i * d + j];
        }
        for (int p = 0; p < parts; ++p)
        {
            if (counts[(size_t)p] > 0)
            {
                for (size_t j = 0; j < d; ++j)
                    centers[(size_t)p * d + j] = next_centers[(size_t)p * d + j] / counts[(size_t)p];
            }
        }
    }
}

static void train_part_centers_ip(const float *base, size_t n, size_t d, int parts,
                                  std::vector<float> &centers, std::vector<int> &assign, int it = 8)
{
    centers.resize((size_t)parts * d);
    assign.resize(n);
    for (int p = 0; p < parts; ++p)
        std::memcpy(centers.data() + (size_t)p * d, base + (size_t)(p % n) * d, d * sizeof(float));

    std::vector<float> next_centers((size_t)parts * d);
    std::vector<int> counts(parts);
    for (int t = 0; t < it; ++t)
    {
        for (size_t i = 0; i < n; ++i)
        {
            float best = ip_dist(base + i * d, centers.data(), d);
            int bp = 0;
            for (int p = 1; p < parts; ++p)
            {
                float dist = ip_dist(base + i * d, centers.data() + (size_t)p * d, d);
                if (dist < best)
                {
                    best = dist;
                    bp = p;
                }
            }
            assign[i] = bp;
        }

        std::fill(next_centers.begin(), next_centers.end(), 0.0f);
        std::fill(counts.begin(), counts.end(), 0);
        for (size_t i = 0; i < n; ++i)
        {
            int p = assign[i];
            ++counts[(size_t)p];
            for (size_t j = 0; j < d; ++j)
                next_centers[(size_t)p * d + j] += base[i * d + j];
        }
        for (int p = 0; p < parts; ++p)
        {
            if (counts[(size_t)p] > 0)
            {
                for (size_t j = 0; j < d; ++j)
                    centers[(size_t)p * d + j] = next_centers[(size_t)p * d + j] / counts[(size_t)p];
            }
        }
    }
}

static void build_router_reps(const float *base, size_t n, size_t d, int parts,
                              const std::vector<int> &assign, const std::vector<float> &centers,
                              int reps_per_part, std::vector<float> &rep_vecs, std::vector<int> &rep_owner)
{
    std::vector<std::vector<int>> members(parts);
    for (size_t i = 0; i < n; ++i)
        members[(size_t)assign[i]].push_back((int)i);

    rep_vecs.clear();
    rep_owner.clear();
    rep_vecs.reserve((size_t)parts * reps_per_part * d);
    rep_owner.reserve((size_t)parts * reps_per_part);

    for (int p = 0; p < parts; ++p)
    {
        const std::vector<int> &mem = members[(size_t)p];
        if (mem.empty())
            continue;

        std::vector<int> chosen;
        chosen.reserve(reps_per_part);

        int first = mem[0];
        float best_center = l2_dist(base + (size_t)first * d, centers.data() + (size_t)p * d, d);
        for (size_t i = 1; i < mem.size(); ++i)
        {
            int id = mem[i];
            float dist = l2_dist(base + (size_t)id * d, centers.data() + (size_t)p * d, d);
            if (dist < best_center)
            {
                best_center = dist;
                first = id;
            }
        }
        chosen.push_back(first);

        while ((int)chosen.size() < reps_per_part && chosen.size() < mem.size())
        {
            int far_id = -1;
            float far_score = -1.0f;
            for (size_t i = 0; i < mem.size(); ++i)
            {
                int id = mem[i];
                bool used = false;
                for (size_t j = 0; j < chosen.size(); ++j)
                    if (chosen[j] == id)
                    {
                        used = true;
                        break;
                    }
                if (used)
                    continue;

                float min_d = l2_dist(base + (size_t)id * d, base + (size_t)chosen[0] * d, d);
                for (size_t j = 1; j < chosen.size(); ++j)
                {
                    float cur = l2_dist(base + (size_t)id * d, base + (size_t)chosen[j] * d, d);
                    if (cur < min_d)
                        min_d = cur;
                }
                if (min_d > far_score)
                {
                    far_score = min_d;
                    far_id = id;
                }
            }
            if (far_id < 0)
                break;
            chosen.push_back(far_id);
        }

        for (size_t j = 0; j < chosen.size(); ++j)
        {
            int id = chosen[j];
            rep_owner.push_back(p);
            rep_vecs.insert(rep_vecs.end(), base + (size_t)id * d, base + (size_t)(id + 1) * d);
        }
    }
}

int main(int argc, char **argv)
{
    MPI_Init(&argc, &argv);
    int rank = 0, sz = 1;
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
    MPI_Comm_size(MPI_COMM_WORLD, &sz);

    size_t tn = 0, dim = 0, qn = 0, gd = 0;
    float *base = nullptr, *queries = nullptr;
    int *gt = nullptr;
    if (rank == 0)
    {
        std::string dp = "/anndata/";
        queries = load_fbin_like<float>(dp + "DEEP100K.query.fbin", qn, dim);
        base = load_fbin_like<float>(dp + "DEEP100K.base.100k.fbin", tn, dim);
        gt = load_fbin_like<int>(dp + "DEEP100K.gt.query.100k.top100.bin", qn, gd);
        qn = 2000;
    }

    MPI_Bcast(&tn, 1, MPI_UNSIGNED_LONG_LONG, 0, MPI_COMM_WORLD);
    MPI_Bcast(&dim, 1, MPI_UNSIGNED_LONG_LONG, 0, MPI_COMM_WORLD);
    MPI_Bcast(&qn, 1, MPI_UNSIGNED_LONG_LONG, 0, MPI_COMM_WORLD);
    MPI_Bcast(&gd, 1, MPI_UNSIGNED_LONG_LONG, 0, MPI_COMM_WORLD);

    const size_t k = 10;
    const bool recall_first = env_i("ANN_RECALL_FIRST", 1) != 0;
    const int parts = std::max(1, env_i("ANN_PARTS", std::min(8, sz)));
    const int route_k = std::min(parts, env_i("ANN_ROUTE", recall_first ? parts : std::min(4, parts)));
    const int route_cand = std::min(parts, env_i("ANN_ROUTE_CAND", recall_first ? parts : std::min(parts, std::max(route_k * 2, 6))));
    const int M = env_i("ANN_M", recall_first ? 24 : 16);
    const int efc = env_i("ANN_EFC", recall_first ? 220 : 150);
    const int ef = env_i("ANN_EF", recall_first ? 120 : 40);
    const int router_M = env_i("ANN_ROUTER_M", 8);
    const int router_ef = env_i("ANN_ROUTER_EF", recall_first ? parts : 16);
    const int reps_per_part = std::max(1, env_i("ANN_REPS_PER_PART", recall_first ? 8 : 4));
    const bool build_only = env_i("ANN_BUILD_ONLY", 0) != 0;
    const std::string part_mode = std::getenv("ANN_PARTITION") ? std::getenv("ANN_PARTITION") : "ip";
    const std::string router_mode = std::getenv("ANN_ROUTER_MODE") ? std::getenv("ANN_ROUTER_MODE") : (recall_first ? "all" : "exact");

    std::vector<int> group_of_vec;
    std::vector<int> owner_of_group(parts);
    for (int p = 0; p < parts; ++p)
        owner_of_group[(size_t)p] = p % sz;

    std::vector<float> part_centers;
    std::vector<float> router_reps;
    std::vector<int> router_owner;
    if (rank == 0)
    {
        std::string apath = part_assign_path(parts, part_mode);
        std::string cpath = part_center_path(parts, part_mode);
        std::string rppath = router_rep_path(parts, part_mode, reps_per_part);
        std::string ropath = router_owner_path(parts, part_mode, reps_per_part);
        if (load_vector_i32(apath, group_of_vec) &&
            load_vector_f32(cpath, part_centers) &&
            load_vector_f32(rppath, router_reps) &&
            load_vector_i32(ropath, router_owner))
        {
            // offline partitioning already exists
        }
        else if (part_mode == "random")
        {
            group_of_vec.resize(tn);
            std::vector<int> perm(tn);
            for (size_t i = 0; i < tn; ++i)
                perm[i] = static_cast<int>(i);
            std::mt19937 rng(42);
            std::shuffle(perm.begin(), perm.end(), rng);
            for (size_t i = 0; i < tn; ++i)
                group_of_vec[(size_t)perm[i]] = static_cast<int>(i % parts);

            part_centers.assign((size_t)parts * dim, 0.0f);
            std::vector<int> cnt(parts, 0);
            for (size_t i = 0; i < tn; ++i)
            {
                int p = group_of_vec[i];
                ++cnt[(size_t)p];
                for (size_t j = 0; j < dim; ++j)
                    part_centers[(size_t)p * dim + j] += base[i * dim + j];
            }
            for (int p = 0; p < parts; ++p)
                if (cnt[(size_t)p] > 0)
                    for (size_t j = 0; j < dim; ++j)
                        part_centers[(size_t)p * dim + j] /= cnt[(size_t)p];
            build_router_reps(base, tn, dim, parts, group_of_vec, part_centers, reps_per_part, router_reps, router_owner);
        }
        else if (part_mode == "block")
        {
            group_of_vec.resize(tn);
            for (size_t i = 0; i < tn; ++i)
                group_of_vec[i] = static_cast<int>((i * parts) / tn);
            part_centers.assign((size_t)parts * dim, 0.0f);
            std::vector<int> cnt(parts, 0);
            for (size_t i = 0; i < tn; ++i)
            {
                int p = group_of_vec[i];
                ++cnt[(size_t)p];
                for (size_t j = 0; j < dim; ++j)
                    part_centers[(size_t)p * dim + j] += base[i * dim + j];
            }
            for (int p = 0; p < parts; ++p)
                if (cnt[(size_t)p] > 0)
                    for (size_t j = 0; j < dim; ++j)
                        part_centers[(size_t)p * dim + j] /= cnt[(size_t)p];
            build_router_reps(base, tn, dim, parts, group_of_vec, part_centers, reps_per_part, router_reps, router_owner);
        }
        else if (part_mode == "ivf")
        {
            train_part_centers_ivf(base, tn, dim, parts, part_centers, group_of_vec);
            build_router_reps(base, tn, dim, parts, group_of_vec, part_centers, reps_per_part, router_reps, router_owner);
        }
        else
        {
            train_part_centers_ip(base, tn, dim, parts, part_centers, group_of_vec);
            build_router_reps(base, tn, dim, parts, group_of_vec, part_centers, reps_per_part, router_reps, router_owner);
        }

        save_vector_i32(apath, group_of_vec);
        save_vector_f32(cpath, part_centers);
        save_vector_f32(rppath, router_reps);
        save_vector_i32(ropath, router_owner);

        std::string rpath = router_index_path(parts, part_mode, reps_per_part, router_M, efc);
        if (!file_exists(rpath))
        {
            InnerProductSpace rspace(dim);
            HierarchicalNSW<float> router(&rspace, std::max((size_t)1, router_owner.size()), router_M, efc);
            for (size_t rid = 0; rid < router_owner.size(); ++rid)
                router.addPoint(router_reps.data() + rid * dim, (labeltype)rid);
            router.saveIndex(rpath);
        }
    }
    bcast_vector_i32(group_of_vec, rank);
    bcast_vector_f32(part_centers, rank);
    bcast_vector_f32(router_reps, rank);
    bcast_vector_i32(router_owner, rank);

    std::vector<float> local_data;
    std::vector<int> local_ids, local_parts;
    scatter_grouped_vectors(base, tn, dim, group_of_vec, owner_of_group, rank, sz,
                            local_data, local_ids, local_parts);

    InnerProductSpace space(dim);
    std::vector<std::vector<int>> pos_by_part(parts);
    for (size_t i = 0; i < local_parts.size(); ++i)
        pos_by_part[(size_t)local_parts[i]].push_back(static_cast<int>(i));

    std::vector<PartIndex> part_indexes(parts);
    for (int p = 0; p < parts; ++p)
    {
        if (owner_of_group[(size_t)p] != rank || pos_by_part[(size_t)p].empty())
            continue;
        std::string path = part_index_path(parts, part_mode, M, efc, p);
        part_indexes[(size_t)p].part_id = p;
        if (file_exists(path))
        {
            part_indexes[(size_t)p].index.reset(new HierarchicalNSW<float>(&space, path));
        }
        else
        {
            auto idx = std::unique_ptr<HierarchicalNSW<float>>(new HierarchicalNSW<float>(&space, pos_by_part[(size_t)p].size(), M, efc));
            for (size_t j = 0; j < pos_by_part[(size_t)p].size(); ++j)
            {
                int pos = pos_by_part[(size_t)p][j];
                idx->addPoint(local_data.data() + (size_t)pos * dim, local_ids[(size_t)pos]);
            }
            idx->saveIndex(path);
            part_indexes[(size_t)p].index = std::move(idx);
        }
        part_indexes[(size_t)p].index->ef_ = ef;
    }

    if (rank == 0)
        delete[] base;

    if (build_only)
    {
        if (rank == 0)
            std::cout << "[Codex-H2H] build only finished, parts=" << parts
                      << " route=" << route_k << " mode=" << part_mode
                      << " reps=" << reps_per_part << " router=" << router_mode
                      << " recall_first=" << (recall_first ? 1 : 0) << "\n";
        delete[] queries;
        delete[] gt;
        MPI_Finalize();
        return 0;
    }

    if (rank != 0)
    {
        queries = new float[qn * dim];
        gt = new int[qn * gd];
    }
    MPI_Bcast(queries, static_cast<int>(qn * dim), MPI_FLOAT, 0, MPI_COMM_WORLD);
    MPI_Bcast(gt, static_cast<int>(qn * gd), MPI_INT, 0, MPI_COMM_WORLD);

    MPI_Barrier(MPI_COMM_WORLD);
    std::string rpath = router_index_path(parts, part_mode, reps_per_part, router_M, efc);
    InnerProductSpace router_space(dim);
    std::unique_ptr<HierarchicalNSW<float>> router;
    if (router_mode == "hnsw")
    {
        router.reset(new HierarchicalNSW<float>(&router_space, rpath));
        router->ef_ = std::max(router_ef, route_cand);
    }

    if (rank == 0)
        std::cout << "[Codex-H2H] MPI=" << sz
                  << " parts=" << parts
                  << " route=" << route_k
                  << " route_cand=" << route_cand
                  << " mode=" << part_mode
                  << " reps=" << reps_per_part
                  << " router=" << router_mode
                  << " recall_first=" << (recall_first ? 1 : 0)
                  << " M=" << M
                  << " ef=" << ef << "\n";

    double ts = MPI_Wtime();
    float total_recall = 0.0f;
    for (size_t qi = 0; qi < qn; ++qi)
    {
        std::vector<std::pair<float, int>> rep_hits;
        if (router_mode == "hnsw" && router)
        {
            auto route = router->searchKnn(queries + qi * dim, std::min(route_cand, (int)router_owner.size()));
            while (!route.empty())
            {
                int rid = static_cast<int>(route.top().second);
                float dist = ip_dist(queries + qi * dim, router_reps.data() + (size_t)rid * dim, dim);
                rep_hits.push_back({dist, rid});
                route.pop();
            }
        }
        else
        {
            rep_hits.reserve(router_owner.size());
        }

        std::vector<std::pair<float, int>> routed;
        std::vector<float> best_part(parts, 1e30f);
        if (router_mode == "all" || route_k >= parts)
        {
            routed.reserve(parts);
            for (int p = 0; p < parts; ++p)
                routed.push_back({0.0f, p});
        }
        else if (router_mode == "hnsw" && router)
        {
            std::sort(rep_hits.begin(), rep_hits.end());
            if ((int)rep_hits.size() > route_cand)
                rep_hits.resize(route_cand);
            for (size_t i = 0; i < rep_hits.size(); ++i)
            {
                int pid = router_owner[(size_t)rep_hits[i].second];
                if (rep_hits[i].first < best_part[(size_t)pid])
                    best_part[(size_t)pid] = rep_hits[i].first;
            }
        }
        else
        {
            for (size_t rid = 0; rid < router_owner.size(); ++rid)
            {
                int pid = router_owner[rid];
                float dist = ip_dist(queries + qi * dim, router_reps.data() + rid * dim, dim);
                if (dist < best_part[(size_t)pid])
                    best_part[(size_t)pid] = dist;
            }
        }
        if (routed.empty())
        {
            for (int p = 0; p < parts; ++p)
                if (best_part[(size_t)p] < 1e29f)
                    routed.push_back({best_part[(size_t)p], p});
            std::sort(routed.begin(), routed.end());
            if ((int)routed.size() > route_k)
                routed.resize(route_k);
        }

        Heap local_heap;
        for (const auto &rp : routed)
        {
            int p = rp.second;
            if (!part_indexes[(size_t)p].index)
                continue;
            auto ret = part_indexes[(size_t)p].index->searchKnn(queries + qi * dim, k);
            while (!ret.empty())
            {
                hp(local_heap, ret.top().first, static_cast<int>(ret.top().second), k);
                ret.pop();
            }
        }

        std::vector<MinPair> local_pairs;
        while (!local_heap.empty())
        {
            local_pairs.push_back(local_heap.top());
            local_heap.pop();
        }

        std::vector<MinPair> merged;
        gather_topk_pairs(local_pairs, k, rank, sz, merged);
        if (rank == 0)
        {
            Heap g;
            for (const auto &p : merged)
                hp(g, p.first, p.second, k);
            total_recall += recall_of_heap(g, gt + qi * gd, k);
        }
    }
    double te = MPI_Wtime();

    if (rank == 0)
    {
        std::cout << std::fixed << std::setprecision(3)
                  << "[Codex-H2H] avg_lat=" << (te - ts) * 1e6 / qn
                  << " us recall=" << total_recall / qn << "\n";
    }

    delete[] queries;
    delete[] gt;
    MPI_Finalize();
    return 0;
}

/*


实验	np	route	ef	latency	recall
proc_np4	4	5	80	~446μs	0.996
proc_np8	8	5	80	~305μs	0.969
proc_np16	16	5	80	~497μs	0.937
route5_80	8	5	80	~308μs	0.969
route5_72	8	5	72	~264μs	0.968
route4_96	8	4	96	~286μs	0.943

*/