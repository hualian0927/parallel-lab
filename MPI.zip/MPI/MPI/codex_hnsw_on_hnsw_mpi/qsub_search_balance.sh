#!/bin/sh
#PBS -N codex_h2h_bal
#PBS -e test.e
#PBS -o test.o
#PBS -l nodes=1:ppn=8

SCRIPT_DIR=$(cd "$(dirname "$0")" && pwd)
if [ -n "${ANN_WORKDIR:-}" ] && [ -d "${ANN_WORKDIR}" ]; then
    DIR="$ANN_WORKDIR"
elif [ -n "${PBS_O_WORKDIR:-}" ] && [ -d "${PBS_O_WORKDIR}" ]; then
    DIR="$PBS_O_WORKDIR"
else
    DIR="$SCRIPT_DIR"
fi
cd "$DIR"
if [ -d "$DIR/hnswlib" ]; then
    ROOT="$DIR"
elif [ -d "$DIR/../../hnswlib" ]; then
    ROOT=$(cd "$DIR/../.." && pwd)
else
    ROOT="$DIR"
fi
mpic++ "$DIR/main.cc" -o /home/${USER}/main -O2 -std=c++17 -lpthread -I"$ROOT"

FILES_DIR="$ROOT/files"
mkdir -p "$FILES_DIR"
export ANN_FILES_DIR="$FILES_DIR"
export ANN_PARTS=${ANN_PARTS:-8}
export ANN_RECALL_FIRST=${ANN_RECALL_FIRST:-0}
export ANN_ROUTE=${ANN_ROUTE:-6}
export ANN_ROUTE_CAND=${ANN_ROUTE_CAND:-8}
export ANN_PARTITION=${ANN_PARTITION:-ip}
export ANN_M=${ANN_M:-24}
export ANN_EFC=${ANN_EFC:-220}
export ANN_EF=${ANN_EF:-96}
export ANN_ROUTER_M=${ANN_ROUTER_M:-8}
export ANN_ROUTER_EF=${ANN_ROUTER_EF:-8}
export ANN_REPS_PER_PART=${ANN_REPS_PER_PART:-8}
export ANN_ROUTER_MODE=${ANN_ROUTER_MODE:-exact}

NODES=$(cat $PBS_NODEFILE | sort | uniq)
for node in $NODES; do
    scp /home/${USER}/main ${node}:/home/${USER} 1>&2
    if [ "$node" != "$(hostname)" ]; then
        ssh "$node" "mkdir -p '$FILES_DIR'" 1>&2
        scp -r "$FILES_DIR"/. "${node}:$FILES_DIR" 1>&2
    fi
done

/usr/local/bin/mpiexec -np 8 -machinefile $PBS_NODEFILE /home/${USER}/main
