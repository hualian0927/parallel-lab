#!/bin/sh
#PBS -N codex_h2h_layout
#PBS -e test.e
#PBS -o test.o
#PBS -l nodes=1:ppn=8

set -eu

SCRIPT_DIR=$(cd "$(dirname "$0")" && pwd)
if [ -n "${ANN_WORKDIR:-}" ] && [ -d "${ANN_WORKDIR}" ]; then
    DIR="$ANN_WORKDIR"
elif [ -n "${PBS_O_WORKDIR:-}" ] && [ -d "${PBS_O_WORKDIR}" ]; then
    DIR="$PBS_O_WORKDIR"
else
    DIR="$SCRIPT_DIR"
fi
cd "$DIR"
OUT_DIR="$DIR/analysis_out"
mkdir -p "$OUT_DIR"
OUT_FILE="$OUT_DIR/layout_info.txt"

{
    echo "=== TIME ==="
    date
    echo

    echo "=== HOST ==="
    hostname
    echo

    echo "=== PBS NODEFILE ==="
    cat "$PBS_NODEFILE"
    echo

    echo "=== NODE COUNTS ==="
    sort "$PBS_NODEFILE" | uniq -c
    echo

    echo "=== CPU INFO ==="
    lscpu
    echo

    echo "=== NUMA ==="
    numactl --hardware 2>/dev/null || true
    echo

    echo "=== MPI VERSION ==="
    mpiexec --version 2>/dev/null || true
    echo

    echo "=== PERF VERSION ==="
    perf --version 2>/dev/null || true
    echo

    echo "=== RANK PLACEMENT ==="
    /usr/local/bin/mpiexec -np 8 -machinefile "$PBS_NODEFILE" sh -c 'echo host=$(hostname) rank=${OMPI_COMM_WORLD_RANK:-${PMI_RANK:-${PMIX_RANK:-NA}}} pid=$$'
    echo
} > "$OUT_FILE" 2>&1

cat "$OUT_FILE"
