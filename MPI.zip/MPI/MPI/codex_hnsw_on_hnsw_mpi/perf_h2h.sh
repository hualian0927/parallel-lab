#!/bin/bash
# ===========================================================================
# perf 分析脚本 — HNSW-on-HNSW MPI 图索引
#
# 说明:
#   这个 H2H 实现当前是“纯 MPI 多进程”版本，没有 pthread / OpenMP 查询线程。
#   因此本脚本主要分析:
#     1. MPI 进程规模变化对 latency / recall 的影响
#     2. 调度与进程开销: context-switches / cpu-migrations
#     3. 缓存与执行效率: IPC / cache-misses / branch-misses
#     4. 负优化案例: route / ef 收缩后 recall 为什么突然下降
#
# 用法:
#   cd ~/ann
#   qsub perf_h2h.sh
#
# 输出:
#   analysis_out/
#     h2h_proc_compare.txt         - 不同 MPI 进程数对比
#     h2h_route_compare.txt        - 路由/ef 负优化对比
#     perf_stat_<tag>.txt          - perf stat 计数器
#     run_<tag>.txt                - 程序输出
#     perf_record.data             - 采样数据
#     perf_report.txt              - 热点函数
#     perf_report_pid.txt          - 按 PID 热点
#     perf_annotate.txt            - 汇编级热点注释
#     h2h_layout_info.txt          - 节点 / rank / CPU 信息
# ===========================================================================
#PBS -N codex_h2h_perf
#PBS -e test.e
#PBS -o test.o
#PBS -l nodes=2:ppn=8

set -eu

# ---------------------------------------------------------------------------
# 0. Resolve working directory safely under Torque
# ---------------------------------------------------------------------------
# PBS_O_WORKDIR 是 qsub 提交时的目录, 直接信任, 不加 -d 检查 (NFS 不可见时误判)
PROJ="${PBS_O_WORKDIR:-/home/${USER}/ann}"

BIN=/home/${USER}/main
OUT_DIR="$PROJ/analysis_out"
FILES_DIR=/home/${USER}/files
HEAD_FILES=/home/${USER}/ann/files
mkdir -p "$OUT_DIR" "$HEAD_FILES"

# 在 head node 编译好, qsub 只负责分发+运行
# (计算节点可能没有 mpic++, 所以编译不能放在 qsub 脚本里)
if [ ! -f "$BIN" ]; then
    echo "[ERR] $BIN not found. Compile on head node first:"
    echo "  cd ~/ann && mpic++ main.cc -o main -O2 -std=c++17 -lpthread -I."
    exit 1
fi

NODES=$(sort "$PBS_NODEFILE" | uniq)
for node in $NODES; do
    scp master_ubss1:/home/${USER}/ann/main ${node}:/home/${USER} 1>&2
    scp -r master_ubss1:/home/${USER}/ann/files ${node}:/home/${USER}/ 1>&2
done

# ---------------------------------------------------------------------------
# 2. Find perf
# ---------------------------------------------------------------------------
if command -v perf >/dev/null 2>&1; then
    PERF=$(command -v perf)
elif [ -x /usr/bin/perf ]; then
    PERF=/usr/bin/perf
elif [ -x /usr/local/bin/perf ]; then
    PERF=/usr/local/bin/perf
else
    echo "[WARN] perf not found; this script will only run the workloads"
    PERF=""
fi

# ---------------------------------------------------------------------------
# 3. Shared H2H config
# ---------------------------------------------------------------------------
export ANN_FILES_DIR=/home/${USER}/files
export ANN_PARTITION=ip
export ANN_M=24
export ANN_EFC=220
export ANN_ROUTER_M=8
export ANN_ROUTER_EF=8
export ANN_REPS_PER_PART=8
export ANN_ROUTE_CAND=8
export ANN_MPI_NP=8

run_case() {
    local tag="$1"
    local np="$2"
    local route="$3"
    local ef="$4"
    local mode="$5"
    local recall_first="$6"

    export ANN_PARTS="$np"
    export ANN_ROUTE="$route"
    export ANN_EF="$ef"
    export ANN_ROUTER_MODE="$mode"
    export ANN_RECALL_FIRST="$recall_first"

    echo "[CFG] tag=$tag np=$np route=$route ef=$ef mode=$mode recall_first=$recall_first reps=$ANN_REPS_PER_PART" \
        | tee "$OUT_DIR/cfg_${tag}.txt"

    if [ -n "$PERF" ]; then
        "$PERF" stat \
            -e task-clock,cycles,instructions,branches,branch-misses,cache-references,cache-misses,context-switches,cpu-migrations,page-faults \
            -o "$OUT_DIR/perf_stat_${tag}.txt" -- \
            /usr/local/bin/mpiexec -np "$np" -machinefile "$PBS_NODEFILE" "$BIN" \
            2>&1 | tee "$OUT_DIR/run_${tag}.txt"
    else
        /usr/local/bin/mpiexec -np "$np" -machinefile "$PBS_NODEFILE" "$BIN" \
            2>&1 | tee "$OUT_DIR/run_${tag}.txt"
    fi
}

extract_one() {
    local file="$1"
    local pattern="$2"
    local fallback="$3"
    grep -oP "$pattern" "$file" 2>/dev/null | head -1 || echo "$fallback"
}

summarize_case() {
    local tag="$1"
    local statf="$OUT_DIR/perf_stat_${tag}.txt"
    local runf="$OUT_DIR/run_${tag}.txt"

    local csw mig cyc ins lat rec
    csw=$(extract_one "$statf" '[0-9,]+(?=\s+context-switches)' '?')
    mig=$(extract_one "$statf" '[0-9,]+(?=\s+cpu-migrations)' '?')
    cyc=$(extract_one "$statf" '[0-9,]+(?=\s+cycles)' '?')
    ins=$(extract_one "$statf" '[0-9,]+(?=\s+instructions)' '?')
    lat=$(extract_one "$runf" 'avg_lat=[0-9.]+' '?')
    rec=$(extract_one "$runf" 'recall=[0-9.]+' '?')
    printf "%-18s csw=%-12s mig=%-12s cycles=%-14s ins=%-14s %-18s %-16s\n" \
        "$tag" "$csw" "$mig" "$cyc" "$ins" "$lat" "$rec"
}

collect_layout() {
    {
        echo "=== TIME ==="
        date
        echo

        echo "=== HOST ==="
        hostname
        echo

        echo "=== PWD ==="
        pwd
        echo

        echo "=== HOME ==="
        echo "$HOME"
        echo

        echo "=== PBS_O_WORKDIR ==="
        echo "${PBS_O_WORKDIR:-}"
        echo

        echo "=== NODEFILE ==="
        cat "$PBS_NODEFILE"
        echo

        echo "=== NODE COUNTS ==="
        sort "$PBS_NODEFILE" | uniq -c
        echo

        echo "=== CPU INFO ==="
        lscpu
        echo

        echo "=== NUMA ==="
        numactl --hardware 2>/dev/null || true
        echo

        echo "=== MPI VERSION ==="
        /usr/local/bin/mpiexec --version 2>/dev/null || true
        echo

        echo "=== PERF VERSION ==="
        if [ -n "$PERF" ]; then
            "$PERF" --version 2>/dev/null || true
        else
            echo "perf not found"
        fi
        echo

        echo "=== RANK PLACEMENT ==="
        /usr/local/bin/mpiexec -np 8 -machinefile "$PBS_NODEFILE" sh -c 'echo host=$(hostname) rank=${OMPI_COMM_WORLD_RANK:-${PMI_RANK:-${PMIX_RANK:-NA}}} pid=$$'
        echo
    } > "$OUT_DIR/h2h_layout_info.txt" 2>&1
}

echo "============================================================"
echo " HNSW-on-HNSW MPI perf"
echo " PROJ=$PROJ"
echo " FILES_DIR=$FILES_DIR"
echo " BIN=$BIN"
echo " PERF=${PERF:-none}"
echo "============================================================"

# ---------------------------------------------------------------------------
# Exp1. MPI process scaling
# Keep routing/search quality fixed, only change process count.
# This answers whether process count helps and whether scheduling overhead rises.
# ---------------------------------------------------------------------------
echo ""
echo "=== Exp1: MPI process scaling | route=5 ef=80 exact ==="
: > "$OUT_DIR/h2h_proc_compare.txt"
printf "%-18s %-16s %-16s %-20s %-20s %-18s %-16s\n" \
    "tag" "context-switch" "cpu-migrate" "cycles" "instructions" "latency" "recall" \
    | tee -a "$OUT_DIR/h2h_proc_compare.txt"

for np in 4 8 16; do
    tag="proc_np${np}"
    echo "--- np=$np ---"
    run_case "$tag" "$np" 5 80 exact 0
    summarize_case "$tag" | tee -a "$OUT_DIR/h2h_proc_compare.txt"
done

# ---------------------------------------------------------------------------
# Exp2. Route / ef tradeoff and negative optimization cases
# This is the most useful part for the report.
# ---------------------------------------------------------------------------
echo ""
echo "=== Exp2: route / ef tradeoff ==="
: > "$OUT_DIR/h2h_route_compare.txt"
printf "%-18s %-16s %-16s %-20s %-20s %-18s %-16s\n" \
    "tag" "context-switch" "cpu-migrate" "cycles" "instructions" "latency" "recall" \
    | tee -a "$OUT_DIR/h2h_route_compare.txt"

run_case "baseline_all" 8 8 120 all 1
summarize_case "baseline_all" | tee -a "$OUT_DIR/h2h_route_compare.txt"

run_case "route5_80" 8 5 80 exact 0
summarize_case "route5_80" | tee -a "$OUT_DIR/h2h_route_compare.txt"

run_case "route5_72" 8 5 72 exact 0
summarize_case "route5_72" | tee -a "$OUT_DIR/h2h_route_compare.txt"

run_case "route4_96" 8 4 96 exact 0
summarize_case "route4_96" | tee -a "$OUT_DIR/h2h_route_compare.txt"

run_case "route5_64" 8 5 64 exact 0
summarize_case "route5_64" | tee -a "$OUT_DIR/h2h_route_compare.txt"

run_case "route4_80" 8 4 80 exact 0
summarize_case "route4_80" | tee -a "$OUT_DIR/h2h_route_compare.txt"

# ---------------------------------------------------------------------------
# Exp3. perf record on the current best balanced case
# ---------------------------------------------------------------------------
if [ -n "$PERF" ]; then
    echo ""
    echo "=== Exp3: perf record | route=5 ef=80 exact ==="
    export ANN_PARTS=8
    export ANN_ROUTE=5
    export ANN_EF=80
    export ANN_ROUTER_MODE=exact
    export ANN_RECALL_FIRST=0

    "$PERF" record -F 99 -g --call-graph dwarf -e cpu-cycles:pp \
        -o "$OUT_DIR/perf_record.data" -- \
        /usr/local/bin/mpiexec -np 8 -machinefile "$PBS_NODEFILE" "$BIN" \
        > "$OUT_DIR/run_record.txt" 2>&1 || echo "[WARN] perf record failed"

    if [ -f "$OUT_DIR/perf_record.data" ]; then
        "$PERF" report -i "$OUT_DIR/perf_record.data" --stdio \
            --sort=comm,pid,dso,symbol --percent-limit=1.0 > "$OUT_DIR/perf_report.txt"
        "$PERF" report -i "$OUT_DIR/perf_record.data" --stdio \
            --sort=pid --percent-limit=0.5 > "$OUT_DIR/perf_report_pid.txt"

        {
            echo "============================================================"
            echo " H2H MPI — assembly-level hot-spot analysis"
            echo " Functions worth checking:"
            echo "   searchKnn           - per-part HNSW graph traversal"
            echo "   ip_dist             - route scoring / representative scoring"
            echo "   gather_topk_pairs   - MPI merge/reduce path"
            echo "============================================================"
            echo
            for sym in searchKnn ip_dist gather_topk_pairs; do
                echo "--- $sym ---"
                "$PERF" annotate -i "$OUT_DIR/perf_record.data" --stdio --symbol="$sym" 2>/dev/null || echo "(not found or inlined)"
                echo
            done
        } > "$OUT_DIR/perf_annotate.txt"
    fi
fi

collect_layout

echo ""
echo "=== Notes for analysis ==="
echo "1) This implementation is MPI-only. There is no real query thread pool here."
echo "2) So perf can give you real and useful process-level data:"
echo "   - process scaling"
echo "   - context-switches / cpu-migrations"
echo "   - cache / branch behavior"
echo "   - hotspots by PID / symbol"
echo "3) It cannot prove thread load balance here, because this code path has no worker threads."
echo "4) For thread-vs-process analysis, use your pthread/OpenMP versions separately."

echo ""
echo "=== Done. Output: $OUT_DIR ==="
ls -la "$OUT_DIR" 2>/dev/null || true

