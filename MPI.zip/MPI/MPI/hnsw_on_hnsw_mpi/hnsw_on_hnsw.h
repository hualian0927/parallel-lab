#pragma once

#include <algorithm>
#include <cstring>
#include <memory>
#include <random>
#include <string>
#include <vector>
#include "hnswlib/hnswlib/hnswlib.h"
#include "../graph_index_common/common.h"

using namespace hnswlib;

// ---- index file path helpers ----

static inline std::string h2h_part_index_path(int parts, const std::string &mode, int M, int efc, int part_id)
{
    return files_path("h2h_parts" + std::to_string(parts) +
                      "_" + mode + "_M" + std::to_string(M) +
                      "_efc" + std::to_string(efc) +
                      "_part" + std::to_string(part_id) + ".index");
}

static inline std::string h2h_router_index_path(int parts, const std::string &mode, int reps, int M, int efc)
{
    return files_path("h2h_router_parts" + std::to_string(parts) +
                      "_" + mode + "_M" + std::to_string(M) +
                      "_r" + std::to_string(reps) +
                      "_efc" + std::to_string(efc) + ".index");
}

static inline std::string h2h_router_rep_path(int parts, const std::string &mode, int reps)
{
    return files_path("h2h_router_reps_parts" + std::to_string(parts) +
                      "_" + mode + "_r" + std::to_string(reps) + ".bin");
}

static inline std::string h2h_router_owner_path(int parts, const std::string &mode, int reps)
{
    return files_path("h2h_router_owner_parts" + std::to_string(parts) +
                      "_" + mode + "_r" + std::to_string(reps) + ".bin");
}

static inline std::string h2h_part_assign_path(int parts, const std::string &mode)
{
    return files_path("h2h_assign_parts" + std::to_string(parts) + "_" + mode + ".bin");
}

static inline std::string h2h_part_center_path(int parts, const std::string &mode)
{
    return files_path("h2h_centers_parts" + std::to_string(parts) + "_" + mode + ".bin");
}

// ---- data structures ----

struct H2HPartIndex
{
    int part_id = -1;
    std::unique_ptr<HierarchicalNSW<float>> index;
};

// ---- training functions ----

static inline void h2h_train_part_centers_ivf(const float *base, size_t n, size_t d, int parts,
                                              std::vector<float> &centers, std::vector<int> &assign, int it = 8)
{
    centers.resize((size_t)parts * d);
    assign.resize(n);
    for (int p = 0; p < parts; ++p)
        std::memcpy(centers.data() + (size_t)p * d, base + (size_t)(p % n) * d, d * sizeof(float));

    std::vector<float> next_centers((size_t)parts * d);
    std::vector<int> counts(parts);
    for (int t = 0; t < it; ++t)
    {
        for (size_t i = 0; i < n; ++i)
        {
            float best = 1e30f;
            int bp = 0;
            for (int p = 0; p < parts; ++p)
            {
                float dist = l2_dist(base + i * d, centers.data() + (size_t)p * d, d);
                if (dist < best)
                {
                    best = dist;
                    bp = p;
                }
            }
            assign[i] = bp;
        }

        std::fill(next_centers.begin(), next_centers.end(), 0.0f);
        std::fill(counts.begin(), counts.end(), 0);
        for (size_t i = 0; i < n; ++i)
        {
            int p = assign[i];
            ++counts[(size_t)p];
            for (size_t j = 0; j < d; ++j)
                next_centers[(size_t)p * d + j] += base[i * d + j];
        }
        for (int p = 0; p < parts; ++p)
        {
            if (counts[(size_t)p] > 0)
            {
                for (size_t j = 0; j < d; ++j)
                    centers[(size_t)p * d + j] = next_centers[(size_t)p * d + j] / counts[(size_t)p];
            }
        }
    }
}

static inline void h2h_train_part_centers_ip(const float *base, size_t n, size_t d, int parts,
                                             std::vector<float> &centers, std::vector<int> &assign, int it = 8)
{
    centers.resize((size_t)parts * d);
    assign.resize(n);
    for (int p = 0; p < parts; ++p)
        std::memcpy(centers.data() + (size_t)p * d, base + (size_t)(p % n) * d, d * sizeof(float));

    std::vector<float> next_centers((size_t)parts * d);
    std::vector<int> counts(parts);
    for (int t = 0; t < it; ++t)
    {
        for (size_t i = 0; i < n; ++i)
        {
            float best = ip_dist(base + i * d, centers.data(), d);
            int bp = 0;
            for (int p = 1; p < parts; ++p)
            {
                float dist = ip_dist(base + i * d, centers.data() + (size_t)p * d, d);
                if (dist < best)
                {
                    best = dist;
                    bp = p;
                }
            }
            assign[i] = bp;
        }

        std::fill(next_centers.begin(), next_centers.end(), 0.0f);
        std::fill(counts.begin(), counts.end(), 0);
        for (size_t i = 0; i < n; ++i)
        {
            int p = assign[i];
            ++counts[(size_t)p];
            for (size_t j = 0; j < d; ++j)
                next_centers[(size_t)p * d + j] += base[i * d + j];
        }
        for (int p = 0; p < parts; ++p)
        {
            if (counts[(size_t)p] > 0)
            {
                for (size_t j = 0; j < d; ++j)
                    centers[(size_t)p * d + j] = next_centers[(size_t)p * d + j] / counts[(size_t)p];
            }
        }
    }
}

// ---- router construction ----

static inline void h2h_build_router_reps(const float *base, size_t n, size_t d, int parts,
                                         const std::vector<int> &assign, const std::vector<float> &centers,
                                         int reps_per_part, std::vector<float> &rep_vecs, std::vector<int> &rep_owner)
{
    std::vector<std::vector<int>> members(parts);
    for (size_t i = 0; i < n; ++i)
        members[(size_t)assign[i]].push_back((int)i);

    rep_vecs.clear();
    rep_owner.clear();
    rep_vecs.reserve((size_t)parts * reps_per_part * d);
    rep_owner.reserve((size_t)parts * reps_per_part);

    for (int p = 0; p < parts; ++p)
    {
        const std::vector<int> &mem = members[(size_t)p];
        if (mem.empty())
            continue;

        std::vector<int> chosen;
        chosen.reserve(reps_per_part);

        int first = mem[0];
        float best_center = l2_dist(base + (size_t)first * d, centers.data() + (size_t)p * d, d);
        for (size_t i = 1; i < mem.size(); ++i)
        {
            int id = mem[i];
            float dist = l2_dist(base + (size_t)id * d, centers.data() + (size_t)p * d, d);
            if (dist < best_center)
            {
                best_center = dist;
                first = id;
            }
        }
        chosen.push_back(first);

        while ((int)chosen.size() < reps_per_part && chosen.size() < mem.size())
        {
            int far_id = -1;
            float far_score = -1.0f;
            for (size_t i = 0; i < mem.size(); ++i)
            {
                int id = mem[i];
                bool used = false;
                for (size_t j = 0; j < chosen.size(); ++j)
                    if (chosen[j] == id)
                    {
                        used = true;
                        break;
                    }
                if (used)
                    continue;

                float min_d = l2_dist(base + (size_t)id * d, base + (size_t)chosen[0] * d, d);
                for (size_t j = 1; j < chosen.size(); ++j)
                {
                    float cur = l2_dist(base + (size_t)id * d, base + (size_t)chosen[j] * d, d);
                    if (cur < min_d)
                        min_d = cur;
                }
                if (min_d > far_score)
                {
                    far_score = min_d;
                    far_id = id;
                }
            }
            if (far_id < 0)
                break;
            chosen.push_back(far_id);
        }

        for (size_t j = 0; j < chosen.size(); ++j)
        {
            int id = chosen[j];
            rep_owner.push_back(p);
            rep_vecs.insert(rep_vecs.end(), base + (size_t)id * d, base + (size_t)(id + 1) * d);
        }
    }
}

// ---- offline partitioning (rank 0) ----

static inline void h2h_prepare_partitioning(float *base, size_t tn, size_t dim, int parts,
                                            const std::string &part_mode, int reps_per_part,
                                            std::vector<int> &group_of_vec,
                                            std::vector<float> &part_centers,
                                            std::vector<float> &router_reps,
                                            std::vector<int> &router_owner)
{
    std::string apath = h2h_part_assign_path(parts, part_mode);
    std::string cpath = h2h_part_center_path(parts, part_mode);
    std::string rppath = h2h_router_rep_path(parts, part_mode, reps_per_part);
    std::string ropath = h2h_router_owner_path(parts, part_mode, reps_per_part);

    if (load_vector_i32(apath, group_of_vec) &&
        load_vector_f32(cpath, part_centers) &&
        load_vector_f32(rppath, router_reps) &&
        load_vector_i32(ropath, router_owner))
    {
        return; // offline partitioning already exists
    }

    if (part_mode == "random")
    {
        group_of_vec.resize(tn);
        std::vector<int> perm(tn);
        for (size_t i = 0; i < tn; ++i)
            perm[i] = static_cast<int>(i);
        std::mt19937 rng(42);
        std::shuffle(perm.begin(), perm.end(), rng);
        for (size_t i = 0; i < tn; ++i)
            group_of_vec[(size_t)perm[i]] = static_cast<int>(i % parts);

        part_centers.assign((size_t)parts * dim, 0.0f);
        std::vector<int> cnt(parts, 0);
        for (size_t i = 0; i < tn; ++i)
        {
            int p = group_of_vec[i];
            ++cnt[(size_t)p];
            for (size_t j = 0; j < dim; ++j)
                part_centers[(size_t)p * dim + j] += base[i * dim + j];
        }
        for (int p = 0; p < parts; ++p)
            if (cnt[(size_t)p] > 0)
                for (size_t j = 0; j < dim; ++j)
                    part_centers[(size_t)p * dim + j] /= cnt[(size_t)p];
        h2h_build_router_reps(base, tn, dim, parts, group_of_vec, part_centers, reps_per_part, router_reps, router_owner);
    }
    else if (part_mode == "block")
    {
        group_of_vec.resize(tn);
        for (size_t i = 0; i < tn; ++i)
            group_of_vec[i] = static_cast<int>((i * parts) / tn);
        part_centers.assign((size_t)parts * dim, 0.0f);
        std::vector<int> cnt(parts, 0);
        for (size_t i = 0; i < tn; ++i)
        {
            int p = group_of_vec[i];
            ++cnt[(size_t)p];
            for (size_t j = 0; j < dim; ++j)
                part_centers[(size_t)p * dim + j] += base[i * dim + j];
        }
        for (int p = 0; p < parts; ++p)
            if (cnt[(size_t)p] > 0)
                for (size_t j = 0; j < dim; ++j)
                    part_centers[(size_t)p * dim + j] /= cnt[(size_t)p];
        h2h_build_router_reps(base, tn, dim, parts, group_of_vec, part_centers, reps_per_part, router_reps, router_owner);
    }
    else if (part_mode == "ivf")
    {
        h2h_train_part_centers_ivf(base, tn, dim, parts, part_centers, group_of_vec);
        h2h_build_router_reps(base, tn, dim, parts, group_of_vec, part_centers, reps_per_part, router_reps, router_owner);
    }
    else
    {
        h2h_train_part_centers_ip(base, tn, dim, parts, part_centers, group_of_vec);
        h2h_build_router_reps(base, tn, dim, parts, group_of_vec, part_centers, reps_per_part, router_reps, router_owner);
    }

    save_vector_i32(apath, group_of_vec);
    save_vector_f32(cpath, part_centers);
    save_vector_f32(rppath, router_reps);
    save_vector_i32(ropath, router_owner);
}

// ---- router index build ----

static inline void h2h_build_router_index(const std::string &part_mode, int parts, int reps_per_part,
                                          int router_M, int efc, size_t dim,
                                          const std::vector<float> &router_reps,
                                          const std::vector<int> &router_owner)
{
    std::string rpath = h2h_router_index_path(parts, part_mode, reps_per_part, router_M, efc);
    if (!file_exists(rpath))
    {
        InnerProductSpace rspace(dim);
        HierarchicalNSW<float> router(&rspace, std::max((size_t)1, router_owner.size()), router_M, efc);
        for (size_t rid = 0; rid < router_owner.size(); ++rid)
            router.addPoint(router_reps.data() + rid * dim, (labeltype)rid);
        router.saveIndex(rpath);
    }
}

// ---- per-query search (routing + local search) ----

static inline void h2h_search_query(const float *query, size_t dim, size_t k, int parts,
                                    const std::string &router_mode, int route_k, int route_cand,
                                    const std::vector<H2HPartIndex> &part_indexes,
                                    const std::vector<float> &router_reps,
                                    const std::vector<int> &router_owner,
                                    HierarchicalNSW<float> *router,
                                    std::vector<MinPair> &out_pairs)
{
    // ---- routing ----
    std::vector<std::pair<float, int>> rep_hits;
    if (router_mode == "hnsw" && router)
    {
        auto route = router->searchKnn(const_cast<float *>(query), std::min(route_cand, (int)router_owner.size()));
        while (!route.empty())
        {
            int rid = static_cast<int>(route.top().second);
            float dist = ip_dist(query, router_reps.data() + (size_t)rid * dim, dim);
            rep_hits.push_back({dist, rid});
            route.pop();
        }
    }
    else
    {
        rep_hits.reserve(router_owner.size());
    }

    std::vector<std::pair<float, int>> routed;
    std::vector<float> best_part((size_t)parts, 1e30f);

    if (router_mode == "all" || route_k >= parts)
    {
        routed.reserve(parts);
        for (int p = 0; p < parts; ++p)
            routed.push_back({0.0f, p});
    }
    else if (router_mode == "hnsw" && router)
    {
        std::sort(rep_hits.begin(), rep_hits.end());
        if ((int)rep_hits.size() > route_cand)
            rep_hits.resize(route_cand);
        for (size_t i = 0; i < rep_hits.size(); ++i)
        {
            int pid = router_owner[(size_t)rep_hits[i].second];
            if (rep_hits[i].first < best_part[(size_t)pid])
                best_part[(size_t)pid] = rep_hits[i].first;
        }
    }
    else
    {
        for (size_t rid = 0; rid < router_owner.size(); ++rid)
        {
            int pid = router_owner[rid];
            float dist = ip_dist(query, router_reps.data() + rid * dim, dim);
            if (dist < best_part[(size_t)pid])
                best_part[(size_t)pid] = dist;
        }
    }
    if (routed.empty())
    {
        for (int p = 0; p < parts; ++p)
            if (best_part[(size_t)p] < 1e29f)
                routed.push_back({best_part[(size_t)p], p});
        std::sort(routed.begin(), routed.end());
        if ((int)routed.size() > route_k)
            routed.resize(route_k);
    }

    // ---- local search ----
    Heap local_heap;
    for (const auto &rp : routed)
    {
        int p = rp.second;
        if (!part_indexes[(size_t)p].index)
            continue;
        auto ret = part_indexes[(size_t)p].index->searchKnn(const_cast<float *>(query), k);
        while (!ret.empty())
        {
            hp(local_heap, ret.top().first, static_cast<int>(ret.top().second), k);
            ret.pop();
        }
    }

    out_pairs.clear();
    out_pairs.reserve(k);
    while (!local_heap.empty())
    {
        out_pairs.push_back(local_heap.top());
        local_heap.pop();
    }
}
