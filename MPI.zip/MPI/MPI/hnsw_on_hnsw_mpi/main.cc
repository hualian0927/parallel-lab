#include <cstdlib>
#include <iomanip>
#include <iostream>
#include <memory>
#include <string>
#include <vector>
#include "hnswlib/hnswlib/hnswlib.h"
#include "hnsw_on_hnsw.h"

using namespace hnswlib;

int main(int argc, char **argv)
{
    MPI_Init(&argc, &argv);
    int rank = 0, sz = 1;
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
    MPI_Comm_size(MPI_COMM_WORLD, &sz);

    // ---- data loading (rank 0) ----
    size_t tn = 0, dim = 0, qn = 0, gd = 0;
    float *base = nullptr, *queries = nullptr;
    int *gt = nullptr;
    if (rank == 0)
    {
        std::string dp = "/anndata/";
        queries = load_fbin_like<float>(dp + "DEEP100K.query.fbin", qn, dim);
        base = load_fbin_like<float>(dp + "DEEP100K.base.100k.fbin", tn, dim);
        gt = load_fbin_like<int>(dp + "DEEP100K.gt.query.100k.top100.bin", qn, gd);
        qn = 2000;
    }

    MPI_Bcast(&tn, 1, MPI_UNSIGNED_LONG_LONG, 0, MPI_COMM_WORLD);
    MPI_Bcast(&dim, 1, MPI_UNSIGNED_LONG_LONG, 0, MPI_COMM_WORLD);
    MPI_Bcast(&qn, 1, MPI_UNSIGNED_LONG_LONG, 0, MPI_COMM_WORLD);
    MPI_Bcast(&gd, 1, MPI_UNSIGNED_LONG_LONG, 0, MPI_COMM_WORLD);

    // ---- parameters ----
    const size_t k = 10;
    const bool recall_first = env_i("ANN_RECALL_FIRST", 1) != 0;
    const int parts = std::max(1, env_i("ANN_PARTS", std::min(8, sz)));
    const int route_k = std::min(parts, env_i("ANN_ROUTE", recall_first ? parts : std::min(4, parts)));
    const int route_cand = std::min(parts, env_i("ANN_ROUTE_CAND", recall_first ? parts : std::min(parts, std::max(route_k * 2, 6))));
    const int M = env_i("ANN_M", recall_first ? 24 : 16);
    const int efc = env_i("ANN_EFC", recall_first ? 220 : 150);
    const int ef = env_i("ANN_EF", recall_first ? 120 : 40);
    const int router_M = env_i("ANN_ROUTER_M", 8);
    const int router_ef = env_i("ANN_ROUTER_EF", recall_first ? parts : 16);
    const int reps_per_part = std::max(1, env_i("ANN_REPS_PER_PART", recall_first ? 8 : 4));
    const bool build_only = env_i("ANN_BUILD_ONLY", 0) != 0;
    const std::string part_mode = std::getenv("ANN_PARTITION") ? std::getenv("ANN_PARTITION") : "ip";
    const std::string router_mode = std::getenv("ANN_ROUTER_MODE") ? std::getenv("ANN_ROUTER_MODE") : (recall_first ? "all" : "exact");

    // ---- owner assignment ----
    std::vector<int> owner_of_group(parts);
    for (int p = 0; p < parts; ++p)
        owner_of_group[(size_t)p] = p % sz;

    // ---- prepare partitioning (rank 0) ----
    std::vector<int> group_of_vec;
    std::vector<float> part_centers;
    std::vector<float> router_reps;
    std::vector<int> router_owner;
    if (rank == 0)
    {
        h2h_prepare_partitioning(base, tn, dim, parts, part_mode, reps_per_part,
                                 group_of_vec, part_centers, router_reps, router_owner);
        h2h_build_router_index(part_mode, parts, reps_per_part, router_M, efc, dim,
                               router_reps, router_owner);
    }
    bcast_vector_i32(group_of_vec, rank);
    bcast_vector_f32(part_centers, rank);
    bcast_vector_f32(router_reps, rank);
    bcast_vector_i32(router_owner, rank);

    // ---- scatter data ----
    std::vector<float> local_data;
    std::vector<int> local_ids, local_parts;
    scatter_grouped_vectors(base, tn, dim, group_of_vec, owner_of_group, rank, sz,
                            local_data, local_ids, local_parts);

    // ---- build / load part indexes ----
    InnerProductSpace space(dim);
    std::vector<std::vector<int>> pos_by_part(parts);
    for (size_t i = 0; i < local_parts.size(); ++i)
        pos_by_part[(size_t)local_parts[i]].push_back(static_cast<int>(i));

    std::vector<H2HPartIndex> part_indexes(parts);
    for (int p = 0; p < parts; ++p)
    {
        if (owner_of_group[(size_t)p] != rank || pos_by_part[(size_t)p].empty())
            continue;
        std::string path = h2h_part_index_path(parts, part_mode, M, efc, p);
        part_indexes[(size_t)p].part_id = p;
        if (file_exists(path))
        {
            part_indexes[(size_t)p].index.reset(new HierarchicalNSW<float>(&space, path));
        }
        else
        {
            auto idx = std::unique_ptr<HierarchicalNSW<float>>(new HierarchicalNSW<float>(&space, pos_by_part[(size_t)p].size(), M, efc));
            for (size_t j = 0; j < pos_by_part[(size_t)p].size(); ++j)
            {
                int pos = pos_by_part[(size_t)p][j];
                idx->addPoint(local_data.data() + (size_t)pos * dim, local_ids[(size_t)pos]);
            }
            idx->saveIndex(path);
            part_indexes[(size_t)p].index = std::move(idx);
        }
        part_indexes[(size_t)p].index->ef_ = ef;
    }

    if (rank == 0)
        delete[] base;

    if (build_only)
    {
        if (rank == 0)
            std::cout << "[H2H] build only finished, parts=" << parts
                      << " route=" << route_k << " mode=" << part_mode
                      << " reps=" << reps_per_part << " router=" << router_mode
                      << " recall_first=" << (recall_first ? 1 : 0) << "\n";
        delete[] queries;
        delete[] gt;
        MPI_Finalize();
        return 0;
    }

    // ---- broadcast queries & ground truth ----
    if (rank != 0)
    {
        queries = new float[qn * dim];
        gt = new int[qn * gd];
    }
    MPI_Bcast(queries, static_cast<int>(qn * dim), MPI_FLOAT, 0, MPI_COMM_WORLD);
    MPI_Bcast(gt, static_cast<int>(qn * gd), MPI_INT, 0, MPI_COMM_WORLD);

    // ---- load router index for search ----
    MPI_Barrier(MPI_COMM_WORLD);
    std::string rpath = h2h_router_index_path(parts, part_mode, reps_per_part, router_M, efc);
    InnerProductSpace router_space(dim);
    std::unique_ptr<HierarchicalNSW<float>> router;
    if (router_mode == "hnsw")
    {
        router.reset(new HierarchicalNSW<float>(&router_space, rpath));
        router->ef_ = std::max(router_ef, route_cand);
    }

    if (rank == 0)
        std::cout << "[H2H] MPI=" << sz
                  << " parts=" << parts
                  << " route=" << route_k
                  << " route_cand=" << route_cand
                  << " mode=" << part_mode
                  << " reps=" << reps_per_part
                  << " router=" << router_mode
                  << " recall_first=" << (recall_first ? 1 : 0)
                  << " M=" << M
                  << " ef=" << ef << "\n";

    // ---- search benchmark ----
    double ts = MPI_Wtime();
    float total_recall = 0.0f;
    for (size_t qi = 0; qi < qn; ++qi)
    {
        std::vector<MinPair> local_pairs;
        h2h_search_query(queries + qi * dim, dim, k, parts,
                         router_mode, route_k, route_cand,
                         part_indexes, router_reps, router_owner,
                         router.get(), local_pairs);

        std::vector<MinPair> merged;
        gather_topk_pairs(local_pairs, k, rank, sz, merged);
        if (rank == 0)
        {
            Heap g;
            for (const auto &p : merged)
                hp(g, p.first, p.second, k);
            total_recall += recall_of_heap(g, gt + qi * gd, k);
        }
    }
    double te = MPI_Wtime();

    if (rank == 0)
    {
        std::cout << std::fixed << std::setprecision(3)
                  << "[H2H] avg_lat=" << (te - ts) * 1e6 / qn
                  << " us recall=" << total_recall / qn << "\n";
    }

    delete[] queries;
    delete[] gt;
    MPI_Finalize();
    return 0;
}
