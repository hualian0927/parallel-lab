// IVF-MPI: 复用已验证的 IVF-SIMD (InnerProductSIMDNeon) + MPI数据分发+归并
// 编译: mpic++ main_mpi.cc -o main -O2 -std=c++17 -I../..
#include <chrono>
#include <iomanip>
#include "ivf_train_mpi.h"

int main(int argc, char** argv) {
    MPI_Init(&argc, &argv);
    int rank, sz;
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
    MPI_Comm_size(MPI_COMM_WORLD, &sz);
    srand(42 + rank);

    // ---- 加载+广播维度 ----
    size_t tn = 0, dim = 0, qn = 0, gd = 0;
    float *ab = nullptr, *qu = nullptr; int* gt = nullptr;
    if (rank == 0) {
        std::string dp = "/anndata/";
        qu = load_data<float>(dp + "DEEP100K.query.fbin", qn, dim);
        ab = load_data<float>(dp + "DEEP100K.base.100k.fbin", tn, dim);
        gt = load_data<int>(dp + "DEEP100K.gt.query.100k.top100.bin", qn, gd);
        qn = 2000;
    }
    MPI_Bcast(&tn, 1, MPI_UNSIGNED_LONG_LONG, 0, MPI_COMM_WORLD);
    MPI_Bcast(&dim, 1, MPI_UNSIGNED_LONG_LONG, 0, MPI_COMM_WORLD);
    MPI_Bcast(&qn, 1, MPI_UNSIGNED_LONG_LONG, 0, MPI_COMM_WORLD);
    MPI_Bcast(&gd, 1, MPI_UNSIGNED_LONG_LONG, 0, MPI_COMM_WORLD);

    // ---- Scatterv base ----
    size_t ln = tn / sz, rm = tn % sz;
    std::vector<int> sc(sz), ds(sz); size_t off = 0;
    for (int i = 0; i < sz; ++i) {
        sc[i] = (int)((ln + (size_t)(i < (int)rm ? 1 : 0)) * dim);
        ds[i] = (int)(off * dim);
        off += ln + (size_t)(i < (int)rm ? 1 : 0);
    }
    size_t mn = ln + (size_t)(rank < (int)rm ? 1 : 0);
    std::vector<float> lb(mn * dim);
    MPI_Scatterv(ab, sc.data(), ds.data(), MPI_FLOAT,
                 lb.data(), (int)(mn * dim), MPI_FLOAT, 0, MPI_COMM_WORLD);
    int goff = (int)(ds[rank] / dim);

    // ---- Rank0 全量训练 centroids → Bcast → 各进程本地建倒排 ----
    const int K = 1000;
    std::vector<float> cent;
    if (rank == 0) { train_ivf(ab, tn, dim, K, cent, 15); }
    size_t csz = cent.size();
    MPI_Bcast(&csz, 1, MPI_UNSIGNED_LONG_LONG, 0, MPI_COMM_WORLD);
    if (rank != 0) cent.resize(csz);
    MPI_Bcast(cent.data(), (int)csz, MPI_FLOAT, 0, MPI_COMM_WORLD);
    auto lists = build_ivf(lb.data(), mn, dim, K, cent);
    if (rank == 0) { delete[] ab; std::cout << "[IVF-MPI] K=" << K << " procs=" << sz << "\n"; }

    // ---- Bcast queries + gt ----
    if (rank != 0) { qu = new float[qn * dim]; gt = new int[qn * gd]; }
    MPI_Bcast(qu, (int)(qn * dim), MPI_FLOAT, 0, MPI_COMM_WORLD);
    MPI_Bcast(gt, (int)(qn * gd), MPI_INT, 0, MPI_COMM_WORLD);

    const size_t k = 10;
    int np_vals[] = {10, 20, 30, 50, 80, 120, 200};
    int num_np = sizeof(np_vals) / sizeof(np_vals[0]);

    for (int ni = 0; ni < num_np; ++ni) {
        int npv = np_vals[ni];
        double ts = MPI_Wtime(); float tr = 0;

        for (size_t i = 0; i < qn; ++i) {
            auto local = ivf_search(lb.data(), qu + i * dim, dim, k, npv, cent, lists);
            // 转成 global ID
            std::vector<std::pair<float, int>> lr;
            while (!local.empty()) {
                auto p = local.top(); local.pop();
                lr.push_back({p.first, p.second + goff});
            }
            int lc = (int)lr.size();
            std::vector<float> lbuf(lc * 2);
            for (int j = 0; j < lc; ++j) {
                lbuf[j * 2] = lr[j].first;
                lbuf[j * 2 + 1] = (float)lr[j].second;
            }
            // MPI Gather + Gatherv
            std::vector<int> ac(sz);
            MPI_Gather(&lc, 1, MPI_INT, ac.data(), 1, MPI_INT, 0, MPI_COMM_WORLD);
            std::vector<float> abuf; std::vector<int> rd(sz), acf(sz);
            if (rank == 0) {
                int t = 0;
                for (int j = 0; j < sz; ++j) {
                    acf[j] = ac[j] * 2; rd[j] = t * 2; t += ac[j];
                }
                abuf.resize(t * 2);
            }
            MPI_Gatherv(lbuf.data(), lc * 2, MPI_FLOAT,
                        abuf.data(), acf.data(), rd.data(), MPI_FLOAT, 0, MPI_COMM_WORLD);
            // Rank0 merge top-k + recall
            if (rank == 0) {
                Heap g; int tp = (int)abuf.size() / 2;
                for (int j = 0; j < tp; ++j)
                    heap_push(g, abuf[j * 2], (int)abuf[j * 2 + 1], k);
                std::set<int> gs(gt + i * gd, gt + i * gd + k);
                size_t h = 0; Heap t2 = g;
                while (!t2.empty()) {
                    if (gs.count(t2.top().second)) ++h; t2.pop();
                }
                tr += (float)h / k;
            }
        }
        double te = MPI_Wtime();
        if (rank == 0) {
            std::cout << std::fixed << std::setprecision(3);
            std::cout << "[IVF-MPI] np=" << npv
                      << " lat=" << (te - ts) * 1e6 / qn << "us"
                      << " recall=" << tr / qn << "\n";
        }
    }
    delete[] qu; delete[] gt;
    MPI_Finalize(); return 0;
}
