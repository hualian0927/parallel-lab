#pragma once
// ===================================================================
// IVF-MPI: 自包含版本 — 内联NEON距离, 无外部SIMD依赖
// ===================================================================
#include <algorithm>
#include <cmath>
#include <cstdlib>
#include <cstring>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <limits>
#include <mpi.h>
#include <queue>
#include <set>
#include <vector>
#if defined(__aarch64__) || defined(__ARM_NEON)
#include <arm_neon.h>
#endif

struct IVFList{std::vector<int>ids;};
using Heap=std::priority_queue<std::pair<float,int>>;

inline void hp(Heap& h,float d,int id,size_t k){
    if(h.size()<k)h.push({d,id});else if(d<h.top().first){h.pop();h.push({d,id});}
}

// L2距离(训练用)
inline float l2d(const float*a,const float*b,size_t d){
    float s=0;for(size_t i=0;i<d;++i){float df=a[i]-b[i];s+=df*df;}return s;
}

// 内积距离(搜索用) — 内联NEON, 不依赖外部头文件
inline float ip_dist(const float*a,const float*b,size_t d){
#if defined(__aarch64__) || defined(__ARM_NEON)
    float32x4_t s4=vdupq_n_f32(0.0f);size_t i=0;
    for(;i+4<=d;i+=4){float32x4_t va=vld1q_f32(a+i);float32x4_t vb=vld1q_f32(b+i);s4=vmlaq_f32(s4,va,vb);}
    float t[4];vst1q_f32(t,s4);float sum=t[0]+t[1]+t[2]+t[3];
    for(;i<d;++i)sum+=a[i]*b[i];return 1.0f-sum;
#else
    float s=0;for(size_t i=0;i<d;++i)s+=a[i]*b[i];return 1.0f-s;
#endif
}

// IVF训练(K-means, L2距离)
inline void train_ivf(const float*b,size_t n,size_t d,int K,std::vector<float>&cent,int it=10){
    cent.resize(K*d);for(int k=0;k<K;++k){int ri=rand()%n;std::memcpy(cent.data()+k*d,b+ri*d,d*4);}
    std::vector<int>as(n);std::vector<float>nc(K*d);std::vector<int>cn(K);
    for(int t=0;t<it;++t){for(size_t i=0;i<n;++i){float be=1e30f;int bk=0;
        for(int k=0;k<K;++k){float dt=l2d(b+i*d,cent.data()+k*d,d);if(dt<be){be=dt;bk=k;}}as[i]=bk;}
        std::fill(nc.begin(),nc.end(),0);std::fill(cn.begin(),cn.end(),0);
        for(size_t i=0;i<n;++i){int k=as[i];cn[k]++;for(size_t j=0;j<d;++j)nc[k*d+j]+=b[i*d+j];}
        for(int k=0;k<K;++k)if(cn[k]>0)for(size_t j=0;j<d;++j)cent[k*d+j]=nc[k*d+j]/cn[k];}
}

// 构建倒排链
inline std::vector<IVFList> build_ivf(const float*b,size_t n,size_t d,int K,const std::vector<float>&cent){
    std::vector<IVFList>ls(K);
    for(size_t i=0;i<n;++i){float be=1e30f;int bk=0;
        for(int k=0;k<K;++k){float dt=l2d(b+i*d,cent.data()+k*d,d);if(dt<be){dt=be;bk=k;}}ls[bk].ids.push_back((int)i);}
    return ls;
}

// IVF搜索(内积距离)
inline Heap ivf_search(const float*b,const float*q,size_t d,size_t k,int np,
    const std::vector<float>&cent,const std::vector<IVFList>&ls){
    int K=(int)cent.size()/(int)d;Heap c;
    for(int i=0;i<K;++i){float dt=ip_dist(q,cent.data()+i*d,d);hp(c,dt,i,np);}
    std::vector<int>pr;while(!c.empty()){pr.push_back(c.top().second);c.pop();}
    Heap f;for(int ci:pr)for(int vi:ls[ci].ids){float dt=ip_dist(q,b+vi*d,d);hp(f,dt,vi,k+10);}
    return f;
}

template<typename T>T*ld(const std::string&p,size_t&n,size_t&d){
    std::ifstream f(p,std::ios::binary);if(!f)return nullptr;
    int32_t h[2];f.read((char*)h,8);n=h[0];d=h[1];T*dt=new T[n*d];f.read((char*)dt,n*d*sizeof(T));return dt;
}
