// 最小化测试: 单进程IVF (无MPI), 确认ivf_train+ivf_search正确
// 编译: g++ test_ivf_only.cc -o test_ivf -O2 -std=c++17
#include "ivf_mpi.h"

int main() {
    size_t tn=0,dim=0,qn=0,gd=0;
    std::string dp="/anndata/";
    float* qu=ld<float>(dp+"DEEP100K.query.fbin",qn,dim);
    float* ab=ld<float>(dp+"DEEP100K.base.100k.fbin",tn,dim);
    int*   gt=ld<int>(dp+"DEEP100K.gt.query.100k.top100.bin",qn,gd);
    if(!qu||!ab||!gt)return 1;
    qn=2000; const size_t k=10;
    const int K=1000, np=50;

    srand(42);
    std::vector<float>cent;
    train_ivf(ab,tn,dim,K,cent,12);
    auto ls=build_ivf(ab,tn,dim,K,cent);
    // 统计各簇大小
    size_t total_assigned=0, empty_clusters=0;
    for(auto&l:ls){total_assigned+=l.ids.size();if(l.ids.empty())++empty_clusters;}
    std::cout<<"[TEST] K="<<K<<" total_assigned="<<total_assigned
        <<" empty_clusters="<<empty_clusters<<"\n";

    // 查第0个query: 打印粗排选中的簇和它们的向量数
    int Kc=(int)cent.size()/(int)dim;Heap coarse;
    for(int i=0;i<Kc;++i){float dt=ip_dist(qu,cent.data()+i*dim,dim);hp(coarse,dt,i,np);}
    std::vector<int>pr;while(!coarse.empty()){pr.push_back(coarse.top().second);coarse.pop();}
    std::cout<<"[TEST q0] probed clusters:";
    size_t total_in_probed=0;
    for(int ci:pr){size_t sz=ls[ci].ids.size();total_in_probed+=sz;
        std::cout<<" c"<<ci<<"="<<sz;}
    std::cout<<" total="<<total_in_probed<<"\n";

    // 全量recall
    float tr=0;
    for(size_t i=0;i<qn;++i){
        auto r=ivf_search(ab,qu+i*dim,dim,k,np,cent,ls);
        std::set<int>gs(gt+i*gd,gt+i*gd+k);size_t h=0;
        while(!r.empty()){if(gs.count(r.top().second))++h;r.pop();}
        tr+=(float)h/k;
    }
    std::cout<<"[TEST] recall="<<tr/qn<<"\n";
    delete[] ab;delete[] qu;delete[] gt;return 0;
}
