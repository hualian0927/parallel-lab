#pragma once
// ===================================================================
// IVF-MPI: 从 ivf_train.h 逐行迁移的 IVF 训练+搜索 + MPI 层
// 训练: L2 k-means (与串行版 ivf_train.h 完全一致)
// 搜索: InnerProductSIMDNeon 粗排+精排
// ===================================================================
#include <algorithm>
#include <cstdlib>
#include <cstring>
#include <fstream>
#include <iostream>
#include <limits>
#include <mpi.h>
#include <queue>
#include <set>
#include <vector>
#include "hnswlib/hnswlib/simd_utils.h"

// ---- 基础结构 ----
struct IVFList { std::vector<int> ids; };
using Heap = std::priority_queue<std::pair<float, int>>;

static inline void heap_push(Heap& h, float d, int id, size_t k) {
    if (h.size() < k) h.push({d, id});
    else if (d < h.top().first) { h.pop(); h.push({d, id}); }
}

// ===================================================================
// IVF 训练 (直接从 ivf_train.h 迁移, 去除 OpenMP)
// ===================================================================
static inline void train_ivf(const float* base, size_t n, size_t d,
                             int K, std::vector<float>& centroids,
                             int max_iter = 15) {
    centroids.resize(K * d);
    for (int k = 0; k < K; ++k) {
        int ri = rand() % n;
        const float* src = base + ri * d;
        for (size_t j = 0; j < d; ++j) centroids[k * d + j] = src[j];
    }

    std::vector<int> assign(n);
    std::vector<float> new_cent(K * d, 0.0f);
    std::vector<int> counts(K, 0);

    for (int iter = 0; iter < max_iter; ++iter) {
        // assign: 每个向量找最近聚类中心 (L2距离)
        for (size_t i = 0; i < n; ++i) {
            float best = std::numeric_limits<float>::max();
            int bk = 0;
            const float* vec = base + i * d;
            for (int k = 0; k < K; ++k) {
                float dist = 0.0f;
                const float* c = centroids.data() + k * d;
                for (size_t j = 0; j < d; ++j) {
                    float df = vec[j] - c[j]; dist += df * df;
                }
                if (dist < best) { best = dist; bk = k; }
            }
            assign[i] = bk;
        }
        // update
        std::fill(new_cent.begin(), new_cent.end(), 0.0f);
        std::fill(counts.begin(), counts.end(), 0);
        for (size_t i = 0; i < n; ++i) {
            int k = assign[i]; counts[k]++;
            const float* vec = base + i * d;
            for (size_t j = 0; j < d; ++j)
                new_cent[k * d + j] += vec[j];
        }
        for (int k = 0; k < K; ++k) {
            if (counts[k] > 0) {
                for (size_t j = 0; j < d; ++j)
                    centroids[k * d + j] = new_cent[k * d + j] / counts[k];
            }
        }
    }
}

// ===================================================================
// 构建倒排表 (直接从 ivf_train.h 迁移, 去除 OpenMP)
// ===================================================================
static inline std::vector<IVFList> build_ivf(
    const float* base, size_t n, size_t d,
    int K, const std::vector<float>& centroids) {
    std::vector<IVFList> lists(K);
    for (size_t i = 0; i < n; ++i) {
        float best = std::numeric_limits<float>::max();
        int bk = 0;
        const float* vec = base + i * d;
        for (int k = 0; k < K; ++k) {
            float dist = 0.0f;
            const float* c = centroids.data() + k * d;
            for (size_t j = 0; j < d; ++j) {
                float df = vec[j] - c[j]; dist += df * df;
            }
            if (dist < best) { best = dist; bk = k; }
        }
        lists[bk].ids.push_back((int)i);
    }
    return lists;
}

// ===================================================================
// IVF-SIMD 搜索 (InnerProductSIMDNeon, 串行版逻辑)
// ===================================================================
static inline Heap ivf_search(
    const float* base, const float* query, size_t d, size_t k, int nprobe,
    const std::vector<float>& centroids, const std::vector<IVFList>& lists) {
    int K = (int)centroids.size() / (int)d;

    // 粗排: 找最近 nprobe 个簇 (IP距离)
    Heap coarse;
    for (int c = 0; c < K; ++c) {
        float dist = InnerProductSIMDNeon(query, centroids.data() + c * d, d);
        heap_push(coarse, dist, c, nprobe);
    }
    std::vector<int> probes;
    while (!coarse.empty()) { probes.push_back(coarse.top().second); coarse.pop(); }

    // 精排: 扫描选中簇中所有向量 (IP距离)
    Heap fine;
    for (int cid : probes) {
        for (int vid : lists[cid].ids) {
            float dist = InnerProductSIMDNeon(query, base + vid * d, d);
            heap_push(fine, dist, vid, k + 10);
        }
    }
    return fine;
}

// ===================================================================
// 数据加载
// ===================================================================
template<typename T>
T* load_data(const std::string& path, size_t& n, size_t& d) {
    std::ifstream f(path, std::ios::binary);
    if (!f) { std::cerr << "[ERR] open " << path << "\n"; return nullptr; }
    int32_t h[2]; f.read((char*)h, 8);
    n = h[0]; d = h[1];
    T* data = new T[n * d];
    f.read((char*)data, n * d * sizeof(T));
    return data;
}
