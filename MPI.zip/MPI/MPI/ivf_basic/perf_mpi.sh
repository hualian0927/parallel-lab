#!/bin/bash
# perf 分析 MPI 程序 (每个进程独立 perf)
BIN="./main"
FLAGS="cpu-cycles,instructions,cache-misses,context-switches,cpu-migrations"
echo "=== perf stat (all procs) ==="
perf stat -e $FLAGS -o perf_stat.txt -- mpirun -np 8 $BIN
cat perf_stat.txt
echo "=== perf record (per proc sampling) ==="
perf record -g --call-graph dwarf -e cpu-cycles:pp -o perf_record.data -- mpirun -np 4 $BIN
perf report -i perf_record.data --stdio --sort=symbol --percent-limit=1.0 | head -40
