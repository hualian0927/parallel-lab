#pragma once

#include <algorithm>
#include <atomic>
#include <chrono>
#include <cstdlib>
#include <memory>
#include <pthread.h>
#include <string>
#include <vector>
#include "hnswlib/hnswlib/hnswlib.h"
#include "../graph_index_common/common.h"

using namespace hnswlib;

// ---- data structures ----

struct IvfHnswClusterIndex
{
    int cid = -1;
    std::unique_ptr<HierarchicalNSW<float>> index;
};

struct IvfHnswThreadStat
{
    double work_us = 0.0;
    size_t tasks = 0;
};

struct IvfHnswWorkerArg
{
    const float *queries;
    size_t qn, d, cluster_k, local_k;
    const std::vector<float> *cent;
    const std::vector<IvfHnswClusterIndex> *clusters;
    int K, nprobe;
    int tid;
    std::atomic<size_t> *next;
    std::vector<std::vector<MinPair>> *out;
    std::vector<IvfHnswThreadStat> *stats;
    std::vector<double> *query_us;
};

// ---- path helpers ----

static inline std::string ivf_hnsw_centroids_path(int K)
{
    return files_path("ivf_hnsw_centroids_K" + std::to_string(K) + ".bin");
}

static inline std::string ivf_hnsw_cluster_index_path(int sz, int rank, int K, int cid, int M, int efc)
{
    return files_path("ivf_hnsw_" + rank_tag(sz, rank) +
                      "_K" + std::to_string(K) +
                      "_c" + std::to_string(cid) +
                      "_M" + std::to_string(M) +
                      "_efc" + std::to_string(efc) + ".index");
}

// ---- IVF training ----

static inline void ivf_hnsw_train_ivf(const float *base, size_t n, size_t d, int K,
                                      std::vector<float> &cent, int it = 6)
{
    cent.resize((size_t)K * d);
    for (int k = 0; k < K; ++k)
        std::memcpy(cent.data() + (size_t)k * d, base + (size_t)(k % n) * d, d * sizeof(float));

    std::vector<int> as(n);
    std::vector<float> nc((size_t)K * d);
    std::vector<int> cn(K);
    for (int t = 0; t < it; ++t)
    {
        for (size_t i = 0; i < n; ++i)
        {
            float best = 1e30f;
            int bk = 0;
            for (int k = 0; k < K; ++k)
            {
                float dist = l2_dist(base + i * d, cent.data() + (size_t)k * d, d);
                if (dist < best)
                {
                    best = dist;
                    bk = k;
                }
            }
            as[i] = bk;
        }
        std::fill(nc.begin(), nc.end(), 0.0f);
        std::fill(cn.begin(), cn.end(), 0);
        for (size_t i = 0; i < n; ++i)
        {
            int k = as[i];
            ++cn[k];
            for (size_t j = 0; j < d; ++j)
                nc[(size_t)k * d + j] += base[i * d + j];
        }
        for (int k = 0; k < K; ++k)
            if (cn[k] > 0)
                for (size_t j = 0; j < d; ++j)
                    cent[(size_t)k * d + j] = nc[(size_t)k * d + j] / cn[k];
    }
}

// ---- probe selection ----

static inline std::vector<int> ivf_hnsw_select_probes(const float *q, const std::vector<float> &cent,
                                                       size_t d, int K, int nprobe)
{
    Heap coarse;
    for (int c = 0; c < K; ++c)
        hp(coarse, l2_dist(q, cent.data() + (size_t)c * d, d), c, nprobe);
    std::vector<int> probes;
    while (!coarse.empty())
    {
        probes.push_back(coarse.top().second);
        coarse.pop();
    }
    return probes;
}

// ---- local search ----

static inline void ivf_hnsw_search_one_local(const float *q, size_t d, const std::vector<float> &cent,
                                              const std::vector<IvfHnswClusterIndex> &clusters,
                                              size_t cluster_k, size_t local_k, int K, int nprobe,
                                              std::vector<MinPair> &out)
{
    Heap local;
    std::vector<int> probes = ivf_hnsw_select_probes(q, cent, d, K, nprobe);
    for (int cid : probes)
    {
        if (!clusters[(size_t)cid].index)
            continue;
        auto ret = clusters[(size_t)cid].index->searchKnn(const_cast<float *>(q), cluster_k);
        while (!ret.empty())
        {
            hp(local, ret.top().first, static_cast<int>(ret.top().second), local_k);
            ret.pop();
        }
    }
    out.clear();
    while (!local.empty())
    {
        out.push_back(local.top());
        local.pop();
    }
}

// ---- worker thread ----

static void *ivf_hnsw_worker(void *arg)
{
    IvfHnswWorkerArg *a = static_cast<IvfHnswWorkerArg *>(arg);
    while (true)
    {
        size_t qi = a->next->fetch_add(1);
        if (qi >= a->qn)
            break;
        auto ts = std::chrono::steady_clock::now();
        ivf_hnsw_search_one_local(a->queries + qi * a->d, a->d, *a->cent, *a->clusters,
                                   a->cluster_k, a->local_k, a->K, a->nprobe, (*a->out)[qi]);
        auto te = std::chrono::steady_clock::now();
        double us = std::chrono::duration<double, std::micro>(te - ts).count();
        (*a->stats)[(size_t)a->tid].work_us += us;
        (*a->stats)[(size_t)a->tid].tasks += 1;
        (*a->query_us)[qi] = us;
    }
    return nullptr;
}
