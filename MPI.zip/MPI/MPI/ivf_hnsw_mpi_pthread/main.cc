#include <algorithm>
#include <atomic>
#include <chrono>
#include <cstdlib>
#include <cstring>
#include <iomanip>
#include <iostream>
#include <memory>
#include <pthread.h>
#include <string>
#include <vector>
#include "hnswlib/hnswlib/hnswlib.h"
#include "ivf_hnsw.h"

using namespace hnswlib;

int main(int argc, char **argv)
{
    MPI_Init(&argc, &argv);
    int rank = 0, sz = 1;
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
    MPI_Comm_size(MPI_COMM_WORLD, &sz);

    double t_build0 = MPI_Wtime();

    // ---- data loading (rank 0) ----
    size_t tn = 0, dim = 0, qn = 0, gd = 0;
    float *base = nullptr, *queries = nullptr;
    int *gt = nullptr;
    if (rank == 0)
    {
        std::string dp = "/anndata/";
        queries = load_fbin_like<float>(dp + "DEEP100K.query.fbin", qn, dim);
        base = load_fbin_like<float>(dp + "DEEP100K.base.100k.fbin", tn, dim);
        gt = load_fbin_like<int>(dp + "DEEP100K.gt.query.100k.top100.bin", qn, gd);
        qn = 2000;
    }

    MPI_Bcast(&tn, 1, MPI_UNSIGNED_LONG_LONG, 0, MPI_COMM_WORLD);
    MPI_Bcast(&dim, 1, MPI_UNSIGNED_LONG_LONG, 0, MPI_COMM_WORLD);
    MPI_Bcast(&qn, 1, MPI_UNSIGNED_LONG_LONG, 0, MPI_COMM_WORLD);
    MPI_Bcast(&gd, 1, MPI_UNSIGNED_LONG_LONG, 0, MPI_COMM_WORLD);

    // ---- parameters ----
    const size_t k = 10;
    const int Kivf = env_i("ANN_KIVF", 64);
    const int nprobe = env_i("ANN_NPROBE", 7);
    const int M = env_i("ANN_HNSW_M", 16);
    const int efc = env_i("ANN_EFC", 150);
    const int ef = env_i("ANN_EF", 80);
    const int nth = env_i("ANN_THREADS", 1);
    const size_t cluster_k = (size_t)std::max(env_i("ANN_CLUSTER_K", 20), (int)k);
    const size_t local_k = (size_t)std::max(env_i("ANN_LOCAL_K", 24), (int)cluster_k);
    const bool build_only = env_i("ANN_BUILD_ONLY", 0) != 0;

    // ---- train / load centroids (rank 0) ----
    std::vector<float> centroids;
    if (rank == 0)
    {
        std::string cpath = ivf_hnsw_centroids_path(Kivf);
        if (!load_vector_f32(cpath, centroids))
        {
            ivf_hnsw_train_ivf(base, tn, dim, Kivf, centroids);
            save_vector_f32(cpath, centroids);
        }
    }
    bcast_vector_f32(centroids, rank);

    // ---- owner assignment ----
    std::vector<int> group_of_vec, owner_of_group(Kivf);
    for (int c = 0; c < Kivf; ++c)
        owner_of_group[(size_t)c] = c % sz;
    if (rank == 0)
    {
        group_of_vec.resize(tn);
        for (size_t i = 0; i < tn; ++i)
        {
            float best = 1e30f;
            int bk = 0;
            for (int c = 0; c < Kivf; ++c)
            {
                float dist = l2_dist(base + i * dim, centroids.data() + (size_t)c * dim, dim);
                if (dist < best)
                {
                    best = dist;
                    bk = c;
                }
            }
            group_of_vec[i] = bk;
        }
    }
    bcast_vector_i32(group_of_vec, rank);

    // ---- scatter data ----
    std::vector<float> local_data;
    std::vector<int> local_ids, local_clusters;
    scatter_grouped_vectors(base, tn, dim, group_of_vec, owner_of_group, rank, sz,
                            local_data, local_ids, local_clusters);

    // ---- build / load cluster indexes ----
    InnerProductSpace space(dim);
    std::vector<std::vector<int>> pos_by_cluster(Kivf);
    for (size_t i = 0; i < local_clusters.size(); ++i)
        pos_by_cluster[(size_t)local_clusters[i]].push_back(static_cast<int>(i));

    std::vector<IvfHnswClusterIndex> clusters(Kivf);
    for (int cid = 0; cid < Kivf; ++cid)
    {
        if (owner_of_group[(size_t)cid] != rank || pos_by_cluster[(size_t)cid].empty())
            continue;
        clusters[(size_t)cid].cid = cid;
        std::string path = ivf_hnsw_cluster_index_path(sz, rank, Kivf, cid, M, efc);
        if (file_exists(path))
        {
            clusters[(size_t)cid].index.reset(new HierarchicalNSW<float>(&space, path));
        }
        else
        {
            auto idx = std::unique_ptr<HierarchicalNSW<float>>(new HierarchicalNSW<float>(&space, pos_by_cluster[(size_t)cid].size(), M, efc));
            for (size_t j = 0; j < pos_by_cluster[(size_t)cid].size(); ++j)
            {
                int pos = pos_by_cluster[(size_t)cid][j];
                idx->addPoint(local_data.data() + (size_t)pos * dim, local_ids[(size_t)pos]);
            }
            idx->saveIndex(path);
            clusters[(size_t)cid].index = std::move(idx);
        }
        clusters[(size_t)cid].index->ef_ = ef;
    }
    double t_build1 = MPI_Wtime();

    if (rank == 0)
        delete[] base;

    // ---- build stats ----
    unsigned long long local_points_ull = static_cast<unsigned long long>(local_ids.size());
    unsigned long long local_cluster_ull = 0;
    for (int cid = 0; cid < Kivf; ++cid)
        if (clusters[(size_t)cid].index)
            ++local_cluster_ull;

    double build_ms = (t_build1 - t_build0) * 1e3;
    double build_ms_min = 0.0, build_ms_max = 0.0, build_ms_sum = 0.0;
    unsigned long long points_min = 0, points_max = 0, points_sum = 0;
    unsigned long long cluster_min = 0, cluster_max = 0, cluster_sum = 0;
    MPI_Reduce(&build_ms, &build_ms_min, 1, MPI_DOUBLE, MPI_MIN, 0, MPI_COMM_WORLD);
    MPI_Reduce(&build_ms, &build_ms_max, 1, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD);
    MPI_Reduce(&build_ms, &build_ms_sum, 1, MPI_DOUBLE, MPI_SUM, 0, MPI_COMM_WORLD);
    MPI_Reduce(&local_points_ull, &points_min, 1, MPI_UNSIGNED_LONG_LONG, MPI_MIN, 0, MPI_COMM_WORLD);
    MPI_Reduce(&local_points_ull, &points_max, 1, MPI_UNSIGNED_LONG_LONG, MPI_MAX, 0, MPI_COMM_WORLD);
    MPI_Reduce(&local_points_ull, &points_sum, 1, MPI_UNSIGNED_LONG_LONG, MPI_SUM, 0, MPI_COMM_WORLD);
    MPI_Reduce(&local_cluster_ull, &cluster_min, 1, MPI_UNSIGNED_LONG_LONG, MPI_MIN, 0, MPI_COMM_WORLD);
    MPI_Reduce(&local_cluster_ull, &cluster_max, 1, MPI_UNSIGNED_LONG_LONG, MPI_MAX, 0, MPI_COMM_WORLD);
    MPI_Reduce(&local_cluster_ull, &cluster_sum, 1, MPI_UNSIGNED_LONG_LONG, MPI_SUM, 0, MPI_COMM_WORLD);

    if (build_only)
    {
        if (rank == 0)
            std::cout << "[IVF-HNSW] build only finished, K=" << Kivf
                      << " nprobe=" << nprobe << " M=" << M << " efc=" << efc
                      << " build_ms[min/avg/max]=" << std::fixed << std::setprecision(3)
                      << build_ms_min << "/" << (build_ms_sum / sz) << "/" << build_ms_max
                      << " points[min/avg/max]=" << points_min << "/" << (points_sum / sz) << "/" << points_max
                      << " clusters[min/avg/max]=" << cluster_min << "/" << (cluster_sum / sz) << "/" << cluster_max
                      << "\n";
        delete[] queries;
        delete[] gt;
        MPI_Finalize();
        return 0;
    }

    // ---- broadcast queries & ground truth ----
    if (rank != 0)
    {
        queries = new float[qn * dim];
        gt = new int[qn * gd];
    }
    MPI_Bcast(queries, static_cast<int>(qn * dim), MPI_FLOAT, 0, MPI_COMM_WORLD);
    MPI_Bcast(gt, static_cast<int>(qn * gd), MPI_INT, 0, MPI_COMM_WORLD);

    if (rank == 0)
        std::cout << "[IVF-HNSW] MPI=" << sz
                  << " pthread=" << nth
                  << " K=" << Kivf
                  << " nprobe=" << nprobe
                  << " cluster_k=" << cluster_k
                  << " local_k=" << local_k
                  << " ef=" << ef
                  << " build_ms[min/avg/max]=" << std::fixed << std::setprecision(3)
                  << build_ms_min << "/" << (build_ms_sum / sz) << "/" << build_ms_max
                  << " points[min/avg/max]=" << points_min << "/" << (points_sum / sz) << "/" << points_max
                  << " clusters[min/avg/max]=" << cluster_min << "/" << (cluster_sum / sz) << "/" << cluster_max
                  << "\n";

    // ---- search benchmark ----
    std::vector<std::vector<MinPair>> local_results(qn);
    std::vector<IvfHnswThreadStat> thread_stats((size_t)nth);
    std::vector<double> query_us(qn, 0.0);
    std::atomic<size_t> next(0);
    std::vector<pthread_t> th(nth);
    std::vector<IvfHnswWorkerArg> args((size_t)nth);

    MPI_Barrier(MPI_COMM_WORLD);
    double ts = MPI_Wtime();
    for (int t = 0; t < nth; ++t)
    {
        args[(size_t)t].queries = queries;
        args[(size_t)t].qn = qn;
        args[(size_t)t].d = dim;
        args[(size_t)t].cluster_k = cluster_k;
        args[(size_t)t].local_k = local_k;
        args[(size_t)t].cent = &centroids;
        args[(size_t)t].clusters = &clusters;
        args[(size_t)t].K = Kivf;
        args[(size_t)t].nprobe = nprobe;
        args[(size_t)t].tid = t;
        args[(size_t)t].next = &next;
        args[(size_t)t].out = &local_results;
        args[(size_t)t].stats = &thread_stats;
        args[(size_t)t].query_us = &query_us;
        pthread_create(&th[t], nullptr, ivf_hnsw_worker, &args[(size_t)t]);
    }
    for (int t = 0; t < nth; ++t)
        pthread_join(th[t], nullptr);
    double tsearch = MPI_Wtime();

    // ---- pack send buffer ----
    const float invalid = 1e30f;
    std::vector<float> sendbuf(qn * local_k * 2, invalid);
    for (size_t qi = 0; qi < qn; ++qi)
    {
        size_t base = qi * local_k * 2;
        for (size_t j = 0; j < local_k; ++j)
        {
            if (j < local_results[qi].size())
            {
                sendbuf[base + j * 2] = local_results[qi][j].first;
                sendbuf[base + j * 2 + 1] = (float)local_results[qi][j].second;
            }
            else
            {
                sendbuf[base + j * 2] = invalid;
                sendbuf[base + j * 2 + 1] = -1.0f;
            }
        }
    }

    std::vector<float> gatherbuf;
    int send_count = (int)sendbuf.size();
    if (rank == 0)
        gatherbuf.resize((size_t)sz * sendbuf.size());
    MPI_Gather(sendbuf.data(), send_count, MPI_FLOAT,
               rank == 0 ? gatherbuf.data() : nullptr, send_count, MPI_FLOAT,
               0, MPI_COMM_WORLD);
    double tgather = MPI_Wtime();

    // ---- merge & recall (rank 0) ----
    float total_recall = 0.0f;
    if (rank == 0)
    {
        for (size_t qi = 0; qi < qn; ++qi)
        {
            Heap g;
            for (int r = 0; r < sz; ++r)
            {
                size_t base = ((size_t)r * qn + qi) * local_k * 2;
                for (size_t j = 0; j < local_k; ++j)
                {
                    int id = (int)gatherbuf[base + j * 2 + 1];
                    if (id >= 0 && gatherbuf[base + j * 2] < invalid * 0.5f)
                        hp(g, gatherbuf[base + j * 2], id, k);
                }
            }
            total_recall += recall_of_heap(g, gt + qi * gd, k);
        }
    }
    double te = MPI_Wtime();

    // ---- reduce timing stats ----
    double local_search_ms = (tsearch - ts) * 1e3;
    double local_gather_ms = (tgather - tsearch) * 1e3;
    double local_merge_ms = rank == 0 ? (te - tgather) * 1e3 : 0.0;
    double local_total_ms = (te - ts) * 1e3;
    double search_min = 0.0, search_max = 0.0, search_sum = 0.0;
    double gather_min = 0.0, gather_max = 0.0, gather_sum = 0.0;
    double merge_min = 0.0, merge_max = 0.0, merge_sum = 0.0;
    double total_min = 0.0, total_max = 0.0, total_sum = 0.0;
    MPI_Reduce(&local_search_ms, &search_min, 1, MPI_DOUBLE, MPI_MIN, 0, MPI_COMM_WORLD);
    MPI_Reduce(&local_search_ms, &search_max, 1, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD);
    MPI_Reduce(&local_search_ms, &search_sum, 1, MPI_DOUBLE, MPI_SUM, 0, MPI_COMM_WORLD);
    MPI_Reduce(&local_gather_ms, &gather_min, 1, MPI_DOUBLE, MPI_MIN, 0, MPI_COMM_WORLD);
    MPI_Reduce(&local_gather_ms, &gather_max, 1, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD);
    MPI_Reduce(&local_gather_ms, &gather_sum, 1, MPI_DOUBLE, MPI_SUM, 0, MPI_COMM_WORLD);
    MPI_Reduce(&local_merge_ms, &merge_min, 1, MPI_DOUBLE, MPI_MIN, 0, MPI_COMM_WORLD);
    MPI_Reduce(&local_merge_ms, &merge_max, 1, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD);
    MPI_Reduce(&local_merge_ms, &merge_sum, 1, MPI_DOUBLE, MPI_SUM, 0, MPI_COMM_WORLD);
    MPI_Reduce(&local_total_ms, &total_min, 1, MPI_DOUBLE, MPI_MIN, 0, MPI_COMM_WORLD);
    MPI_Reduce(&local_total_ms, &total_max, 1, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD);
    MPI_Reduce(&local_total_ms, &total_sum, 1, MPI_DOUBLE, MPI_SUM, 0, MPI_COMM_WORLD);

    // ---- reduce query latency stats ----
    double qsum = 0.0;
    double qmax = 0.0;
    for (size_t qi = 0; qi < qn; ++qi)
    {
        qsum += query_us[qi];
        if (query_us[qi] > qmax)
            qmax = query_us[qi];
    }
    double qavg = qn ? qsum / qn : 0.0;
    double qp50 = percentile_us(query_us, 0.50);
    double qp95 = percentile_us(query_us, 0.95);
    double qp99 = percentile_us(query_us, 0.99);
    double qavg_max = 0.0, qavg_min = 0.0, qavg_sum = 0.0, qmax_max = 0.0;
    MPI_Reduce(&qavg, &qavg_min, 1, MPI_DOUBLE, MPI_MIN, 0, MPI_COMM_WORLD);
    MPI_Reduce(&qavg, &qavg_max, 1, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD);
    MPI_Reduce(&qavg, &qavg_sum, 1, MPI_DOUBLE, MPI_SUM, 0, MPI_COMM_WORLD);
    MPI_Reduce(&qmax, &qmax_max, 1, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD);

    // ---- rank 0 output ----
    if (rank == 0)
    {
        size_t task_min = thread_stats.empty() ? 0 : thread_stats[0].tasks;
        size_t task_max = 0;
        size_t task_sum = 0;
        double work_min = thread_stats.empty() ? 0.0 : thread_stats[0].work_us;
        double work_max = 0.0;
        double work_sum = 0.0;
        for (int t = 0; t < nth; ++t)
        {
            task_min = std::min(task_min, thread_stats[(size_t)t].tasks);
            task_max = std::max(task_max, thread_stats[(size_t)t].tasks);
            task_sum += thread_stats[(size_t)t].tasks;
            work_min = std::min(work_min, thread_stats[(size_t)t].work_us);
            work_max = std::max(work_max, thread_stats[(size_t)t].work_us);
            work_sum += thread_stats[(size_t)t].work_us;
        }

        std::cout << std::fixed << std::setprecision(3)
                  << "[IVF-HNSW] avg_lat=" << (te - ts) * 1e6 / qn
                  << " us recall=" << total_recall / qn
                  << " search_ms[min/avg/max]=" << search_min << "/" << (search_sum / sz) << "/" << search_max
                  << " gather_ms[min/avg/max]=" << gather_min << "/" << (gather_sum / sz) << "/" << gather_max
                  << " merge_ms[min/avg/max]=" << merge_min << "/" << (merge_sum / sz) << "/" << merge_max
                  << " total_ms[min/avg/max]=" << total_min << "/" << (total_sum / sz) << "/" << total_max
                  << " qavg_us[min/avg/max]=" << qavg_min << "/" << (qavg_sum / sz) << "/" << qavg_max
                  << " qmax_us=" << qmax_max
                  << "\n";
        std::cout << "[IVF-HNSW] rank0_query_us p50/p95/p99/max="
                  << qp50 << "/" << qp95 << "/" << qp99 << "/" << qmax
                  << " rank0_thread_tasks min/avg/max=" << task_min << "/" << (task_sum / nth) << "/" << task_max
                  << " rank0_thread_work_us min/avg/max=" << work_min << "/" << (work_sum / nth) << "/" << work_max
                  << "\n";
        for (int t = 0; t < nth; ++t)
        {
            std::cout << "[IVF-HNSW] rank0_thread[" << t << "]"
                      << " tasks=" << thread_stats[(size_t)t].tasks
                      << " work_us=" << thread_stats[(size_t)t].work_us
                      << "\n";
        }
    }

    delete[] queries;
    delete[] gt;
    MPI_Finalize();
    return 0;
}
