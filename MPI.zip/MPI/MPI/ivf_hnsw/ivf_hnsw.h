#pragma once
// IVF-HNSW MPI: IVF簇分布在MPI进程间, 每簇内建NSW图, 并行簇间搜索, merge
// 指导书4.2: "先构建IVF, 每个簇建立HNSW, 簇间MPI并行搜索"
#include <algorithm>
#include <cstdlib>
#include <cstring>
#include <iostream>
#include <limits>
#include <mpi.h>
#include <queue>
#include <random>
#include <set>
#include <vector>

using Heap = std::priority_queue<std::pair<float, int>>;

inline float ip_dist(const float* a, const float* b, size_t d) {
    float s=0;for(size_t i=0;i<d;++i)s+=a[i]*b[i];return 1.0f-s;
}
inline float l2_dist(const float* a, const float* b, size_t d) {
    float s=0;for(size_t i=0;i<d;++i){float df=a[i]-b[i];s+=df*df;}return s;
}
inline void hp(Heap& h, float d, int id, size_t k) {
    if(h.size()<k)h.push({d,id});else if(d<h.top().first){h.pop();h.push({d,id});}
}

struct NSWGraph {
    size_t n,d;int M;std::vector<std::vector<int>>adj;const float*base;
    void build(const float*data,size_t n_,size_t d_,int M_){
        n=n_;d=d_;M=M_;adj.resize(n);base=data;std::mt19937 rng(42);
        for(size_t i=1;i<n;++i){size_t ss=std::min<size_t>(200,i);
            std::uniform_int_distribution<size_t>pk(0,i-1);std::set<int>seen;std::vector<int>cand;
            while(cand.size()<ss){int j=(int)pk(rng);if(seen.insert(j).second)cand.push_back(j);}
            std::vector<std::pair<float,int>>dists;
            for(int j:cand)dists.push_back({ip_dist(data+i*d,data+j*d,d),j});
            size_t kp=std::min<size_t>(M_,dists.size());
            std::partial_sort(dists.begin(),dists.begin()+kp,dists.end());
            for(size_t k=0;k<kp;++k){int nb=dists[k].second;adj[i].push_back(nb);
                if(adj[nb].size()<(size_t)M_*2)adj[nb].push_back((int)i);}}
    }
    void search(const float*q,size_t k,size_t ef,int ep,std::vector<std::pair<float,int>>&out)const{
        std::vector<bool>vis(n,false);
        using MH=std::priority_queue<std::pair<float,int>,std::vector<std::pair<float,int>>,std::greater<std::pair<float,int>>>;
        MH pq;Heap H;if(ep<0||ep>=(int)n){out.clear();return;}
        float d0=ip_dist(q,base+ep*d,d);pq.push({d0,ep});H.push({d0,ep});vis[ep]=true;
        while(!pq.empty()){auto[cd,vc]=pq.top();if(cd>H.top().first)break;pq.pop();
            for(int nb:adj[vc]){if(vis[nb])continue;vis[nb]=true;
                float nd=ip_dist(q,base+nb*d,d);if(nd<H.top().first||H.size()<ef){
                    H.push({nd,nb});pq.push({nd,nb});if(H.size()>ef)H.pop();}}}
        out.clear();while(!H.empty()){out.push_back(H.top());H.pop();}
    }
};

// per-process IVF-HNSW
struct IVFNSW {
    size_t d;int K;std::vector<float>cent;std::vector<std::vector<int>>lists;
    std::vector<NSWGraph>graphs;std::vector<std::vector<float>>cbuf;int goff;const float*gb;
    void build(const float*b,size_t n,size_t d_,int K_,int M,int off){
        d=d_;K=K_;goff=off;gb=b;
        cent.resize(K*d);for(int k=0;k<K;++k){int ri=rand()%n;std::memcpy(cent.data()+k*d,b+ri*d,d*4);}
        std::vector<int>as(n);std::vector<float>nc(K*d);std::vector<int>cn(K);
        for(int it=0;it<6;++it){for(size_t i=0;i<n;++i){float be=1e30f;int bk=0;
            for(int k=0;k<K;++k){float dt=l2_dist(b+i*d,cent.data()+k*d,d);if(dt<be){be=dt;bk=k;}}as[i]=bk;}
            std::fill(nc.begin(),nc.end(),0);std::fill(cn.begin(),cn.end(),0);
            for(size_t i=0;i<n;++i){int k=as[i];cn[k]++;for(size_t j=0;j<d;++j)nc[k*d+j]+=b[i*d+j];}
            for(int k=0;k<K;++k)if(cn[k]>0)for(size_t j=0;j<d;++j)cent[k*d+j]=nc[k*d+j]/cn[k];}
        lists.resize(K);for(size_t i=0;i<n;++i)lists[as[i]].push_back((int)i+off);
        graphs.resize(K);cbuf.resize(K);
        for(int k=0;k<K;++k){if(lists[k].size()<3)continue;
            cbuf[k].resize(lists[k].size()*d);
            for(size_t i=0;i<lists[k].size();++i)std::memcpy(cbuf[k].data()+i*d,b+(lists[k][i]-off)*d,d*4);
            graphs[k].build(cbuf[k].data(),lists[k].size(),d,M);}
    }
    // search: query广播, nprobe选簇, 每簇NSW搜索
    std::vector<std::pair<float,int>> search_q(const float*q,size_t k,size_t ef,int nprobe)const{
        Heap coarse;for(int c=0;c<K;++c){float dt=l2_dist(q,cent.data()+c*d,d);hp(coarse,dt,c,nprobe);}
        std::vector<int>pro;while(!coarse.empty()){pro.push_back(coarse.top().second);coarse.pop();}
        std::vector<std::pair<float,int>>all;
        for(int cid:pro){if(lists[cid].size()<3){for(int vid:lists[cid]){
            float ed=ip_dist(q,gb+(vid-goff)*d,d);all.push_back({ed,vid});}continue;}
            std::vector<std::pair<float,int>>lr;
            graphs[cid].search(q,ef,ef,rand()%graphs[cid].n,lr);
            for(auto&p:lr){int gvid=lists[cid][p.second];float ed=ip_dist(q,gb+(gvid-goff)*d,d);all.push_back({ed,gvid});}
        }
        std::partial_sort(all.begin(),all.begin()+std::min(k+5,all.size()),all.end());
        all.resize(std::min(k+5,all.size()));return all;
    }
};

template<typename T>T*ld(const std::string&p,size_t&n,size_t&d){
    std::ifstream f(p,std::ios::binary);if(!f)return nullptr;
    int32_t h[2];f.read((char*)h,8);n=h[0];d=h[1];T*dt=new T[n*d];f.read((char*)dt,n*d*sizeof(T));return dt;
}
