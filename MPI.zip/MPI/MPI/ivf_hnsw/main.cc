// IVF-HNSW MPI: IVF簇分布在MPI进程间, 簇内NSW搜索, MPI merge
// 编译: mpic++ main.cc -o main -O2 -std=c++17
#include <chrono>
#include <iomanip>
#include <iostream>
#include <set>
#include "ivf_hnsw.h"

float recall_of(const Heap& r,const int* gt,size_t k){std::set<int> gs(gt,gt+k);size_t h=0;Heap t=r;
    while(!t.empty()){if(gs.count(t.top().second))++h;t.pop();}return (float)h/k;}

int main(int argc,char** argv){
    MPI_Init(&argc,&argv);int rank,sz;MPI_Comm_rank(MPI_COMM_WORLD,&rank);MPI_Comm_size(MPI_COMM_WORLD,&sz);srand(42+rank);
    size_t tn=0,dim=0,qn=0,gd=0;float*ab=nullptr,*qu=nullptr;int*gt=nullptr;
    if(rank==0){std::string dp="/anndata/";qu=ld<float>(dp+"DEEP100K.query.fbin",qn,dim);
        ab=ld<float>(dp+"DEEP100K.base.100k.fbin",tn,dim);gt=ld<int>(dp+"DEEP100K.gt.query.100k.top100.bin",qn,gd);qn=2000;}
    MPI_Bcast(&tn,1,MPI_UNSIGNED_LONG_LONG,0,MPI_COMM_WORLD);MPI_Bcast(&dim,1,MPI_UNSIGNED_LONG_LONG,0,MPI_COMM_WORLD);
    MPI_Bcast(&qn,1,MPI_UNSIGNED_LONG_LONG,0,MPI_COMM_WORLD);MPI_Bcast(&gd,1,MPI_UNSIGNED_LONG_LONG,0,MPI_COMM_WORLD);
    size_t ln=tn/sz,rm=tn%sz;std::vector<int>sc(sz),ds(sz);size_t off=0;
    for(int i=0;i<sz;++i){sc[i]=(int)((ln+(i<(int)rm?1:0))*dim);ds[i]=(int)(off*dim);off+=ln+(i<(int)rm?1:0);}
    size_t mn=ln+(rank<(int)rm?1:0);std::vector<float>lb(mn*dim);
    MPI_Scatterv(ab,sc.data(),ds.data(),MPI_FLOAT,lb.data(),(int)(mn*dim),MPI_FLOAT,0,MPI_COMM_WORLD);
    int goff=(int)(ds[rank]/dim);if(rank==0)delete[] ab;
    const size_t k=10,ef=32;const int K_ivf=64,M=8,nprobe=4;
    IVFNSW idx;idx.build(lb.data(),mn,dim,K_ivf,M,goff);
    if(rank!=0){qu=new float[qn*dim];gt=new int[qn*gd];}
    MPI_Bcast(qu,(int)(qn*dim),MPI_FLOAT,0,MPI_COMM_WORLD);MPI_Bcast(gt,(int)(qn*gd),MPI_INT,0,MPI_COMM_WORLD);
    double ts=MPI_Wtime();float total_recall=0;
    for(size_t i=0;i<qn;++i){auto lr=idx.search_q(qu+i*dim,k,ef,nprobe);
        int lc=(int)lr.size();std::vector<float>lbuf(lc*2);
        for(int j=0;j<lc;++j){lbuf[j*2]=lr[j].first;lbuf[j*2+1]=(float)lr[j].second;}
        std::vector<int>ac(sz);MPI_Gather(&lc,1,MPI_INT,ac.data(),1,MPI_INT,0,MPI_COMM_WORLD);
        std::vector<float>abuf;std::vector<int>rd(sz),acf(sz);if(rank==0){int t=0;for(int j=0;j<sz;++j){acf[j]=ac[j]*2;rd[j]=t*2;t+=ac[j];}abuf.resize(t*2);}
        MPI_Gatherv(lbuf.data(),lc*2,MPI_FLOAT,abuf.data(),acf.data(),rd.data(),MPI_FLOAT,0,MPI_COMM_WORLD);
        if(rank==0){Heap gl;int tp=(int)abuf.size()/2;for(int j=0;j<tp;++j)hp(gl,abuf[j*2],(int)abuf[j*2+1],k);total_recall+=recall_of(gl,gt+i*gd,k);}}
    double te=MPI_Wtime();
    if(rank==0){std::cout<<std::fixed<<std::setprecision(3)<<"[IVF-HNSW-MPI] procs="<<sz
        <<" K="<<K_ivf<<" np="<<nprobe<<" ef="<<ef<<" avg_lat="<<(te-ts)*1e6/qn<<" us recall="<<total_recall/qn<<"\n";}
    delete[] qu;delete[] gt;MPI_Finalize();return 0;
}
