#pragma once

#include <algorithm>
#include <atomic>
#include <chrono>
#include <memory>
#include <pthread.h>
#include <string>
#include <vector>
#include "hnswlib/hnswlib/hnswlib.h"
#include "../graph_index_common/common.h"

using namespace hnswlib;

// ---- index file path helper ----

static inline std::string hnsw_split_part_index_path(int parts, const std::string &mode, int M, int efc, int part_id)
{
    return files_path("hnsw_split_parts" + std::to_string(parts) +
                      "_" + mode + "_M" + std::to_string(M) +
                      "_efc" + std::to_string(efc) +
                      "_part" + std::to_string(part_id) + ".index");
}

// ---- data structures ----

struct SplitPartIndex
{
    int part_id = -1;
    size_t count = 0;
    std::unique_ptr<HierarchicalNSW<float>> index;
};

struct SplitThreadStat
{
    double work_us = 0.0;
    size_t tasks = 0;
};

struct SplitWorkerArg
{
    const std::vector<SplitPartIndex> *part_indexes;
    const float *queries;
    size_t qn = 0;
    size_t dim = 0;
    size_t local_k = 0;
    std::atomic<size_t> *next = nullptr;
    std::vector<std::vector<MinPair>> *results = nullptr;
    std::vector<double> *query_us = nullptr;
    std::vector<SplitThreadStat> *stats = nullptr;
    int tid = 0;
};

// ---- local search ----

static inline void hnsw_split_search_one_local(const std::vector<SplitPartIndex> &part_indexes,
                                                const float *query, size_t local_k,
                                                std::vector<MinPair> &out)
{
    Heap local_heap;
    for (const auto &part : part_indexes)
    {
        if (!part.index)
            continue;
        auto ret = part.index->searchKnn(const_cast<float *>(query), local_k);
        while (!ret.empty())
        {
            hp(local_heap, ret.top().first, static_cast<int>(ret.top().second), local_k);
            ret.pop();
        }
    }

    out.clear();
    out.reserve(local_k);
    while (!local_heap.empty())
    {
        out.push_back(local_heap.top());
        local_heap.pop();
    }
}

// ---- worker thread function (must be a free function for pthread) ----

static void *hnsw_split_query_worker(void *arg)
{
    SplitWorkerArg *a = static_cast<SplitWorkerArg *>(arg);
    while (true)
    {
        size_t qi = a->next->fetch_add(1);
        if (qi >= a->qn)
            break;

        auto t0 = std::chrono::steady_clock::now();
        hnsw_split_search_one_local(*a->part_indexes, a->queries + qi * a->dim, a->local_k, (*a->results)[qi]);
        auto t1 = std::chrono::steady_clock::now();
        double us = std::chrono::duration<double, std::micro>(t1 - t0).count();

        (*a->query_us)[qi] = us;
        (*a->stats)[(size_t)a->tid].tasks += 1;
        (*a->stats)[(size_t)a->tid].work_us += us;
    }
    return nullptr;
}
